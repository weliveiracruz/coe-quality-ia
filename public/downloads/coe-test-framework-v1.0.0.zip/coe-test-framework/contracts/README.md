# Contratos versionados no repositório

Não há Pact Broker. Os contratos ficam aqui, versionados pelo Git, e qualquer mudança passa por pull request.

```
contracts/
  schemas/                       JSON Schema dos payloads (fonte da verdade dos campos)
    resposta-pesquisa.schema.json   canais -> BFF
    evento-pesquisa.schema.json     BFF -> API de eventos
  canais-bff/                    pacts gerados pelos consumidores (web, webview, android, ios)
  bff-api/                       pact gerado pelo BFF como consumidor da API .NET
```

## Duas camadas
| Camada | Consumidor | Provedor | Quem verifica |
|---|---|---|---|
| canais → BFF | Android, iOS, WebView, Web | `bff-pesquisa` | Pipeline do BFF (`ProvedorCanaisPactTest`) |
| BFF → API | `bff-pesquisa` | `api-eventos` | Pipeline da API .NET (`ProvedorBffPactTests`) |

## Fluxo de mudança
1. **Consumidor** altera o teste de contrato. O pact gerado vai para a pasta da camada no mesmo PR deste repositório, ou num PR automático aberto pelo workflow `contrato-publicar`.
2. O PR roda a verificação **de todos os provedores afetados** contra o pact novo. Se quebrar, o merge trava com a interação que falhou no comentário.
3. **Provedor** que muda a API roda contra **todos** os pacts vigentes da camada. Se remover um campo que o iOS usa, o PR do BFF falha mostrando o consumidor `modulo-pesquisa-ios`.
4. Mudança incompatível de verdade exige nova versão de rota (`/v2`) e período de convivência registrado em `metadata.coe.versao_contrato`.

## Por que schema e pact juntos
O **schema** garante a forma dos campos (tipos e campos proibidos, como CPF em `cliente_ref`) e é usado também pelos testes E2E e pelo scanner de qualidade de dados. O **pact** garante o comportamento: status, idempotência, token expirado.

# Playbook: bump do FullStory no SDK de Analytics

## Gatilho
O Dependabot abre o PR com o label `coe-analytics-bump`, para uma nova versão do FullStory ou do BoM do Firebase. A suíte `analytics-bump` roda no Android e no iOS.

## Leitura do comentário no PR
| Resultado | O que fazer |
|---|---|
| Tudo OK | Tech Lead aprova e faz o merge. A baseline é atualizada sozinha na `main`. |
| `api_publica_wrapper` FALHOU | O FullStory mudou algo que o wrapper expõe. Ajuste o wrapper para manter as assinaturas. Se a quebra for inevitável, suba a versão **major** do SDK e avise os apps consumidores. |
| `compila_e_inicializa` FALHOU | Veja o log do teste `bump01`. Normalmente é mudança de inicialização ou de permissão no FullStory. Consulte o changelog do fornecedor. |
| `convivencia_firebase` FALHOU | Conflito entre FullStory e Firebase (ordem de inicialização, dependência transitiva). Fixe a versão que conflita e abra um chamado com o fornecedor. |
| `captura_sessao` FALHOU | Confira a chave e o org do FullStory no ambiente de teste. Se estiverem corretos, a versão nova tem regressão: não faça o merge. |
| `tamanho_pacote` acima de +5% | Avalie com o time dos apps. Se aceitarem, registre a exceção no PR e ajuste a baseline manualmente. |
| `tempo_inicializacao` acima de +10% | Repita o job uma vez (pode ser ruído do emulador). Se persistir, não faça o merge e reporte ao fornecedor. |

## Prazos
- **Patch e minor:** avaliar em até 5 dias úteis.
- **Correção de segurança do fornecedor:** no mesmo dia.
- **Major:** abrir uma história no IU Click para planejar a adaptação.

## Exceção registrada
Toda exceção (merge com verificação vermelha) precisa de aprovação do CoE no PR, com justificativa, para ficar auditável.

# Governança: RACI, versões e métricas

## RACI
| Atividade | CoE | PM | Tech Lead | Devs | Time do IU Click |
|---|---|---|---|---|---|
| Manter o framework, templates e workflows | **R/A** | I | C | C | |
| Definir e alterar o quality gate | **R/A** | I | C | I | |
| Cenários de negócio no catálogo | C | **R/A** | C | I | |
| Cenários transversais (a11y, LGPD, rede, token) | **R/A** | I | I | I | |
| Implementar os testes dos cenários | C | I | **A** | **R** | |
| Revisar o PR (técnico) | | | **R/A** | R | |
| Conferir os cenários de negócio no PR | | **R/A** | I | | |
| Corrigir testes instáveis | C | I | **A** | **R** | |
| Contratos: propor mudança | C | I | **A** | **R** | |
| Contratos: aprovar mudança que afeta outros | **A** | I | R (de cada consumidor) | | |
| Exceção de gate | **A** | I | R | | |
| Credencial de serviço do IU Click | C | | I | | **R/A** |
| Revisão mensal de cobertura e paridade | **R/A** | C | C | I | |

R = executa · A = responde · C = consultado · I = informado

## Versões do framework
- SemVer com tags: as squads fixam `@v1`, que acompanha os minors e patches automaticamente.
- **Patch:** correções. **Minor:** novas camadas ou opções, sempre desligadas por padrão. **Major:** pode exigir mudança na squad e vem com guia de migração no `CHANGELOG.md` e 30 dias de convivência.
- O CI do framework (`.github/workflows/ci.yml`) testa o CLI, os exemplos, o template web contra a demo e a acessibilidade do portal antes de cada tag.

## Métricas de adoção e qualidade
Publicadas a cada execução em `coe-metricas.json` (schema em `core/schemas/metricas.schema.json`) e exibidas no painel do portal.

| Métrica | Meta |
|---|---|
| Squads no nível prata ou acima | 80% em 2 trimestres |
| Cobertura do código novo | ≥ 80% (gate) |
| Testes instáveis | < 1% |
| Tempo de pipeline de PR (runner) | < 15 min |
| Defeitos escapados para produção por release | Tendência de queda trimestre a trimestre |
| Paridade entre canais (módulo de pesquisa) | ≥ 95% |
| PRs bloqueados só pela janela | Acompanhar (insumo para FinOps) |

O JSON é o mesmo para todas as squads. Assim, o time de Indicadores de Experiência pode consumi-lo direto como fonte de um painel corporativo de qualidade.

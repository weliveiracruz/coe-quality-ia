# Guia de adoção — squad nova

Tempo estimado até o primeiro pipeline verde: **menos de uma hora**.

## 1. Gerar a estrutura
Pelo portal (`portal/index.html`, seção "Cadastrar squad"), ou pela linha de comando:
```bash
npx github:itau-coe/coe-test-framework#v1 init \
  --stack <android-compose|ios-swiftui|kotlin-bff|dotnet-api|angular|react> \
  --produto <modulo-pesquisa|bff-kotlin|api-eventos|...> \
  --squad "Nome da Squad" --canais android,webview --nivel bronze
```
O comando cria:
- `coe-test.yml`, o único arquivo que a squad edita
- `.github/workflows/coe-qualidade.yml`, com 5 linhas que chamam o pipeline do CoE
- `coe-tests/`, com exemplos de cada camada já passando contra uma implementação de referência

## 2. Ligar ao código real
1. Siga o `README.md` dentro de `coe-tests/`, que muda conforme a stack.
2. Troque os imports da `exemplo-referencia/` pelos do seu código e apague a pasta.
3. Mescle as dependências de `package.coe.json`, `build.gradle.coe.kts` ou `.csproj`.

## 3. Configurar o repositório (uma vez)
**Secrets** (Settings → Secrets and variables → Actions):

| Secret | Para quê |
|---|---|
| `SONAR_TOKEN` | Análise no SonarQube interno |
| `COE_FRAMEWORK_TOKEN` | Leitura do repositório do framework, se for privado |
| `IUCLICK_MCP_URL`, `IUCLICK_TOKEN` | Integração com o IU Click (credencial de serviço) |
| `DEVICE_FARM_URL`, `DEVICE_FARM_TOKEN` | Device farm (mobile) |
| `COE_WEB_USUARIO`, `COE_WEB_SENHA` | Usuário de teste das plataformas web |
| `COE_TOKEN_CANAL_HML`, `COE_TOKEN_SERVICO_HML` | Performance, resiliência e qualidade de dados em homologação |
| `NVD_API_KEY` | Acelera o Dependency-Check |

**Variáveis:** `SONAR_HOST_URL`, `COE_BFF_HML_URL`, `COE_API_EVENTOS_HML_URL`, `COE_WEB_HML_URL`, `COE_BFF_OPENAPI_URL`, `COE_API_EVENTOS_OPENAPI_URL`.

**Proteção da branch `main`:** exigir os checks `Qualidade CoE` e `coe/ambiente`. O segundo segura o merge enquanto os testes de ambiente esperam a janela.

## 4. Primeiro PR
Abra um PR com o ID da história do IU Click no título (por exemplo, `PESQ-1234: adota CoE`). O PR recebe:
- comentário com os gates
- link do relatório
- atualização na história

## Níveis de maturidade
| Nível | Camadas exigidas | Efeito |
|---|---|---|
| **Bronze** | Lint, unitário, segurança estática, SonarQube | Entrada no framework |
| **Prata** | Bronze + contrato, integração, acessibilidade, privacidade | Padrão esperado em até 2 sprints |
| **Ouro** | Prata + mutação, E2E, performance, resiliência, qualidade de dados | A paridade entre canais passa a bloquear o merge |

O nível é calculado a cada execução e aparece no painel do portal.

## Checklist de onboarding
- [ ] `coe-test init` executado e `coe-test validate` sem erro
- [ ] Secrets e variáveis cadastrados
- [ ] Branch protection com `Qualidade CoE` e `coe/ambiente`
- [ ] Exemplos apontando para o código real
- [ ] Primeiro PR verde com comentário do CoE
- [ ] Squad aparece no painel do portal
- [ ] PM fez o treinamento do modelo de história (30 min)
- [ ] Tech Lead conhece o `coe-test esqueleto` e a paridade
- [ ] Nível bronze atingido

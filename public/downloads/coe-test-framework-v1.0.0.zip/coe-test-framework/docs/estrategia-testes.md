# Estratégia de testes do CoE

## Princípios
1. **Mais barato primeiro.** O pipeline segue a ordem de custo e para no primeiro erro, para economizar runner e ambiente.
2. **Escrito uma vez, executado em todos os canais.** O cenário de negócio mora no catálogo do produto, e cada canal implementa o seu teste.
3. **Transversais são do CoE.** Acessibilidade, LGPD, rede ruim e token são herdados por todas as squads.
4. **Sem QA na squad, o framework faz o papel de rede de segurança.** Modelos guiados para o PM, esqueletos para os devs e gates automáticos.
5. **Ambiente é caro.** Tudo que pode rodar sem ambiente (Testcontainers, WireMock, emuladores) roda no runner.

## Pirâmide por camada
| Camada | Objetivo | Proporção | Momento |
|---|---|---|---|
| Unitário / componente | Regras e estados de tela | Base, cerca de 70% | PR |
| Contrato | Canais ↔ BFF ↔ API não quebram entre si | Toda interação usada | PR |
| Integração | Dependências reais (containers) ou homologação | Fluxos de serviço | PR (runner ou janela) |
| UI / E2E | Jornada completa por canal | Só cenários do catálogo | PR (janela) |
| Acessibilidade | WCAG 2.2 AA, TalkBack, VoiceOver | Toda tela, em todo estado | PR (janela) |
| Visual | Regressão de layout | Telas-chave | PR (janela) |
| Performance, DAST, device farm, resiliência, qualidade de dados | Riscos de produção | Por release | Fechamento do pacote |
| Smoke | Produção funcionando | 3 verificações | Contínuo |

## Ferramentas por stack
| | Android | iOS | Angular / React | BFF Kotlin | API .NET |
|---|---|---|---|---|---|
| Unitário | JUnit 5, MockK, Robolectric | XCTest | Jest / Vitest + Testing Library | JUnit 5, MockK | xUnit, FluentAssertions, NSubstitute |
| Integração | MockWebServer | URLProtocol | não se aplica | Testcontainers, WireMock | WebApplicationFactory, Testcontainers |
| UI / E2E | Compose UI Test, Espresso-Web | XCUITest | Playwright (3 motores) | REST Assured | não se aplica |
| Acessibilidade | ATF | `performAccessibilityAudit` | axe-core, Lighthouse | não se aplica | não se aplica |
| Contrato | Schema + Pact consumidor | Schema + Pact consumidor | Schema + Pact consumidor | Pact provedor e consumidor | Pact provedor |
| Mutação | PIT | não se aplica | Stryker | PIT | Stryker.NET |
| Performance | Macrobenchmark (SDK) | XCTMetric (SDK) | Lighthouse | k6 | k6 |
| Segurança | MobSF | MobSF | ZAP full scan | ZAP API scan | ZAP API scan |

Para todas as stacks: Semgrep, Gitleaks e OWASP Dependency-Check, além do quality gate do CoE no SonarQube interno.

## Quality gate do CoE
| Regra | Valor padrão | A squad pode... |
|---|---|---|
| Cobertura do código novo | ≥ 80% | subir |
| Duplicação | ≤ 3% | baixar |
| Mutantes mortos | ≥ 60% | subir |
| Bugs e vulnerabilidades bloqueantes | 0 | não alterar |
| Violações graves de acessibilidade (axe critical e serious) | 0 | não alterar |
| Dados pessoais em eventos | 0 | não alterar |
| Vulnerabilidades críticas no release | 0 | não alterar |
| SLO de performance (p95, p99, taxa de erro) | 800 ms, 1500 ms, 1% | definir o seu |

O CLI recusa um `coe-test.yml` que afrouxe qualquer mínimo.

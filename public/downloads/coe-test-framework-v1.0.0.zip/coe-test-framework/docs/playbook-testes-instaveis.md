# Playbook: testes instáveis (flaky)

## Como o framework detecta
Toda stack roda com **uma** nova tentativa:
- Playwright: `retries: 1`
- Gradle: `test-retry`
- XCTest: `retryOnFailure`
- Vitest: `retry: 1`

O teste que só passa na segunda tentativa conta como **instável** no JSON de métricas e no painel. Ele não reprova o PR, mas fica visível.

## Regras
1. **Teste instável não é ignorado.** Ele vira uma task no IU Click, com o dono sendo quem criou ou alterou o teste por último.
2. **Prazo de correção:** 5 dias úteis. Depois disso, o teste vai para quarentena (`@Disabled`, `test.fixme` ou `XCTSkip`) com o ID da task no motivo. Em quarentena, ele não conta para a paridade.
3. **Quarentena máxima:** 15 dias úteis. Depois disso, o CoE e o Tech Lead decidem entre corrigir de vez ou apagar.
4. **Meta por squad:** menos de 1% de testes instáveis em 30 dias. É acompanhada no painel.

## Causas mais comuns e correção
| Causa | Correção |
|---|---|
| Espera fixa (`sleep`) | Espera por condição: `expect(...).toBeVisible()`, `waitForExistence`, `IdlingResource` |
| Dependência entre testes | Cada teste cria a própria massa (`core/test-data`) e limpa o que criou |
| Animação | Desligar animações (já vem no template do Android e com `animations: 'disabled'` no Playwright) |
| Data e hora | Fixar relógio e fuso (`timezoneId: America/Sao_Paulo`) |
| Ambiente de homologação oscilando | Mover para Testcontainers ou WireMock quando possível; senão, registrar como incidente de ambiente |
| Ordem de dados assíncronos | Ordenar antes de comparar; usar IDs fixos de teste |

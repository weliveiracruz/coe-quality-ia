# Janela de execução (FinOps): ambiente das 8h às 20h

O ambiente de testes fica ligado só das 8h às 20h (horário de Brasília). Não há execução noturna. O framework divide os testes em três momentos e decide sozinho o que roda.

## 1. A qualquer hora (runner do GitHub)
Rodam em todo PR, inclusive de madrugada, porque não precisam do ambiente:
- unitário e contrato
- mutação
- análise do SonarQube e segurança estática
- privacidade
- rede instável

Integração com Testcontainers também entra aqui, se a squad declarar:
```yaml
estagios:
  integracao: { precisa_ambiente: false }
```

## 2. Dentro da janela
Integração com homologação, E2E/UI, acessibilidade e visual.
- **PR aberto fora do horário:** essas etapas ficam pendentes. O status `coe/ambiente` fica amarelo e o merge, bloqueado.
- **Às 8h05:** o agendamento do workflow da squad (`schedule`) reexecuta os PRs pendentes.
- **Perto das 20h:** o plano só inicia o que cabe antes do desligamento, com 15 min de margem. O restante continua pendente para o dia seguinte.

## 3. Fechamento do pacote para produção
Disparado ao criar a branch `release/*` ou manualmente com `momento: release`. Inclui:
- performance com k6
- OWASP ZAP
- device farm com a matriz completa
- resiliência com Toxiproxy
- qualidade de dados ponta a ponta

Essas suítes são obrigatórias para liberar o deploy. O pipeline **não inicia** se a duração estimada não couber antes das 20h e avisa para disparar no dia seguinte a partir das 8h.

## Ajustes
No `coe-test.yml`:
```yaml
janela:
  inicio: "08:00"
  fim: "20:00"
  dias: [seg, ter, qua, qui, sex]   # se o ambiente também desligar no fim de semana
  margem_min: 15
```
As durações estimadas de cada estágio ficam em `core/defaults/estagios.yml` e podem ser sobrescritas por squad (`estagios.<id>.duracao_min`).

## Para conferir na hora
```bash
coe-test janela --duracao 60          # a janela está aberta? cabe uma execução de 60 min?
coe-test plano --momento release      # o que rodaria agora no fechamento do pacote
```

O smoke sintético em produção não depende da janela e roda o dia todo.

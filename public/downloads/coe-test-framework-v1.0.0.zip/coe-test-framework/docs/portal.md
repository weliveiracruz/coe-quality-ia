# Portal web do CoE

Arquivo único: `portal/index.html`. Funciona aberto direto no navegador, publicado no GitHub Pages ou num servidor interno.

## Seções
| Seção | Para quem | O que faz |
|---|---|---|
| Cadastrar squad | PM, Tech Lead | Formulário que gera o `coe-test.yml` e o workflow, com camadas, canais, perfis web e status do IU Click. Abre o pull request no repositório da squad. |
| Plataforma web | Tech Lead, CoE | Gera um perfil novo a partir do modelo, sem alterar o framework |
| Painel de qualidade | CoE, gestão, Indicadores | Última execução por squad: nível, testes, instáveis, cobertura e gates |
| Catálogo de cenários | PM, Tech Lead | Cenários por produto, com o texto "dado, quando, então" e a paridade por canal |

## Dados
Os catálogos, a paridade e as métricas ficam embutidos no HTML. Para atualizar:
```bash
node core/cli/bin/coe-test.js portal --metricas <pasta com os coe-metricas.json das squads>
```
Sem `--metricas`, o portal usa os dados de exemplo e avisa isso na tela. Um job agendado do CoE pode baixar os artefatos `coe-relatorio-*` das squads, rodar o comando e publicar.

## Acessibilidade (WCAG 2.2 AA)
- Link "Pular para o conteúdo", landmarks e títulos hierárquicos.
- Navegação por teclado; ao trocar de seção, o foco vai para o título e `aria-current` marca a seção.
- Validação com resumo de erros que recebe o foco e tem links para os campos, além de `aria-invalid` e mensagens associadas.
- Anúncios de ações (copiar, gerar, filtrar) numa região `aria-live`.
- Alvos de toque de 44 px (acima do mínimo de 24 px do critério 2.5.8), foco visível com 3 px e contraste AA.
- Reflow sem rolagem horizontal a 320 px; tabelas roláveis com foco.
- Status com texto, além da cor ("Aprovado", "Reprovado", "Pendente", "Falta").

Testado com axe (tags `wcag2a`, `wcag2aa`, `wcag21aa`, `wcag22aa`) e teclado em `portal/teste/portal.spec.ts`, que roda no CI do framework.

# Casos de teste e integração com o IU Click

As squads não têm QA. O **PM** escreve os cenários de negócio, o **Tech Lead** garante a implementação, e o **CoE** cobre o papel de qualidade com os transversais e as revisões.

## Fluxo
1. **Origem na história.** O PM escreve os critérios de aceite como cenários "dado, quando, então", em português, usando `docs/modelo-historia-pm.md`. O modelo traz as perguntas que um QA faria.
2. **Proposta pelo agente.** Um agente de IA lê a história pelo MCP do IU Click e propõe os cenários, incluindo os transversais que se aplicam. O prompt fica em `core/agente/prompt-cenarios.md`. O PM revisa e aprova, e os aprovados são gravados de volta na história.
3. **Catálogo único.** Os cenários aprovados entram em `products/<produto>/catalogo/cenarios.yml` por pull request, com `id`, `historia` e `canais`. O catálogo é por produto, não por plataforma.
4. **Implementação.** Cada canal gera o esqueleto e completa:
   ```bash
   coe-test esqueleto --cenario CEN-PESQ-004 --stack ios-swiftui
   ```
5. **Revisão no PR.** O comentário do CoE mostra quais cenários o PR cobre e a paridade por canal. O Tech Lead aprova o técnico e o PM confere o negócio.
6. **Resultado na história.** Ao fim do pipeline, o resultado é gravado na história do IU Click, por cenário e por plataforma, com o link do relatório.
7. **Movimentação.** Quando os gates passam, a task avança. Quando algo falha, volta com o motivo. Com testes pendentes da janela, a task não se move.

## Configuração por squad (parametrizável)
```yaml
iuclick:
  habilitado: true
  projeto: PESQ
  comentar_resultado: true
  mover_tasks: true
  status:
    em_teste: "Em teste"
    aprovado: "Pronto para release"     # cada squad usa os nomes do seu fluxo
    reprovado: "Em desenvolvimento"
  ferramentas_mcp:                      # nomes das ferramentas do MCP do IU Click
    ler_historia: iuclick_get_story
    comentar: iuclick_add_comment
    mover: iuclick_move_task
    gravar_cenarios: iuclick_update_acceptance_criteria
```
Os nomes de `ferramentas_mcp` são placeholders. Ajuste aos nomes reais do MCP do IU Click; não é preciso mudar código.

## Como o pipeline encontra a história
O ID da história (padrão `PROJETO-123`) é extraído do título do PR, do nome da branch ou da mensagem de commit. Os IDs de cenário (`CEN-...`) são ignorados nessa extração.

## Acesso e camadas de segurança
- **Credencial de serviço:** a integração usa `IUCLICK_TOKEN`, que precisa ser liberada pelo time dono do IU Click, com escopo mínimo (ler história, comentar, mover task).
- **Modo simulação:** sem `IUCLICK_MCP_URL` ou `IUCLICK_TOKEN`, o CLI só imprime o que faria. Use para validar antes de liberar a credencial.
- **Transporte:** chamadas JSON-RPC 2.0 (`tools/call`) via HTTP, com resposta em JSON ou SSE. Se houver gateway ou proxy corporativo, aponte `IUCLICK_MCP_URL` para ele.

## Cenários transversais (mantidos pelo CoE)
Ficam em `suites/transversais/catalogo-transversal.yml` e entram automaticamente na paridade de cada produto:
- CEN-TRV-001: leitor de tela
- CEN-TRV-002: fonte ampliada e zoom de 200%
- CEN-TRV-003: LGPD
- CEN-TRV-004: offline
- CEN-TRV-005: token expirado
- CEN-TRV-006: contraste e área de toque

O CoE revisa a cobertura de cada squad mensalmente, pelo painel.

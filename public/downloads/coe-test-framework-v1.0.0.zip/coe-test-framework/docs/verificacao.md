# Verificação desta versão (v1.0.0)

O que foi **executado** antes da entrega e o que depende da infraestrutura do Itaú.

## Executado e aprovado
| Item | Resultado |
|---|---|
| Testes do CLI: config, mínimos do gate, janela 8h–20h, plano por momento, privacidade, catálogo e paridade, métricas e instabilidade, gates, IU Click (status parametrizáveis), bump, esqueletos, init, paridade de payload, contratos x schemas, qualidade de dados | 52 de 52 passaram |
| Configurações de exemplo (`examples/*.yml`) contra o schema e os mínimos do CoE | 5 de 5 válidas |
| Template **React** (Vitest, Testing Library, axe, privacidade) | 8 de 8 passaram |
| Template **Angular** (Jest, Angular Testing Library, jest-axe) com Angular 18 | 6 de 6 passaram |
| **E2E web** (Playwright + axe) contra a demo, no Chrome, rodando no framework e numa squad criada por `coe-test init` | 16 de 16 e 15 de 15 passaram |
| Cadeia completa de gates numa squad gerada: privacidade, paridade com resultados, paridade de payload, gates, métricas, IU Click (simulação) | OK, nível prata calculado |
| Scanner de privacidade com vazamento proposital (CPF, e-mail, saldo) | 3 de 3 detectados |
| Qualidade de dados ponta a ponta contra BFF e API simulados, com defeito proposital no canal iOS | Defeito detectado (6 de 8 íntegras) |
| **Portal** (axe WCAG 2.2 AA em todas as seções, teclado, foco, validação, reflow a 320 px) | 6 de 6 passaram |
| Workflows e actions (`actionlint` + `shellcheck`) | Sem apontamentos (um risco de injeção de script foi achado e corrigido) |
| Regras Semgrep do CoE | Válidas e disparando nos três casos de teste |
| Sintaxe de scripts k6, Node e shell, e JSON, YAML e TOML do repositório | OK |

## Escrito, mas não executado aqui
O ambiente de geração não tinha acesso a Maven Central, NuGet, Gradle, Xcode ou emulador. Esses templates seguem as APIs documentadas das ferramentas, mas **precisam de uma primeira execução no CI de vocês**:

| Item | O que validar na primeira execução |
|---|---|
| Android (Compose, Espresso-Web, ATF, MockWebServer, TestStorage) | Ajustar imports ao módulo real; rodar `testDebugUnitTest` e o emulador gerenciado |
| iOS (XCTest, XCUITest, `performAccessibilityAudit`) | Runner macOS com Xcode 15+ (a auditoria exige iOS 17) |
| BFF Kotlin (Spring, Pact JVM, WireMock, Testcontainers, PIT) | Perfil `coe-teste` no BFF; endpoint de idempotência |
| API .NET (xUnit, PactNet 5, Testcontainers, Stryker.NET) | `public partial class Program`; endpoints do ambiente `CoeTeste` |
| Suíte de bump do FullStory | Nomes reais do wrapper (`AnalyticsSdk`) e da dependência do FullStory |
| k6, Toxiproxy, ZAP, device farm | URLs e credenciais de homologação; fornecedor da device farm |
| IU Click | Nomes reais das ferramentas do MCP e credencial de serviço |
| SonarQube | Rodar `core/sonar/configurar-quality-gate.sh` uma vez com token de administrador |

## Pontos em aberto
- **Fornecedor da device farm:** o adaptador genérico está pronto; falta registrar o adaptador do fornecedor em `core/cli/src/lib/devicefarm.js`.
- **Ferramentas do MCP do IU Click:** os nomes em `iuclick.ferramentas_mcp` são provisórios.

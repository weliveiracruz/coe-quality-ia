// Performance do BFF de pesquisa (k6). Roda no FECHAMENTO DO PACOTE, dentro da janela 8h–20h.
// SLOs vêm do coe-test.yml via variáveis (o workflow exporta): COE_P95_MS, COE_P99_MS, COE_ERRO_MAX, COE_RPS_ALVO.
// Cenário: CENARIO=carga (padrão) | estresse | pico | resistencia
// Uso: k6 run -e BFF_URL=https://bff-hml... -e TOKEN=... --summary-export artefatos/performance.json bff-pesquisa.k6.js
import http from 'k6/http';
import { check } from 'k6';
import { uuidv4 } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

const P95 = Number(__ENV.COE_P95_MS ?? 800);
const P99 = Number(__ENV.COE_P99_MS ?? 1500);
const ERRO = Number(__ENV.COE_ERRO_MAX ?? 0.01);
const RPS = Number(__ENV.COE_RPS_ALVO ?? 50);

const CENARIOS = {
  carga: { executor: 'constant-arrival-rate', rate: RPS, timeUnit: '1s', duration: '10m', preAllocatedVUs: RPS, maxVUs: RPS * 4 },
  estresse: { executor: 'ramping-arrival-rate', startRate: RPS, timeUnit: '1s', preAllocatedVUs: RPS * 2, maxVUs: RPS * 8,
    stages: [{ target: RPS * 2, duration: '5m' }, { target: RPS * 4, duration: '5m' }, { target: RPS * 4, duration: '5m' }] },
  pico: { executor: 'ramping-arrival-rate', startRate: RPS, timeUnit: '1s', preAllocatedVUs: RPS * 4, maxVUs: RPS * 12,
    stages: [{ target: RPS, duration: '2m' }, { target: RPS * 10, duration: '30s' }, { target: RPS * 10, duration: '2m' }, { target: RPS, duration: '1m' }] },
  resistencia: { executor: 'constant-arrival-rate', rate: Math.round(RPS * 0.7), timeUnit: '1s', duration: '25m', preAllocatedVUs: RPS, maxVUs: RPS * 3 },
};

export const options = {
  scenarios: { [__ENV.CENARIO ?? 'carga']: CENARIOS[__ENV.CENARIO ?? 'carga'] },
  thresholds: {
    http_req_duration: [`p(95)<${P95}`, `p(99)<${P99}`],
    http_req_failed: [`rate<${ERRO}`],
    checks: ['rate>0.99'],
  },
  summaryTrendStats: ['avg', 'p(90)', 'p(95)', 'p(99)', 'max'],
  tags: { produto: 'bff-pesquisa', origem: 'coe-performance' },
};

const CANAIS = ['android', 'ios', 'webview', 'web'];

export default function () {
  const id = `r-perf-${uuidv4()}`;
  const corpo = {
    pesquisa_id: 'PESQ-NPS-APP', versao_pesquisa: 3, canal: CANAIS[__ITER % 4], resposta_id: id,
    respostas: [{ pergunta_id: 'nota', tipo: 'escala', valor: 1 + (__ITER % 5) }],
    contexto: { jornada: 'teste-carga', plataforma: CANAIS[__ITER % 4] },
  };
  const r = http.post(`${__ENV.BFF_URL}/bff/pesquisa/v1/respostas`, JSON.stringify(corpo), {
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${__ENV.TOKEN}`, 'Idempotency-Key': id, 'X-Coe-Sintetico': 'true' },
  });
  check(r, { 'status 201': (x) => x.status === 201 });
}

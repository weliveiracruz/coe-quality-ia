// Performance da API de eventos (.NET) focada em VOLUME e PICOS de ingestão.
// Simula o BFF publicando em lote (o BFF é o único cliente da API). Fechamento do pacote, janela 8h–20h.
import http from 'k6/http';
import { check } from 'k6';
import crypto from 'k6/crypto';

const RPS = Number(__ENV.COE_RPS_ALVO ?? 1000);

export const options = {
  scenarios: {
    volume_sustentado: { executor: 'constant-arrival-rate', rate: RPS, timeUnit: '1s', duration: '10m', preAllocatedVUs: 200, maxVUs: 1000 },
    pico_campanha: { executor: 'ramping-arrival-rate', startTime: '10m30s', startRate: RPS, timeUnit: '1s', preAllocatedVUs: 500, maxVUs: 3000,
      stages: [{ target: RPS * 5, duration: '1m' }, { target: RPS * 5, duration: '3m' }, { target: RPS, duration: '1m' }] },
  },
  thresholds: {
    'http_req_duration{scenario:volume_sustentado}': [`p(95)<${__ENV.COE_P95_MS ?? 150}`],
    'http_req_duration{scenario:pico_campanha}': [`p(95)<${Number(__ENV.COE_P95_MS ?? 150) * 3}`],
    http_req_failed: [`rate<${__ENV.COE_ERRO_MAX ?? 0.001}`],
  },
  summaryTrendStats: ['avg', 'p(95)', 'p(99)', 'max'],
};

export default function () {
  const id = `r-ingest-${__VU}-${__ITER}-${Date.now()}`;
  const evento = {
    evento_id: id, tipo: 'pesquisa.respondida', versao_schema: 1,
    origem: { canal: 'android', cliente_ref: `sha256:${crypto.sha256(`cliente-${__VU}`, 'hex')}` },
    ocorrido_em: new Date().toISOString(),
    dados: { pesquisa_id: 'PESQ-NPS-APP', versao_pesquisa: 3, respostas: [{ pergunta_id: 'nota', tipo: 'escala', valor: 1 + (__ITER % 5) }] },
  };
  const r = http.post(`${__ENV.API_URL}/v1/eventos`, JSON.stringify(evento), {
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${__ENV.TOKEN_SERVICO}`, 'Idempotency-Key': id, 'X-Coe-Sintetico': 'true' },
  });
  check(r, { 'status 202': (x) => x.status === 202 });
}

#!/usr/bin/env node
// Consolida ZAP (JSON) + OWASP Dependency-Check (JSON) + MobSF (JSON) em artefatos/seguranca-release.json { criticas, altas, itens }
// Uso: node consolidar-release.mjs --zap zap.json --dc dependency-check-report.json --mobsf mobsf.json
import fs from 'node:fs';

const a = Object.fromEntries(process.argv.slice(2).reduce((acc, x, i, arr) => (x.startsWith('--') ? [...acc, [x.slice(2), arr[i + 1]]] : acc), []));
const ler = (f) => (f && fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : null);
const itens = [];

const zap = ler(a.zap);
for (const site of zap?.site ?? []) {
  for (const al of site.alerts ?? []) {
    // riskcode ZAP: 3 alto, 2 médio. Alto em DAST é tratado como crítico para o release.
    if (Number(al.riskcode) >= 3) itens.push({ fonte: 'zap', severidade: 'critica', id: al.pluginid, titulo: al.name });
    else if (Number(al.riskcode) === 2) itens.push({ fonte: 'zap', severidade: 'alta', id: al.pluginid, titulo: al.name });
  }
}

const dc = ler(a.dc);
for (const dep of dc?.dependencies ?? []) {
  for (const v of dep.vulnerabilities ?? []) {
    const sev = (v.severity ?? '').toUpperCase();
    if (sev === 'CRITICAL') itens.push({ fonte: 'dependency-check', severidade: 'critica', id: v.name, titulo: dep.fileName });
    else if (sev === 'HIGH') itens.push({ fonte: 'dependency-check', severidade: 'alta', id: v.name, titulo: dep.fileName });
  }
}

const mobsf = ler(a.mobsf);
for (const [chave, achado] of Object.entries(mobsf?.code_analysis?.findings ?? {})) {
  const sev = achado.metadata?.severity;
  if (sev === 'high') itens.push({ fonte: 'mobsf', severidade: 'alta', id: chave, titulo: achado.metadata?.description?.slice(0, 120) });
}

const saida = { criticas: itens.filter((i) => i.severidade === 'critica').length, altas: itens.filter((i) => i.severidade === 'alta').length, itens };
fs.mkdirSync('artefatos', { recursive: true });
fs.writeFileSync('artefatos/seguranca-release.json', JSON.stringify(saida, null, 2));
console.log(`Segurança (release): ${saida.criticas} crítica(s), ${saida.altas} alta(s).`);

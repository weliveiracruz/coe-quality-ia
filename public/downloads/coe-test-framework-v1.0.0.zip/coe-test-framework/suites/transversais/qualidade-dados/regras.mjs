// Regras de integridade ponta a ponta: o que o canal enviou ao BFF x o que a API de eventos gravou.
// Função pura (testada em core/cli/test). O executor fica em executar.mjs.
import { varrer } from '../../../core/cli/src/lib/privacidade.js';

export function compararRespostaEvento(resposta, evento) {
  const falhas = [];
  if (!evento) return ['evento não encontrado na API de eventos'];
  if (evento.evento_id !== resposta.resposta_id) falhas.push(`evento_id ${evento.evento_id} ≠ resposta_id ${resposta.resposta_id}`);
  if (evento.origem?.canal !== resposta.canal) falhas.push(`canal ${evento.origem?.canal} ≠ ${resposta.canal}`);
  if (!/^sha256:[a-f0-9]{64}$/.test(evento.origem?.cliente_ref ?? '')) falhas.push('cliente_ref não pseudonimizado');
  if (evento.dados?.pesquisa_id !== resposta.pesquisa_id) falhas.push('pesquisa_id divergente');
  if (evento.dados?.versao_pesquisa !== resposta.versao_pesquisa) falhas.push('versao_pesquisa divergente');

  const gravadas = new Map((evento.dados?.respostas ?? []).map((r) => [r.pergunta_id, r]));
  for (const r of resposta.respostas) {
    const g = gravadas.get(r.pergunta_id);
    if (!g) { falhas.push(`pergunta ${r.pergunta_id} perdida`); continue; }
    if (r.tipo !== 'texto' && g.valor !== r.valor) falhas.push(`pergunta ${r.pergunta_id}: ${JSON.stringify(g.valor)} ≠ ${JSON.stringify(r.valor)}`);
    if (r.tipo === 'texto' && varrer(r.valor).length > 0 && !g.anonimizado) falhas.push(`pergunta ${r.pergunta_id}: texto com dado pessoal não anonimizado`);
  }
  const pii = varrer(evento).filter((a) => a.tipo !== 'campo_proibido');
  if (pii.length) falhas.push(`dado pessoal gravado: ${[...new Set(pii.map((p) => p.tipo))].join(', ')}`);
  return falhas;
}

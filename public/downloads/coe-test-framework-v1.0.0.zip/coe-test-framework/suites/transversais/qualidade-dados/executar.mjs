#!/usr/bin/env node
// Qualidade de dados ponta a ponta (fechamento do pacote, janela 8h–20h).
// Envia respostas sintéticas por cada canal ao BFF de homologação e confere se chegaram íntegras à API de eventos.
// Variáveis: BFF_URL, API_URL, TOKEN (canal), TOKEN_SERVICO (consulta na API), QTD_POR_CANAL (padrão 5)
// Saída: artefatos/qualidade-dados.json e resultados/qualidade_dados/junit.xml
import fs from 'node:fs';
import { compararRespostaEvento } from './regras.mjs';

const { BFF_URL, API_URL, TOKEN, TOKEN_SERVICO } = process.env;
const QTD = Number(process.env.QTD_POR_CANAL ?? 5);
const CANAIS = ['android', 'ios', 'webview', 'web'];
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

async function enviar(resposta) {
  const t0 = Date.now();
  const r = await fetch(`${BFF_URL}/bff/pesquisa/v1/respostas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${TOKEN}`, 'Idempotency-Key': resposta.resposta_id, 'X-Coe-Sintetico': 'true' },
    body: JSON.stringify(resposta),
  });
  return { status: r.status, enviadoEm: t0 };
}

async function buscarEvento(id, limiteMs = 60_000) {
  const fim = Date.now() + limiteMs;
  while (Date.now() < fim) {
    const r = await fetch(`${API_URL}/v1/eventos/${id}`, { headers: { Authorization: `Bearer ${TOKEN_SERVICO}` } });
    if (r.status === 200) return { evento: await r.json(), chegouEm: Date.now() };
    await esperar(2000);
  }
  return { evento: null, chegouEm: null };
}

const casos = [];
for (const canal of CANAIS) {
  for (let i = 0; i < QTD; i++) {
    const comCpf = i === 0; // um caso por canal com dado pessoal no texto, para conferir a anonimização
    const resposta = {
      pesquisa_id: 'PESQ-NPS-APP', versao_pesquisa: 3, canal, resposta_id: `r-qd-${canal}-${Date.now()}-${i}`,
      respostas: [
        { pergunta_id: 'nota', tipo: 'escala', valor: 1 + (i % 5) },
        { pergunta_id: 'motivo', tipo: 'texto', valor: comCpf ? 'meu cpf é 529.982.247-25' : `teste de qualidade ${i}` },
      ],
      contexto: { jornada: 'qualidade-dados', plataforma: canal },
    };
    casos.push({ canal, resposta, ...(await enviar(resposta)) });
  }
}

const resultados = [];
for (const c of casos) {
  const { evento, chegouEm } = c.status < 300 ? await buscarEvento(c.resposta.resposta_id) : { evento: null };
  const falhas = c.status < 300 ? compararRespostaEvento(c.resposta, evento) : [`BFF respondeu ${c.status}`];
  resultados.push({ canal: c.canal, resposta_id: c.resposta.resposta_id, latencia_ms: chegouEm ? chegouEm - c.enviadoEm : null, falhas });
}

const resumo = {
  total: resultados.length,
  integras: resultados.filter((r) => r.falhas.length === 0).length,
  latencia_p95_ms: (() => { const l = resultados.map((r) => r.latencia_ms).filter(Boolean).sort((a, b) => a - b); return l[Math.floor(l.length * 0.95)] ?? null; })(),
  resultados,
};
fs.mkdirSync('artefatos', { recursive: true });
fs.writeFileSync('artefatos/qualidade-dados.json', JSON.stringify(resumo, null, 2));

const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<testsuite name="qualidade-dados" tests="${resultados.length}" failures="${resultados.length - resumo.integras}">\n${resultados.map((r) =>
  `  <testcase classname="qualidade_dados.${r.canal}" name="CEN-TRV-003 ${r.resposta_id}">${r.falhas.length ? `<failure message="${r.falhas.join('; ').replace(/"/g, "'")}"/>` : ''}</testcase>`).join('\n')}\n</testsuite>\n`;
fs.mkdirSync('resultados/qualidade_dados', { recursive: true });
fs.writeFileSync('resultados/qualidade_dados/junit.xml', xml);

console.log(`Qualidade de dados: ${resumo.integras}/${resumo.total} íntegras, p95 de chegada ${resumo.latencia_p95_ms} ms.`);
process.exit(resumo.integras === resumo.total ? 0 : 1);

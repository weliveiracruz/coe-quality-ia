# Suítes transversais do CoE

Valem para todas as squads e são mantidas pelo CoE. As squads herdam sem precisar escrever os cenários de `catalogo-transversal.yml`.

| Suíte | Onde fica a implementação | Momento |
|---|---|---|
| **Privacidade e LGPD** | Scanner `coe-test privacidade` sobre `artefatos/eventos/` (gerado pelos testes de cada stack), `fs-mask` e marcação de campo sensível, anonimização no BFF, validação na API | PR (runner) |
| **Resiliência** | Nível serviço: `stacks/kotlin-bff/template/resiliencia` (WireMock). Nível ambiente: `resiliencia/` (Toxiproxy + k6) | PR e fechamento do pacote |
| **Rede instável no mobile** | `stacks/android-compose/.../FilaOfflineTest.kt`, `stacks/ios-swiftui/Transversais/`, `stacks/web-e2e/tests/webview/ponte.spec.ts` | PR (runner/emulador) |
| **Qualidade de dados ponta a ponta** | `qualidade-dados/` (canal → BFF → API, por canal) | Fechamento do pacote |
| **Smoke sintético em produção** | `smoke/` (Playwright, a cada 15 min, o dia todo) | Contínuo |
| **Performance** | `performance/` (k6 com SLOs do `coe-test.yml`) | Fechamento do pacote |
| **Segurança** | `seguranca/` (Semgrep, Gitleaks, ZAP, consolidação) + Dependency-Check e MobSF nos workflows | PR (estático) e release (DAST) |

## Privacidade: como o scanner funciona
Cada stack grava os eventos de analytics capturados nos testes em `artefatos/eventos/*.json`. O comando `coe-test privacidade --entrada artefatos/eventos` procura:
- CPF com dígito verificador válido
- CNPJ, e-mail e telefone celular
- cartão que passa no Luhn
- campos proibidos em claro (`cpf`, `senha`, `saldo`, `agencia`, `conta`...)

Uma ocorrência já reprova o gate (`pii_ocorrencias_max: 0`).

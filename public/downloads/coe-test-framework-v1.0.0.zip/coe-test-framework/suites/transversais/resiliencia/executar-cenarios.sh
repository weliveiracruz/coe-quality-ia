#!/usr/bin/env bash
# Aplica falhas na API de eventos via Toxiproxy e roda o k6 de resiliência em cada uma.
# Saída: artefatos/resiliencia-<cenario>.json e resultado agregado em artefatos/resiliencia.json
set -euo pipefail
TOXI=${TOXIPROXY_URL:-http://localhost:8474}
DIR=$(cd "$(dirname "$0")" && pwd)
mkdir -p artefatos

limpar() { curl -s -X POST "$TOXI/reset" >/dev/null; }
toxico() { curl -s -X POST "$TOXI/proxies/api_eventos/toxics" -d "$1" >/dev/null; }

declare -A CENARIOS=(
  [latencia_3s]='{"type":"latency","attributes":{"latency":3000,"jitter":500}}'
  [timeout_total]='{"type":"timeout","attributes":{"timeout":0}}'
  [banda_estreita]='{"type":"bandwidth","attributes":{"rate":8}}'
  [reset_conexao]='{"type":"reset_peer","attributes":{"timeout":100}}'
)

resultado='{}'
for nome in "${!CENARIOS[@]}"; do
  limpar
  toxico "${CENARIOS[$nome]}"
  echo ">> Cenário de resiliência: $nome"
  if k6 run -e CENARIO_FALHA="$nome" --summary-export "artefatos/resiliencia-$nome.json" "$DIR/resiliencia.k6.js"; then st=aprovado; else st=reprovado; fi
  resultado=$(echo "$resultado" | jq --arg n "$nome" --arg s "$st" '. + {($n): $s}')
done
# Recuperação: sem falhas, o circuito precisa fechar e o fluxo normalizar
limpar
k6 run -e CENARIO_FALHA=recuperacao --summary-export artefatos/resiliencia-recuperacao.json "$DIR/resiliencia.k6.js" && rec=aprovado || rec=reprovado
echo "$resultado" | jq --arg s "$rec" '. + {recuperacao: $s}' > artefatos/resiliencia.json
cat artefatos/resiliencia.json
jq -e 'all(.[]; . == "aprovado")' artefatos/resiliencia.json >/dev/null

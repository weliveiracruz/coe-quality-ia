// Mede o que o CANAL vê enquanto a API de eventos sofre a falha aplicada pelo Toxiproxy.
// Regra do CoE: a pesquisa nunca recebe 5xx bruto nem espera além do limite; aceita 201/202, ou 503 com Retry-After.
import http from 'k6/http';
import { check } from 'k6';

const LIMITE_MS = Number(__ENV.COE_LIMITE_RESPOSTA_MS ?? 8000);

export const options = {
  scenarios: { canais: { executor: 'constant-arrival-rate', rate: 10, timeUnit: '1s', duration: '2m', preAllocatedVUs: 20, maxVUs: 100 } },
  thresholds: {
    'checks{verificacao:sem_5xx_bruto}': ['rate==1'],
    'checks{verificacao:tempo_limite}': ['rate>0.99'],
    ...(__ENV.CENARIO_FALHA === 'recuperacao' ? { 'checks{verificacao:recuperou}': ['rate>0.98'] } : {}),
  },
};

export default function () {
  const id = `r-resil-${__VU}-${__ITER}-${Date.now()}`;
  const r = http.post(`${__ENV.BFF_URL}/bff/pesquisa/v1/respostas`, JSON.stringify({
    pesquisa_id: 'PESQ-NPS-APP', versao_pesquisa: 3, canal: 'android', resposta_id: id,
    respostas: [{ pergunta_id: 'nota', tipo: 'escala', valor: 4 }],
  }), { headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${__ENV.TOKEN}`, 'Idempotency-Key': id, 'X-Coe-Sintetico': 'true' }, timeout: '15s' });

  check(r, { sem_5xx_bruto: (x) => [201, 202].includes(x.status) || (x.status === 503 && !!x.headers['Retry-After']) }, { verificacao: 'sem_5xx_bruto' });
  check(r, { tempo_limite: (x) => x.timings.duration < LIMITE_MS }, { verificacao: 'tempo_limite' });
  if (__ENV.CENARIO_FALHA === 'recuperacao') check(r, { recuperou: (x) => x.status === 201 }, { verificacao: 'recuperou' });
}

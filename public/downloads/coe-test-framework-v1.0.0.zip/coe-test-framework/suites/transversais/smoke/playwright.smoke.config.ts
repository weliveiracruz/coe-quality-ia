import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: '.',
  testMatch: 'smoke-producao.spec.ts',
  retries: 2, // produção: evita alarme falso por oscilação pontual
  timeout: 30_000,
  reporter: [['list'], ['junit', { outputFile: '../../../resultados/smoke/junit.xml' }]],
  use: { locale: 'pt-BR', trace: 'retain-on-failure' },
});

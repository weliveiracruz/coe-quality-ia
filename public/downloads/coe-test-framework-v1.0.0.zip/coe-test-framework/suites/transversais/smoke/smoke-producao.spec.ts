// Smoke sintético em PRODUÇÃO (roda o dia todo, a cada 15 min; produção não desliga).
// Curto e não intrusivo: confere que a pesquisa carrega e que o BFF responde ao health check.
// Não envia respostas reais. Se COE_SMOKE_ENVIO=1, envia UMA resposta marcada como sintética (X-Coe-Sintetico),
// que o BFF descarta antes da API de eventos.
import { test, expect } from '@playwright/test';

const URL_PESQUISA = process.env.COE_SMOKE_URL!;      // ex.: https://bankline.itau.com.br/pesquisa/satisfacao?sintetico=1
const BFF_HEALTH = process.env.COE_SMOKE_BFF_HEALTH!; // ex.: https://bff-pesquisa.itau.com.br/actuator/health

test('SMOKE pesquisa carrega em produção', async ({ page }) => {
  const resp = await page.goto(URL_PESQUISA);
  expect(resp?.status()).toBeLessThan(400);
  await expect(page.getByRole('heading', { name: 'Pesquisa de satisfação' })).toBeVisible({ timeout: 10_000 });
  await expect(page.getByRole('radio')).toHaveCount(5);
});

test('SMOKE BFF de pesquisa saudável', async ({ request }) => {
  const r = await request.get(BFF_HEALTH);
  expect(r.status()).toBe(200);
  expect((await r.json()).status).toBe('UP');
});

test('SMOKE envio sintético', async ({ page }) => {
  test.skip(process.env.COE_SMOKE_ENVIO !== '1', 'envio sintético desligado');
  await page.setExtraHTTPHeaders({ 'X-Coe-Sintetico': 'true' });
  await page.goto(URL_PESQUISA);
  await page.getByRole('radio', { name: /5 de 5/ }).check();
  await page.getByRole('button', { name: 'Enviar' }).click();
  await expect(page.getByRole('status')).toBeVisible();
});

package br.com.itau.analytics.bump

import android.os.SystemClock
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import br.com.itau.analytics.AnalyticsSdk          // wrapper da squad (Firebase + FullStory)
import br.com.itau.analytics.AnalyticsConfig
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Regressão de bump do FullStory encapsulado no SDK de Analytics (Android).
 * Roda em todo PR do Dependabot que muda a versão do FullStory (ou do BoM do Firebase).
 * Gera build/coe-bump/atual.json, comparado com a baseline por "coe-test bump".
 */
@RunWith(AndroidJUnit4::class)
class WrapperFullStoryBumpTest {

    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext
    private val medicoes = JSONObject()

    @Test
    fun bump01_compilaEInicializaComFirebaseEFullStory() {
        val tempos = (1..5).map {
            AnalyticsSdk.resetParaTeste()
            val t0 = SystemClock.elapsedRealtimeNanos()
            AnalyticsSdk.inicializar(ctx, AnalyticsConfig(modoDebug = true))
            (SystemClock.elapsedRealtimeNanos() - t0) / 1_000_000.0
        }.sorted()
        check(AnalyticsSdk.inicializado) { "SDK de Analytics não inicializou com o FullStory novo" }
        registrar("inicializou", true)
        registrar("inicializacao_ms_p50", tempos[tempos.size / 2])
    }

    @Test
    fun bump02_sessaoFullStoryCapturada() {
        AnalyticsSdk.inicializar(ctx, AnalyticsConfig(modoDebug = true))
        val latch = CountDownLatch(1)
        var url: String? = null
        AnalyticsSdk.aoIniciarSessaoFullStory { url = it; latch.countDown() }
        latch.await(20, TimeUnit.SECONDS)
        registrar("sessao_capturada", url?.startsWith("https://") == true)
        check(url != null) { "FullStory não iniciou sessão em 20s" }
    }

    @Test
    fun bump03_eventosDoFirebaseSeguemSaindo() {
        AnalyticsSdk.inicializar(ctx, AnalyticsConfig(modoDebug = true))
        val capturados = mutableListOf<String>()
        AnalyticsSdk.observadorDeTeste = { nome, _ -> capturados += nome } // gancho do wrapper em modo debug
        AnalyticsSdk.registrar("coe_bump_teste", mapOf("origem" to "suite-bump"))
        registrar("firebase_eventos_ok", "coe_bump_teste" in capturados)
        check("coe_bump_teste" in capturados) { "Evento não chegou ao Firebase com o FullStory novo" }
    }

    @Test
    fun bump04_wrapperRepassaIdentificacaoPseudonimizada() {
        AnalyticsSdk.inicializar(ctx, AnalyticsConfig(modoDebug = true))
        val enviados = mutableListOf<Map<String, Any?>>()
        AnalyticsSdk.observadorDeTeste = { nome, p -> enviados += mapOf("evento" to nome) + p }
        AnalyticsSdk.identificar(idCliente = "52998224725")
        val dir = File(ctx.externalCacheDir, "coe/eventos").apply { mkdirs() }
        File(dir, "bump-identificacao.json").writeText(JSONArray(enviados.map { JSONObject(it) }).toString())
        check(enviados.none { it.values.any { v -> v.toString().contains("52998224725") } }) { "CPF em claro no identify" }
    }

    private fun registrar(chave: String, valor: Any) {
        val arq = File(ctx.externalCacheDir, "coe-bump/atual.json").apply { parentFile?.mkdirs() }
        val atual = if (arq.exists()) JSONObject(arq.readText()) else JSONObject()
        atual.put(chave, valor)
        arq.writeText(atual.toString(2))
    }
}

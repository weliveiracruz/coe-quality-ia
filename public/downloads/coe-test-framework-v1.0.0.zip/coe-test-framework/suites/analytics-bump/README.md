# Suíte de bump do FullStory (SDK de Analytics)

O FullStory fica **encapsulado** no SDK de Analytics, que também usa o Firebase. A única coisa a testar nele é se um bump de versão do FullStory quebra o wrapper. Esta suíte faz isso no Android e no iOS.

## Quando roda
1. O Dependabot abre o PR de bump (modelo em `dependabot.exemplo.yml`, que agrupa FullStory e BoM do Firebase).
2. O label `coe-analytics-bump` dispara o workflow `analytics-bump.yml`.
3. O merge só libera com todas as verificações verdes. O PR recebe a tabela de comparação.

## O que é verificado
| Verificação | Como | Limite |
|---|---|---|
| Compila e inicializa | Teste instrumentado inicializa o wrapper 5 vezes | Precisa inicializar |
| API pública do wrapper | Android: `binary-compatibility-validator` (`apiDump`/`apiCheck`). iOS: `swift-api-digester` | Nenhuma assinatura removida |
| Convivência com o Firebase | Evento de teste observado no modo debug | Precisa chegar |
| Captura de sessão | Callback de sessão do FullStory com URL | Em até 20 s |
| Tamanho do pacote | `apkanalyzer` (AAR/APK) e tamanho do framework no iOS | Até +5% |
| Tempo de inicialização | p50 de 5 inicializações (e `XCTMetric` no iOS) | Até +10% |
| Privacidade | Identificação pseudonimizada, sem CPF | Zero ocorrências |

Os limites ficam em `core/cli/src/lib/bump.js` (`LIMITES_PADRAO`).

## Arquivos
- `android/WrapperFullStoryBumpTest.kt` e `ios/WrapperFullStoryBumpTests.swift`: os testes. Adapte os nomes do wrapper (`AnalyticsSdk`).
- `scripts/montar-bump-json.mjs`: junta medições, tamanho, API e JUnit num JSON.
- `baseline/`: medições da versão atual em produção. Atualizadas automaticamente quando o bump é aprovado e mergeado.

## Comparação local
```
node core/cli/bin/coe-test.js bump --base suites/analytics-bump/baseline/android.exemplo.json --atual artefatos/bump-atual.json
```

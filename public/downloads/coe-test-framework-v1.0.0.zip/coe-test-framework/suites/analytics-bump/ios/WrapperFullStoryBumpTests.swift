import XCTest
@testable import AnalyticsSDK // wrapper da squad (Firebase + FullStory)

/// Regressão de bump do FullStory encapsulado no SDK de Analytics (iOS).
/// Gera coe-bump/atual.json (no diretório de cache do teste), comparado com a baseline por "coe-test bump".
final class WrapperFullStoryBumpTests: XCTestCase {

    private func registrar(_ chave: String, _ valor: Any) throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("coe-bump", isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let arq = dir.appendingPathComponent("atual.json")
        var atual = (try? JSONSerialization.jsonObject(with: Data(contentsOf: arq))) as? [String: Any] ?? [:]
        atual[chave] = valor
        try JSONSerialization.data(withJSONObject: atual, options: .prettyPrinted).write(to: arq)
    }

    func test_bump01_inicializaComFirebaseEFullStory() throws {
        var tempos: [Double] = []
        for _ in 0..<5 {
            AnalyticsSDK.resetParaTeste()
            let t0 = CFAbsoluteTimeGetCurrent()
            AnalyticsSDK.inicializar(config: .init(modoDebug: true))
            tempos.append((CFAbsoluteTimeGetCurrent() - t0) * 1000)
        }
        XCTAssertTrue(AnalyticsSDK.inicializado)
        try registrar("inicializou", AnalyticsSDK.inicializado)
        try registrar("inicializacao_ms_p50", tempos.sorted()[tempos.count / 2])
    }

    /// Mede também com XCTMetric para acompanhar a tendência no Xcode Cloud/relatório.
    func test_bump01b_metricaDeInicializacao() {
        measure(metrics: [XCTClockMetric(), XCTMemoryMetric()]) {
            AnalyticsSDK.resetParaTeste()
            AnalyticsSDK.inicializar(config: .init(modoDebug: true))
        }
    }

    func test_bump02_sessaoFullStoryCapturada() throws {
        AnalyticsSDK.inicializar(config: .init(modoDebug: true))
        let exp = expectation(description: "sessão FullStory")
        var url: String?
        AnalyticsSDK.aoIniciarSessaoFullStory { url = $0; exp.fulfill() }
        wait(for: [exp], timeout: 20)
        try registrar("sessao_capturada", url?.hasPrefix("https://") == true)
    }

    func test_bump03_eventosDoFirebaseSeguemSaindo() throws {
        AnalyticsSDK.inicializar(config: .init(modoDebug: true))
        var capturados: [String] = []
        AnalyticsSDK.observadorDeTeste = { nome, _ in capturados.append(nome) }
        AnalyticsSDK.registrar("coe_bump_teste", parametros: ["origem": "suite-bump"])
        try registrar("firebase_eventos_ok", capturados.contains("coe_bump_teste"))
        XCTAssertTrue(capturados.contains("coe_bump_teste"))
    }
}

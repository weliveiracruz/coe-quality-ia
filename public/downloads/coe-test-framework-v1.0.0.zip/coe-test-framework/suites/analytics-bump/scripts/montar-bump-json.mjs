#!/usr/bin/env node
// Monta o JSON "atual" da suíte de bump juntando: medições do teste instrumentado, tamanho do pacote,
// assinaturas da API pública e resultado JUnit. Saída consumida por: coe-test bump --base baseline.json --atual atual.json
//
// Uso:
//   node montar-bump-json.mjs --medicoes atual-device.json --tamanho <bytes> --api api.txt \
//        --junit resultados/bump --versao-fullstory 1.54.0 --saida artefatos/bump-atual.json
import fs from 'node:fs';
import path from 'node:path';

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => (a.startsWith('--') ? [...acc, [a.slice(2), arr[i + 1]]] : acc), []));

function contarJunit(dir) {
  let total = 0, falharam = 0;
  const visitar = (p) => {
    if (!fs.existsSync(p)) return;
    if (fs.statSync(p).isDirectory()) return fs.readdirSync(p).forEach((f) => visitar(path.join(p, f)));
    if (!p.endsWith('.xml')) return;
    const xml = fs.readFileSync(p, 'utf8');
    total += (xml.match(/<testcase\b/g) ?? []).length;
    falharam += (xml.match(/<(failure|error)\b/g) ?? []).length;
  };
  visitar(dir);
  return { total, falharam };
}

const medicoes = JSON.parse(fs.readFileSync(args.medicoes, 'utf8'));
// api.txt: uma assinatura pública por linha (gerado por apiDump no Android ou swift-api-digester no iOS)
const api = fs.readFileSync(args.api, 'utf8').split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('//'));

const atual = {
  versao_fullstory: args['versao-fullstory'],
  tamanho_bytes: Number(args.tamanho),
  inicializacao_ms_p50: medicoes.inicializacao_ms_p50,
  inicializou: medicoes.inicializou === true,
  firebase_eventos_ok: medicoes.firebase_eventos_ok === true,
  sessao_capturada: medicoes.sessao_capturada === true,
  api_publica: api,
  testes: contarJunit(args.junit),
};
fs.mkdirSync(path.dirname(args.saida), { recursive: true });
fs.writeFileSync(args.saida, JSON.stringify(atual, null, 2));
console.log(`Bump JSON gravado em ${args.saida}`);

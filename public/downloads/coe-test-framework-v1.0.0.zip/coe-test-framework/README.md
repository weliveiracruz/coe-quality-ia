# CoE Test Framework

Framework único do CoE para as squads testarem do mesmo jeito em todas as stacks. A squad declara stack, produto e camadas num arquivo (`coe-test.yml`). O framework entrega pipeline, quality gates, relatórios, catálogo de cenários e integração com o IU Click.

## Arquitetura coberta
```
Android (Compose) ──┐
iOS (SwiftUI) ──────┤
WebView (Angular/React) ─┼──> BFF Kotlin (token, camadas) ──> API de eventos .NET
Web: Bankline e outras ──┘
SDK de Analytics (Firebase + FullStory encapsulado) ──> suíte de bump do FullStory
```

## Estrutura
| Pasta | Conteúdo |
|---|---|
| `core/` | CLI `coe-test`, padrões do CoE, schemas, massa de dados sintética, padrões de nomenclatura, quality gate do SonarQube |
| `stacks/` | Templates por tecnologia: `android-compose`, `ios-swiftui`, `kotlin-bff`, `dotnet-api`, `angular`, `react` e `web-e2e` (Playwright, compartilhado por Angular e React) |
| `products/` | Um por produto: `modulo-pesquisa`, `bff-kotlin`, `api-eventos`, cada um com catálogo de cenários; espaço para novos |
| `suites/analytics-bump/` | Regressão de bump do FullStory dentro do SDK de Analytics (Android e iOS) |
| `suites/transversais/` | Privacidade/LGPD, resiliência, rede instável, qualidade de dados, smoke em produção, performance e segurança |
| `platforms/web/perfis/` | Perfis das plataformas web (Bankline + modelo em branco) |
| `contracts/` | Contratos versionados (schemas + pacts) nas camadas canais → BFF e BFF → API |
| `.github/` | Workflows reutilizáveis (pipeline, stacks, release, bump, smoke) e actions compostas |
| `portal/` | Portal web do CoE (WCAG 2.2 AA): cadastro de squad, perfis web, painel e catálogo |
| `docs/` | Estratégia, DoD, guias, playbooks, governança |
| `examples/` | `coe-test.yml` de exemplo para cada tipo de squad e métricas de exemplo |

## Início rápido (squad nova)
```bash
npx github:itau-coe/coe-test-framework#v1 init --stack react --produto modulo-pesquisa --squad "Minha Squad" --canais web,webview
npx github:itau-coe/coe-test-framework#v1 validate
git add coe-test.yml coe-tests .github && git commit -m "chore: adota CoE Test Framework" && git push
```
Ou cadastre a squad pelo portal (`portal/index.html`), que gera os mesmos arquivos e abre o pull request.

O passo a passo completo está em `docs/guia-adocao.md`.

## Como os testes rodam (FinOps: ambiente das 8h às 20h)
| Momento | O que roda | Onde |
|---|---|---|
| A qualquer hora, a cada PR | Lint, unitário, contrato, mutação, segurança estática, privacidade, SonarQube | Runner do GitHub |
| Dentro da janela 8h–20h | Integração com ambiente, E2E/UI, acessibilidade, visual | Ambiente de homologação. Fora do horário, fica pendente e dispara às 8h05 |
| Fechamento do pacote para produção | Performance (k6), OWASP ZAP, device farm, resiliência, qualidade de dados | Só inicia se terminar antes das 20h |
| Contínuo | Smoke sintético em produção | A cada 15 min |

## Comandos do CLI
```
coe-test init | validate | plano | janela | catalogo validar|paridade | esqueleto | privacidade
coe-test gates | metricas | contrato | payloads | iuclick | bump | devicefarm | portal
```
Rode `coe-test ajuda` para ver os parâmetros.

## Desenvolvimento do framework
```bash
npm ci && npm test            # testes do CLI
npm run validate:all          # configurações de exemplo
node core/cli/bin/coe-test.js portal   # atualiza os dados do portal
```
Versões seguem SemVer com tags (`v1`, `v1.1.0`). As squads fixam a versão no workflow (`@v1`). Mudanças que quebram compatibilidade vêm com guia de migração no `CHANGELOG.md`.

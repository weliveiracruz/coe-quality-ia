import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: '.',
  reporter: [['list'], ['junit', { outputFile: '../../resultados/portal/junit.xml' }]],
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'], ...(process.env.COE_CHROME_CANAL ? { channel: process.env.COE_CHROME_CANAL } : {}) } }],
});

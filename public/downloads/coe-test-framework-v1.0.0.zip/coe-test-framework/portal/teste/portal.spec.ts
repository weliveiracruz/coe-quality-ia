// O portal do CoE testado com o próprio padrão que ele cobra das squads: WCAG 2.2 AA com axe + teclado.
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import path from 'node:path';

const URL = `file://${path.resolve(__dirname, '../index.html')}`;
const TAGS = ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa'];

async function semViolacoes(page) {
  const r = await new AxeBuilder({ page }).withTags(TAGS).analyze();
  expect(r.violations.map((v) => `${v.id} (${v.impact}): ${v.nodes.map((n) => n.target.join(' ')).join(' | ')}`)).toEqual([]);
}

test('todas as seções sem violações WCAG 2.2 AA', async ({ page }) => {
  for (const secao of ['onboarding', 'perfil-web', 'painel', 'catalogo']) {
    await page.goto(`${URL}#${secao}`);
    await semViolacoes(page);
  }
});

test('erro de validação leva o foco ao resumo e o link ao campo', async ({ page }) => {
  await page.goto(`${URL}#onboarding`);
  await page.getByRole('button', { name: 'Gerar configuração' }).click();
  const resumo = page.locator('#erros-onboarding');
  await expect(resumo).toBeFocused();
  await expect(page.getByLabel('Nome da squad (obrigatório)')).toHaveAttribute('aria-invalid', 'true');
  await resumo.getByRole('link').first().click();
  await expect(page.getByLabel('Nome da squad (obrigatório)')).toBeFocused();
  await semViolacoes(page);
});

test('cadastro gera coe-test.yml com status do IU Click parametrizados', async ({ page }) => {
  await page.goto(`${URL}#onboarding`);
  await page.getByLabel('Nome da squad (obrigatório)').fill('Squad Teste Portal');
  await page.getByLabel('Repositório da squad (org/repo)').fill('itau-pesquisa/app-web');
  await page.getByLabel('Stack').selectOption('react');
  await page.getByLabel('Gravar o resultado dos testes nas histórias').check();
  await page.getByLabel('Status quando os gates passam').fill('Homologado');
  await page.getByRole('button', { name: 'Gerar configuração' }).click();
  await expect(page.getByRole('heading', { name: 'Configuração gerada' })).toBeFocused();
  const yml = await page.locator('#yml-saida').textContent();
  expect(yml).toContain('stack: react');
  expect(yml).toContain('aprovado: Homologado');
  expect(yml).toContain('perfis_web: [bankline]');
  await expect(page.getByRole('link', { name: /Abrir pull request/ })).toHaveAttribute('href', /github\.com\/itau-pesquisa\/app-web\/new\/main\?filename=coe-test\.yml/);
  await semViolacoes(page);
});

test('navegação por teclado entre seções move o foco para o título', async ({ page }) => {
  await page.goto(`${URL}#onboarding`);
  await page.getByRole('link', { name: 'Painel de qualidade' }).focus();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { level: 1, name: 'Painel de qualidade por squad' })).toBeFocused();
  await expect(page.getByRole('link', { name: 'Painel de qualidade' })).toHaveAttribute('aria-current', 'page');
});

test('painel e catálogo exibem os dados embutidos', async ({ page }) => {
  await page.goto(`${URL}#painel`);
  await expect(page.getByRole('row', { name: /Squad Pesquisa Web/ })).toContainText('Ouro');
  await page.goto(`${URL}#catalogo`);
  await expect(page.locator('#cat-produto')).toHaveValue('modulo-pesquisa');
  await expect(page.getByText('CEN-PESQ-001 Responder nota e enviar')).toBeVisible();
  await page.locator('#cat-produto').selectOption('bff-kotlin');
  await expect(page.getByText('CEN-BFF-011 Token expirado retorna 401 sem chamar a API')).toBeVisible();
});

test('reflow: 320 px de largura sem rolagem horizontal da página', async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 640 });
  await page.goto(`${URL}#onboarding`);
  const rola = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
  expect(rola).toBe(false);
});

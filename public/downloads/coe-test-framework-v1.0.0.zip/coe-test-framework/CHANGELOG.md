# Changelog

## v1.0.0 — 2026-11-20
Primeira versão do CoE Test Framework.

- **CLI `coe-test`:**
  - comandos init, validate, plano, janela, catálogo e paridade, esqueleto, privacidade, gates, métricas, contrato, payloads, IU Click, bump, device farm e portal
  - testes automatizados do próprio CLI
- **Templates por stack:** Android (Compose), iOS (SwiftUI), BFF Kotlin, API .NET, Angular e React, além do E2E web compartilhado (Playwright) com demo local.
- **Produtos:** módulo de pesquisa (nativo, WebView e web), BFF Kotlin e API de eventos, com catálogos de cenários.
- **Contratos versionados** (schemas + pacts) em duas camadas, sem broker.
- **Suítes:**
  - bump do FullStory (Android e iOS)
  - transversais: LGPD, resiliência, rede instável, qualidade de dados, smoke, performance e segurança
- **Workflows reutilizáveis:**
  - janela 8h–20h com fila das 8h05
  - fechamento do pacote com suítes pesadas
  - SonarQube interno, Allure e JSON de métricas
  - device farm com adaptador genérico
- **Integração com o IU Click** via MCP, com status e movimentação parametrizáveis por squad.
- **Portal web** (WCAG 2.2 AA): cadastro de squad, perfis web, painel e catálogo.
- **Documentação:** estratégia, DoD, guia de adoção, janela, cenários e IU Click, playbooks e governança.

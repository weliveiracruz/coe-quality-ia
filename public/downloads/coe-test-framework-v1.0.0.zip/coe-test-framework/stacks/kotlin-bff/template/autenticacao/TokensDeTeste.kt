package br.com.itau.bff.pesquisa.autenticacao

import io.jsonwebtoken.Jwts
import io.jsonwebtoken.security.Keys
import java.time.Instant
import java.util.Date

/**
 * Tokens assinados com a chave do perfil "coe-teste" (application-coe-teste.yml do BFF deve apontar para a mesma chave).
 * Nunca usar tokens ou chaves reais em teste.
 */
object TokensDeTeste {
    private val chave = Keys.hmacShaKeyFor("coe-chave-de-teste-somente-local-0123456789abcdef".toByteArray())
    private val outraChave = Keys.hmacShaKeyFor("chave-errada-para-teste-de-assinatura-0123456789".toByteArray())

    private fun gerar(expiraEm: Instant, audiencia: String = "bff-pesquisa", assinatura: javax.crypto.SecretKey = chave) =
        Jwts.builder().subject("cliente-teste").audience().add(audiencia).and()
            .issuedAt(Date.from(Instant.now())).expiration(Date.from(expiraEm))
            .signWith(assinatura).compact()

    fun valido() = gerar(Instant.now().plusSeconds(3600))
    fun expirado() = gerar(Instant.now().minusSeconds(60))
    fun assinaturaInvalida() = gerar(Instant.now().plusSeconds(3600), assinatura = outraChave)
    fun outraAudiencia() = gerar(Instant.now().plusSeconds(3600), audiencia = "outro-servico")
}

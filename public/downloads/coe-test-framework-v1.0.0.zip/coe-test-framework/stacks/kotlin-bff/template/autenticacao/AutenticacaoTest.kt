package br.com.itau.bff.pesquisa.autenticacao

import com.github.tomakehurst.wiremock.client.WireMock.aResponse
import com.github.tomakehurst.wiremock.client.WireMock.post
import com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor
import com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo
import com.github.tomakehurst.wiremock.junit5.WireMockExtension
import io.restassured.RestAssured.given
import io.restassured.http.ContentType
import org.hamcrest.Matchers.equalTo
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.RegisterExtension
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.test.context.DynamicPropertyRegistry
import org.springframework.test.context.DynamicPropertySource

/**
 * Suíte de autenticação do BFF: token válido, expirado, inválido e ausente (CEN-TRV-005 no lado do serviço).
 * A API de eventos é simulada com WireMock; o validador de token usa a chave de teste (perfil "coe-teste").
 * Roda no runner, sem ambiente.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = ["spring.profiles.active=coe-teste"])
class AutenticacaoTest {

    companion object {
        @JvmField @RegisterExtension
        val apiEventos: WireMockExtension = WireMockExtension.newInstance().build()

        @JvmStatic @DynamicPropertySource
        fun props(r: DynamicPropertyRegistry) = r.add("api-eventos.url") { apiEventos.baseUrl() }
    }

    @LocalServerPort var porta = 0
    private val corpo = """{"pesquisa_id":"PESQ-NPS-APP","versao_pesquisa":3,"canal":"web","resposta_id":"r-0000000001","respostas":[{"pergunta_id":"nota","tipo":"escala","valor":5}]}"""

    @BeforeEach
    fun setup() = apiEventos.stubFor(post("/v1/eventos").willReturn(aResponse().withStatus(202)))

    private fun enviar(authorization: String?) = given().port(porta).contentType(ContentType.JSON)
        .apply { authorization?.let { header("Authorization", it) } }
        .header("Idempotency-Key", "r-0000000001").body(corpo)
        .post("/bff/pesquisa/v1/respostas")

    @Test
    fun CEN_BFF_010_tokenValidoEncaminhaParaApi() {
        enviar("Bearer ${TokensDeTeste.valido()}").then().statusCode(201)
        apiEventos.verify(1, postRequestedFor(urlEqualTo("/v1/eventos")))
    }

    @Test
    fun CEN_BFF_011_tokenExpiradoRetorna401SemChamarApi() {
        enviar("Bearer ${TokensDeTeste.expirado()}").then().statusCode(401).body("codigo", equalTo("TOKEN_EXPIRADO"))
        apiEventos.verify(0, postRequestedFor(urlEqualTo("/v1/eventos")))
    }

    @Test
    fun CEN_BFF_012_tokenComAssinaturaInvalidaRetorna401() {
        enviar("Bearer ${TokensDeTeste.assinaturaInvalida()}").then().statusCode(401)
        apiEventos.verify(0, postRequestedFor(urlEqualTo("/v1/eventos")))
    }

    @Test
    fun CEN_BFF_013_semTokenRetorna401() {
        enviar(null).then().statusCode(401)
    }

    @Test
    fun CEN_BFF_014_tokenDeOutraAudienciaRetorna403() {
        enviar("Bearer ${TokensDeTeste.outraAudiencia()}").then().statusCode(403)
    }
}

// Referência mínima (Kotlin puro) usada pelos testes unitários de exemplo. A squad troca pelo código real do BFF.
package br.com.itau.bff.pesquisa

import java.security.MessageDigest

data class RespostaCanal(
    val pesquisaId: String,
    val versaoPesquisa: Int,
    val canal: String,
    val respostaId: String,
    val respostas: List<Item>,
) { data class Item(val perguntaId: String, val tipo: String, val valor: Any) }

data class EventoPesquisa(
    val eventoId: String,
    val tipo: String = "pesquisa.respondida",
    val canal: String,
    val clienteRef: String,
    val pesquisaId: String,
    val versaoPesquisa: Int,
    val respostas: List<Map<String, Any>>,
)

/** Remove dados pessoais de texto livre antes de sair do BFF (LGPD). */
object Anonimizador {
    private val padroes = listOf(
        Regex("""(?<!\d)\d{3}\.?\d{3}\.?\d{3}-?\d{2}(?!\d)""") to "[cpf]",
        Regex("""[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}""") to "[email]",
        Regex("""(?<!\d)(?:\+?55\s?)?\(?\d{2}\)?\s?9\d{4}-?\d{4}(?!\d)""") to "[telefone]",
    )
    fun limpar(texto: String): Pair<String, Boolean> {
        var saida = texto
        padroes.forEach { (r, troca) -> saida = r.replace(saida, troca) }
        return saida to (saida != texto)
    }
    fun pseudonimo(idCliente: String): String =
        "sha256:" + MessageDigest.getInstance("SHA-256").digest(idCliente.toByteArray()).joinToString("") { "%02x".format(it) }
}

interface ApiEventosClient { fun publicar(evento: EventoPesquisa): Int }

class EncaminhadorEventos(private val api: ApiEventosClient) {
    fun encaminhar(resposta: RespostaCanal, idCliente: String): EventoPesquisa {
        val evento = EventoPesquisa(
            eventoId = resposta.respostaId,
            canal = resposta.canal,
            clienteRef = Anonimizador.pseudonimo(idCliente),
            pesquisaId = resposta.pesquisaId,
            versaoPesquisa = resposta.versaoPesquisa,
            respostas = resposta.respostas.map { item ->
                if (item.tipo == "texto") {
                    val (limpo, anonimizado) = Anonimizador.limpar(item.valor.toString())
                    mapOf("pergunta_id" to item.perguntaId, "tipo" to item.tipo, "valor" to limpo, "anonimizado" to anonimizado)
                } else mapOf("pergunta_id" to item.perguntaId, "tipo" to item.tipo, "valor" to item.valor)
            },
        )
        val status = api.publicar(evento)
        check(status in 200..299) { "API de eventos respondeu $status" }
        return evento
    }
}

// Trecho do CoE para o build.gradle.kts do BFF (Kotlin + Spring Boot 3).
// Usa Ktor? Troque as dependências spring-boot-starter-test por ktor-server-test-host; o restante vale igual.

plugins {
    jacoco
    id("info.solidsoft.pitest") version "1.15.0"
    id("org.sonarqube") version "5.1.0.4882"
    id("org.gradle.test-retry") version "1.6.0"
}

sourceSets {
    test {
        kotlin.srcDirs(
            "coe-tests/unitario", "coe-tests/autenticacao", "coe-tests/integracao",
            "coe-tests/resiliencia", "coe-tests/contrato",
            "coe-tests/exemplo-referencia", // remova quando apontar para o código real
        )
    }
}

dependencies {
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-params")
    testImplementation("io.mockk:mockk:1.13.13")
    testImplementation("com.ninja-squad:springmockk:4.0.2")
    testImplementation("io.rest-assured:rest-assured:5.5.0")
    testImplementation("io.rest-assured:kotlin-extensions:5.5.0")
    testImplementation("org.wiremock:wiremock-standalone:3.10.0")
    testImplementation("org.testcontainers:junit-jupiter:1.20.4")
    testImplementation("au.com.dius.pact.consumer:junit5:4.6.15")
    testImplementation("au.com.dius.pact.provider:junit5spring:4.6.15")
    testImplementation("io.jsonwebtoken:jjwt-api:0.12.6")
    testRuntimeOnly("io.jsonwebtoken:jjwt-impl:0.12.6")
    testRuntimeOnly("io.jsonwebtoken:jjwt-jackson:0.12.6")
}

// Estágios do CoE como tarefas separadas (o workflow chama cada uma no momento certo)
fun Test.camada(vararg pacotes: String) {
    useJUnitPlatform()
    filter { pacotes.forEach { includeTestsMatching("br.com.itau.bff.pesquisa.$it*") } }
    reports.junitXml.outputLocation.set(layout.buildDirectory.dir("coe-resultados/${name.removePrefix("teste")}"))
    systemProperty("pact.verifier.publishResults", "false")
}

tasks.register<Test>("testeUnitario") { camada("EncaminhadorEventosTest", "autenticacao.") }
tasks.register<Test>("testeContrato") { camada("contrato.") }
tasks.register<Test>("testeIntegracao") { camada("integracao.") }
tasks.register<Test>("testeResiliencia") { camada("resiliencia.") }

tasks.withType<Test>().configureEach {
    // 1 nova tentativa só para medir instabilidade: o JUnit XML registra a falha anterior e o CLI marca como instável
    retry { maxRetries.set(1); failOnPassedAfterRetry.set(false) }
    finalizedBy(tasks.jacocoTestReport)
}

tasks.jacocoTestReport {
    executionData.setFrom(fileTree(layout.buildDirectory).include("jacoco/*.exec"))
    reports { xml.required.set(true) }
}

pitest {
    junit5PluginVersion.set("1.2.1")
    targetClasses.set(listOf("br.com.itau.bff.*"))
    excludedClasses.set(listOf("*Application*", "*Config*"))
    mutationThreshold.set(60) // espelha quality_gate.mutacao_minima do CoE
    outputFormats.set(listOf("XML", "HTML"))
    timestampedReports.set(false)
}

sonar {
    properties {
        property("sonar.coverage.jacoco.xmlReportPaths", "build/reports/jacoco/test/jacocoTestReport.xml")
        property("sonar.junit.reportPaths", "build/coe-resultados")
    }
}

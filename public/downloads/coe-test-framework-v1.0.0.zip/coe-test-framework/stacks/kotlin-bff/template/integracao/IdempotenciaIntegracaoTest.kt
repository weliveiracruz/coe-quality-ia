package br.com.itau.bff.pesquisa.integracao

import br.com.itau.bff.pesquisa.autenticacao.TokensDeTeste
import com.github.tomakehurst.wiremock.client.WireMock.aResponse
import com.github.tomakehurst.wiremock.client.WireMock.equalTo
import com.github.tomakehurst.wiremock.client.WireMock.matchingJsonPath
import com.github.tomakehurst.wiremock.client.WireMock.post
import com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor
import com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo
import com.github.tomakehurst.wiremock.junit5.WireMockExtension
import io.restassured.RestAssured.given
import io.restassured.http.ContentType
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.RegisterExtension
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.test.context.DynamicPropertyRegistry
import org.springframework.test.context.DynamicPropertySource
import org.testcontainers.containers.GenericContainer
import org.testcontainers.junit.jupiter.Container
import org.testcontainers.junit.jupiter.Testcontainers
import org.testcontainers.utility.DockerImageName

/**
 * Integração com dependências reais em container (Testcontainers) e API de eventos simulada (WireMock).
 * Exemplo: Redis guardando as chaves de idempotência. Troque pelo que o BFF usa de verdade.
 * Como não depende do ambiente de homologação, a squad pode declarar no coe-test.yml:
 *   estagios: { integracao: { precisa_ambiente: false } }   -> roda a qualquer hora no runner.
 */
@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = ["spring.profiles.active=coe-teste"])
class IdempotenciaIntegracaoTest {

    companion object {
        @Container @JvmStatic
        val redis: GenericContainer<*> = GenericContainer(DockerImageName.parse("redis:7-alpine")).withExposedPorts(6379)

        @JvmField @RegisterExtension
        val api: WireMockExtension = WireMockExtension.newInstance().build()

        @JvmStatic @DynamicPropertySource
        fun props(r: DynamicPropertyRegistry) {
            r.add("spring.data.redis.host") { redis.host }
            r.add("spring.data.redis.port") { redis.getMappedPort(6379) }
            r.add("api-eventos.url") { api.baseUrl() }
        }
    }

    @LocalServerPort var porta = 0

    private fun enviar(id: String, canal: String = "android") = given().port(porta).contentType(ContentType.JSON)
        .header("Authorization", "Bearer ${TokensDeTeste.valido()}").header("Idempotency-Key", id)
        .body("""{"pesquisa_id":"PESQ-NPS-APP","versao_pesquisa":3,"canal":"$canal","resposta_id":"$id","respostas":[{"pergunta_id":"nota","tipo":"escala","valor":5},{"pergunta_id":"motivo","tipo":"texto","valor":"cpf 529.982.247-25"}]}""")
        .post("/bff/pesquisa/v1/respostas")

    @Test
    fun CEN_TRV_004_reenvioDaMesmaRespostaNaoDuplicaNaApi() {
        api.stubFor(post("/v1/eventos").willReturn(aResponse().withStatus(202)))
        enviar("r-0000000301").then().statusCode(201)
        enviar("r-0000000301").then().statusCode(200) // já recebida
        api.verify(1, postRequestedFor(urlEqualTo("/v1/eventos")).withHeader("Idempotency-Key", equalTo("r-0000000301")))
    }

    @Test
    fun CEN_TRV_003_bffEncaminhaTextoAnonimizadoEPseudonimo() {
        api.stubFor(post("/v1/eventos").willReturn(aResponse().withStatus(202)))
        enviar("r-0000000302").then().statusCode(201)
        api.verify(
            postRequestedFor(urlEqualTo("/v1/eventos"))
                .withRequestBody(matchingJsonPath("$.dados.respostas[1].valor", equalTo("cpf [cpf]")))
                .withRequestBody(matchingJsonPath("$.origem.cliente_ref", com.github.tomakehurst.wiremock.client.WireMock.matching("^sha256:[a-f0-9]{64}$"))),
        )
    }
}

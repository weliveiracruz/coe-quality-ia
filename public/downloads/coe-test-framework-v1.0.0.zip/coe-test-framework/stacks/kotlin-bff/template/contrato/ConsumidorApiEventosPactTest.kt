package br.com.itau.bff.pesquisa.contrato

import au.com.dius.pact.consumer.MockServer
import au.com.dius.pact.consumer.dsl.LambdaDsl.newJsonBody
import au.com.dius.pact.consumer.dsl.PactDslWithProvider
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt
import au.com.dius.pact.consumer.junit5.PactTestFor
import au.com.dius.pact.core.model.PactSpecVersion
import au.com.dius.pact.core.model.RequestResponsePact
import au.com.dius.pact.core.model.annotations.Pact
import au.com.dius.pact.core.model.annotations.PactDirectory
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse

/**
 * BFF como CONSUMIDOR da API de eventos (.NET). Gera contracts/bff-api/bff-pesquisa-api-eventos.json.
 * Mudou o que o BFF envia? Este teste regrava o pact e o PR mostra a diferença; o pipeline da API valida.
 */
@ExtendWith(PactConsumerTestExt::class)
@PactTestFor(providerName = "api-eventos", pactVersion = PactSpecVersion.V3)
@PactDirectory("build/pacts") // o workflow copia para contracts/bff-api no PR de contrato
class ConsumidorApiEventosPactTest {

    @Pact(consumer = "bff-pesquisa")
    fun ingestao(builder: PactDslWithProvider): RequestResponsePact = builder
        .given("credencial de serviço do BFF válida")
        .uponReceiving("ingestão de evento de pesquisa respondida")
        .path("/v1/eventos").method("POST")
        .headers(mapOf("Content-Type" to "application/json", "Authorization" to "Bearer token-servico-bff", "Idempotency-Key" to "r-0000000001"))
        .body(newJsonBody { o ->
            o.stringType("evento_id", "r-0000000001")
            o.stringValue("tipo", "pesquisa.respondida")
            o.numberValue("versao_schema", 1)
            o.`object`("origem") { or ->
                or.stringValue("canal", "android")
                or.stringMatcher("cliente_ref", "^sha256:[a-f0-9]{64}$", "sha256:" + "0f1e2d3c4b5a6978".repeat(4))
            }
            o.datetime("ocorrido_em", "yyyy-MM-dd'T'HH:mm:ssX")
            o.`object`("dados") { d ->
                d.stringValue("pesquisa_id", "PESQ-NPS-APP")
                d.numberValue("versao_pesquisa", 3)
                d.minArrayLike("respostas", 1) { r ->
                    r.stringType("pergunta_id", "nota"); r.stringType("tipo", "escala"); r.integerType("valor", 5)
                }
            }
        }.build())
        .willRespondWith().status(202)
        .body(newJsonBody { it.stringType("evento_id", "r-0000000001"); it.stringValue("status", "aceito") }.build())
        .toPact()

    @Test
    @PactTestFor(pactMethod = "ingestao")
    fun CEN_BFF_030_bffPublicaEventoNoFormatoDaApi(mock: MockServer) {
        // Em produção, use o ApiEventosClient real apontando para mock.getUrl().
        val corpo = """{"evento_id":"r-0000000001","tipo":"pesquisa.respondida","versao_schema":1,
            "origem":{"canal":"android","cliente_ref":"sha256:${"0f1e2d3c4b5a6978".repeat(4)}"},
            "ocorrido_em":"2026-11-20T12:00:00Z","dados":{"pesquisa_id":"PESQ-NPS-APP","versao_pesquisa":3,
            "respostas":[{"pergunta_id":"nota","tipo":"escala","valor":5}]}}"""
        val resp = HttpClient.newHttpClient().send(
            HttpRequest.newBuilder(URI("${mock.getUrl()}/v1/eventos")).POST(HttpRequest.BodyPublishers.ofString(corpo))
                .header("Content-Type", "application/json").header("Authorization", "Bearer token-servico-bff")
                .header("Idempotency-Key", "r-0000000001").build(),
            HttpResponse.BodyHandlers.ofString(),
        )
        assertThat(resp.statusCode()).isEqualTo(202)
    }
}

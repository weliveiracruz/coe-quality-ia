package br.com.itau.bff.pesquisa.contrato

import au.com.dius.pact.provider.junit5.HttpTestTarget
import au.com.dius.pact.provider.junit5.PactVerificationContext
import au.com.dius.pact.provider.junit5.PactVerificationInvocationContextProvider
import au.com.dius.pact.provider.junitsupport.Provider
import au.com.dius.pact.provider.junitsupport.State
import au.com.dius.pact.provider.junitsupport.loader.PactFolder
import br.com.itau.bff.pesquisa.autenticacao.TokensDeTeste
import com.github.tomakehurst.wiremock.client.WireMock.aResponse
import com.github.tomakehurst.wiremock.client.WireMock.post
import com.github.tomakehurst.wiremock.junit5.WireMockExtension
import org.apache.hc.core5.http.HttpRequest
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.TestTemplate
import org.junit.jupiter.api.extension.ExtendWith
import org.junit.jupiter.api.extension.RegisterExtension
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.test.context.DynamicPropertyRegistry
import org.springframework.test.context.DynamicPropertySource

/**
 * BFF como PROVEDOR: verifica TODOS os contratos dos canais (web, webview, android, ios) versionados em
 * contracts/canais-bff. Se uma mudança no BFF quebrar o que algum canal usa, este teste falha
 * indicando o consumidor e a interação. Roda no runner (estágio "contrato"), sem ambiente.
 * O pipeline faz checkout do framework em .coe-framework/.
 */
@Provider("bff-pesquisa")
@PactFolder(".coe-framework/contracts/canais-bff")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = ["spring.profiles.active=coe-teste"])
class ProvedorCanaisPactTest {

    companion object {
        @JvmField @RegisterExtension
        val api: WireMockExtension = WireMockExtension.newInstance().build()

        @JvmStatic @DynamicPropertySource
        fun props(r: DynamicPropertyRegistry) = r.add("api-eventos.url") { api.baseUrl() }
    }

    @LocalServerPort var porta = 0

    @BeforeEach
    fun antes(ctx: PactVerificationContext) {
        ctx.target = HttpTestTarget("localhost", porta)
        api.stubFor(post("/v1/eventos").willReturn(aResponse().withStatus(202)))
    }

    @TestTemplate
    @ExtendWith(PactVerificationInvocationContextProvider::class)
    fun verificarContratoDosCanais(ctx: PactVerificationContext, request: HttpRequest) {
        // Os pacts usam tokens simbólicos; aqui eles viram tokens de teste assinados de verdade.
        when (request.getFirstHeader("Authorization")?.value) {
            "Bearer token-valido" -> request.setHeader("Authorization", "Bearer ${TokensDeTeste.valido()}")
            "Bearer token-expirado" -> request.setHeader("Authorization", "Bearer ${TokensDeTeste.expirado()}")
        }
        ctx.verifyInteraction()
    }

    @State("token de sessão válido") fun tokenValido() = Unit
    @State("token de sessão expirado") fun tokenExpirado() = Unit
    @State("resposta r-0000000001 já recebida") fun jaRecebida() {
        // Pré-registra a chave de idempotência (ex.: via repositório de idempotência do BFF).
        RegistroIdempotenciaDeTeste.registrar("r-0000000001")
    }
}

/** Ponte para o repositório de idempotência real do BFF. Implemente apontando para o bean da aplicação. */
object RegistroIdempotenciaDeTeste {
    var registrar: (String) -> Unit = { }
}

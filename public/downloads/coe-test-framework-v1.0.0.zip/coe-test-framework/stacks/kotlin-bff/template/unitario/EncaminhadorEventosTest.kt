package br.com.itau.bff.pesquisa

import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import org.assertj.core.api.Assertions.assertThat
import org.assertj.core.api.Assertions.assertThatThrownBy
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.CsvSource

class EncaminhadorEventosTest {

    private val api = mockk<ApiEventosClient>()
    private val encaminhador = EncaminhadorEventos(api)

    private fun resposta(comentario: String? = null) = RespostaCanal(
        pesquisaId = "PESQ-NPS-APP", versaoPesquisa = 3, canal = "android", respostaId = "r-0000000001",
        respostas = listOfNotNull(
            RespostaCanal.Item("nota", "escala", 5),
            comentario?.let { RespostaCanal.Item("motivo", "texto", it) },
        ),
    )

    @Test
    @DisplayName("CEN-BFF-001 Resposta vira evento com o mesmo ID (idempotência ponta a ponta)")
    fun CEN_BFF_001_respostaViraEventoComMesmoId() {
        val enviado = slot<EventoPesquisa>()
        every { api.publicar(capture(enviado)) } returns 202
        encaminhador.encaminhar(resposta(), idCliente = "cliente-123")
        assertThat(enviado.captured.eventoId).isEqualTo("r-0000000001")
        assertThat(enviado.captured.clienteRef).matches("^sha256:[a-f0-9]{64}$")
    }

    @ParameterizedTest(name = "CEN-TRV-003 anonimiza {0}")
    @CsvSource(
        "'meu cpf é 529.982.247-25', '[cpf]'",
        "'escreve pra fulano@exemplo.com', '[email]'",
        "'me liga (11) 91234-5678', '[telefone]'",
    )
    fun CEN_TRV_003_textoLivreAnonimizadoAntesDaApi(texto: String, marcador: String) {
        val enviado = slot<EventoPesquisa>()
        every { api.publicar(capture(enviado)) } returns 202
        encaminhador.encaminhar(resposta(texto), "cliente-123")
        val motivo = enviado.captured.respostas.single { it["pergunta_id"] == "motivo" }
        assertThat(motivo["valor"] as String).contains(marcador)
        assertThat(motivo["anonimizado"]).isEqualTo(true)
    }

    @Test
    @DisplayName("CEN-BFF-002 Cliente nunca segue identificado em claro")
    fun CEN_BFF_002_clienteNuncaEmClaro() {
        val enviado = slot<EventoPesquisa>()
        every { api.publicar(capture(enviado)) } returns 202
        encaminhador.encaminhar(resposta(), idCliente = "52998224725")
        assertThat(enviado.captured.toString()).doesNotContain("52998224725")
    }

    @Test
    @DisplayName("CEN-BFF-003 Erro da API de eventos é propagado para o retry")
    fun CEN_BFF_003_erroDaApiPropagado() {
        every { api.publicar(any()) } returns 503
        assertThatThrownBy { encaminhador.encaminhar(resposta(), "c") }.hasMessageContaining("503")
        verify(exactly = 1) { api.publicar(any()) }
    }
}

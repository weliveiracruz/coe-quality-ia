package br.com.itau.bff.pesquisa.resiliencia

import br.com.itau.bff.pesquisa.autenticacao.TokensDeTeste
import com.github.tomakehurst.wiremock.client.WireMock.aResponse
import com.github.tomakehurst.wiremock.client.WireMock.post
import com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor
import com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo
import com.github.tomakehurst.wiremock.http.Fault
import com.github.tomakehurst.wiremock.junit5.WireMockExtension
import com.github.tomakehurst.wiremock.stubbing.Scenario
import io.restassured.RestAssured.given
import io.restassured.http.ContentType
import org.hamcrest.Matchers.lessThan
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.RegisterExtension
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.test.context.DynamicPropertyRegistry
import org.springframework.test.context.DynamicPropertySource

/**
 * Suíte transversal de resiliência: API de eventos lenta ou fora do ar.
 * Expectativa do CoE para o BFF (ajuste aos valores reais em application-coe-teste.yml):
 *   timeout 2s, 3 tentativas com backoff, circuit breaker abre após falhas seguidas,
 *   e a pesquisa NUNCA recebe erro 5xx bruto: o BFF responde 202 (aceita e reprocessa) ou 503 com Retry-After.
 * Nível unitário/integração com WireMock (runner). Nível ambiente com Toxiproxy: suites/transversais/resiliencia.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = ["spring.profiles.active=coe-teste"])
class ResilienciaApiEventosTest {

    companion object {
        @JvmField @RegisterExtension
        val api: WireMockExtension = WireMockExtension.newInstance().build()

        @JvmStatic @DynamicPropertySource
        fun props(r: DynamicPropertyRegistry) {
            r.add("api-eventos.url") { api.baseUrl() }
            r.add("api-eventos.timeout-ms") { 2000 }
            r.add("api-eventos.tentativas") { 3 }
        }
    }

    @LocalServerPort var porta = 0

    private fun enviar(id: String) = given().port(porta).contentType(ContentType.JSON)
        .header("Authorization", "Bearer ${TokensDeTeste.valido()}").header("Idempotency-Key", id)
        .body("""{"pesquisa_id":"PESQ-NPS-APP","versao_pesquisa":3,"canal":"ios","resposta_id":"$id","respostas":[{"pergunta_id":"nota","tipo":"escala","valor":4}]}""")
        .post("/bff/pesquisa/v1/respostas")

    @Test
    fun CEN_BFF_020_retryRecuperaFalhaTransitoria() {
        api.stubFor(post("/v1/eventos").inScenario("instavel").whenScenarioStateIs(Scenario.STARTED)
            .willReturn(aResponse().withStatus(503)).willSetStateTo("ok"))
        api.stubFor(post("/v1/eventos").inScenario("instavel").whenScenarioStateIs("ok")
            .willReturn(aResponse().withStatus(202)))

        enviar("r-0000000020").then().statusCode(201)
        api.verify(2, postRequestedFor(urlEqualTo("/v1/eventos")))
    }

    @Test
    fun CEN_BFF_021_apiLentaRespeitaTimeoutSemTravarOCanal() {
        api.stubFor(post("/v1/eventos").willReturn(aResponse().withStatus(202).withFixedDelay(10_000)))
        enviar("r-0000000021").then()
            .statusCode(org.hamcrest.Matchers.anyOf(org.hamcrest.Matchers.equalTo(202), org.hamcrest.Matchers.equalTo(503)))
            .time(lessThan(8_000L)) // 3 tentativas x 2s + backoff; nunca 10s
    }

    @Test
    fun CEN_BFF_022_apiForaDoArNaoDevolve500ParaOCanal() {
        api.stubFor(post("/v1/eventos").willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)))
        val r = enviar("r-0000000022")
        check(r.statusCode in listOf(202, 503)) { "BFF devolveu ${r.statusCode}; esperado 202 (fila) ou 503 com Retry-After" }
        if (r.statusCode == 503) check(r.header("Retry-After") != null) { "503 sem Retry-After" }
        api.verify(3, postRequestedFor(urlEqualTo("/v1/eventos")))
    }

    @Test
    fun CEN_BFF_023_circuitBreakerAbreAposFalhasSeguidas() {
        api.stubFor(post("/v1/eventos").willReturn(aResponse().withStatus(500)))
        repeat(6) { enviar("r-00000001$it") }
        val antes = api.findAll(postRequestedFor(urlEqualTo("/v1/eventos"))).size
        enviar("r-0000000199")
        val depois = api.findAll(postRequestedFor(urlEqualTo("/v1/eventos"))).size
        check(depois == antes) { "Circuito deveria estar aberto e não chamar a API (antes=$antes, depois=$depois)" }
    }
}

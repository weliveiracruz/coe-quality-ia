# Template BFF Kotlin

Criado por `coe-test init --stack kotlin-bff`. Pressupõe Spring Boot 3. Para Ktor, veja o comentário no `build.gradle.coe.kts`.

| Pasta | Camada | Ferramentas | Onde roda |
|---|---|---|---|
| `unitario/` | Unitário | JUnit 5, MockK, AssertJ | Runner, a qualquer hora |
| `autenticacao/` | Token válido, expirado, inválido, ausente e outra audiência | REST Assured, WireMock, JJWT | Runner |
| `integracao/` | Dependências reais em container + API simulada | Testcontainers, WireMock | Runner (ou janela, se usar homologação) |
| `resiliencia/` | Retry, timeout, circuit breaker, API fora do ar | WireMock com falhas | Runner; versão com ambiente em `suites/transversais/resiliencia` |
| `contrato/` | Provedor dos canais e consumidor da API .NET | Pact JVM, sem broker (pasta versionada) | Runner |

Também usados por este produto:
- Performance com k6: `suites/transversais/performance/bff-pesquisa.k6.js`, no fechamento do pacote.
- Mutação com PIT: `./gradlew pitest`, limite de 60%.
- DAST com OWASP ZAP: workflow de release.

## Perfil `coe-teste`
O BFF precisa de um `application-coe-teste.yml` com:
- a chave de assinatura de teste (igual à de `TokensDeTeste.kt`)
- `api-eventos.url`, `api-eventos.timeout-ms` e `api-eventos.tentativas` sobrescrevíveis
- circuit breaker e retry (Resilience4j) com os valores que a squad definir

## Comandos que o pipeline usa
```
./gradlew testeUnitario testeContrato        # PR, a qualquer hora
./gradlew testeIntegracao testeResiliencia   # PR
./gradlew pitest                             # se camadas.mutacao
./gradlew sonar                              # quality gate do CoE
```

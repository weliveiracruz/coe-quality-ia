package br.com.itau.pesquisa.webview

import androidx.test.espresso.Espresso.pressBack
import androidx.test.espresso.web.assertion.WebViewAssertions.webMatches
import androidx.test.espresso.web.sugar.Web.onWebView
import androidx.test.espresso.web.webdriver.DriverAtoms.findElement
import androidx.test.espresso.web.webdriver.DriverAtoms.getText
import androidx.test.espresso.web.webdriver.DriverAtoms.webClick
import androidx.test.espresso.web.webdriver.Locator
import androidx.test.ext.junit.rules.ActivityScenarioRule
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.hamcrest.Matchers.containsString
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

/**
 * Integração da página web (Angular ou React) com o app Android via WebView.
 * O conteúdo web em si é testado pelo time web com Playwright (stacks/web-e2e);
 * aqui o foco é a fronteira app <-> página: carregamento, token pela ponte, voltar/fechar e erros.
 * O BFF é simulado com MockWebServer para o teste não depender do ambiente.
 */
class PesquisaWebViewTest {

    private val bff = MockWebServer()

    @get:Rule
    val activity = ActivityScenarioRule(PesquisaWebViewActivity::class.java)

    @Before
    fun setup() {
        bff.start()
        PesquisaWebViewActivity.bffBaseUrlParaTeste = bff.url("/").toString()
        onWebView().forceJavascriptEnabled()
    }

    @After
    fun tearDown() = bff.shutdown()

    @Test
    fun CEN_PESQ_006_paginaRecebeTokenDoApp() {
        bff.enqueue(MockResponse().setResponseCode(201))
        onWebView()
            .withElement(findElement(Locator.CSS_SELECTOR, "[data-testid=nota-4]")).perform(webClick())
            .withElement(findElement(Locator.CSS_SELECTOR, "[data-testid=enviar]")).perform(webClick())

        val req = bff.takeRequest()
        check(req.getHeader("Authorization")?.startsWith("Bearer ") == true) { "Página não enviou o token recebido pela ponte" }
        check(req.path!!.endsWith("/bff/pesquisa/v1/respostas"))
    }

    @Test
    fun CEN_PESQ_001_responderNotaEEnviar() {
        bff.enqueue(MockResponse().setResponseCode(201))
        onWebView()
            .withElement(findElement(Locator.CSS_SELECTOR, "[data-testid=nota-5]")).perform(webClick())
            .withElement(findElement(Locator.CSS_SELECTOR, "[data-testid=enviar]")).perform(webClick())
            .withElement(findElement(Locator.CSS_SELECTOR, "[role=status]"))
            .check(webMatches(getText(), containsString("Obrigado")))
    }

    @Test
    fun CEN_PESQ_007_voltarDoSistemaFechaWebView() {
        pressBack()
        activity.scenario.onActivity { check(it.isFinishing) { "WebView não devolveu o controle ao app" } }
    }

    @Test
    fun CEN_PESQ_005_erroDoBffExibeMensagemNaPagina() {
        bff.enqueue(MockResponse().setResponseCode(503))
        onWebView()
            .withElement(findElement(Locator.CSS_SELECTOR, "[data-testid=nota-2]")).perform(webClick())
            .withElement(findElement(Locator.CSS_SELECTOR, "[data-testid=enviar]")).perform(webClick())
            .withElement(findElement(Locator.CSS_SELECTOR, "[role=alert]"))
            .check(webMatches(getText(), containsString("Tente novamente")))
    }
}

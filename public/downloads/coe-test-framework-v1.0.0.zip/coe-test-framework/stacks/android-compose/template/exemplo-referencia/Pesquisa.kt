// Implementação de REFERÊNCIA mínima usada pelos testes de exemplo do template.
// A squad substitui pelos imports reais do módulo de pesquisa e apaga esta pasta.
package br.com.itau.pesquisa

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

const val LIMITE_COMENTARIO = 500

data class RespostaPesquisa(
    val pesquisaId: String,
    val versaoPesquisa: Int,
    val canal: String,
    val respostaId: String,
    val nota: Int,
    val comentario: String?,
)

interface PesquisaRepository {
    suspend fun enviar(resposta: RespostaPesquisa): Result<Unit>
}

data class PesquisaUiState(
    val nota: Int? = null,
    val comentario: String = "",
    val enviando: Boolean = false,
    val erro: String? = null,
    val enviada: Boolean = false,
) {
    val podeEnviar: Boolean get() = nota != null && !enviando
}

class PesquisaViewModel(
    private val repo: PesquisaRepository,
    private val dispatcher: CoroutineDispatcher,
    private val gerarId: () -> String,
) {
    private val _estado = MutableStateFlow(PesquisaUiState())
    val estado: StateFlow<PesquisaUiState> = _estado

    fun selecionarNota(nota: Int) {
        require(nota in 1..5)
        _estado.update { it.copy(nota = nota, erro = null) }
    }

    fun atualizarComentario(texto: String) =
        _estado.update { it.copy(comentario = texto.take(LIMITE_COMENTARIO)) }

    suspend fun enviar() {
        val atual = _estado.value
        val nota = atual.nota ?: return
        _estado.update { it.copy(enviando = true, erro = null) }
        val resposta = RespostaPesquisa("PESQ-NPS-APP", 3, "android", gerarId(), nota, atual.comentario.ifBlank { null })
        val r = withContext(dispatcher) { repo.enviar(resposta) }
        _estado.update {
            if (r.isSuccess) it.copy(enviando = false, enviada = true)
            else it.copy(enviando = false, erro = "Não foi possível enviar. Tente novamente.")
        }
    }
}

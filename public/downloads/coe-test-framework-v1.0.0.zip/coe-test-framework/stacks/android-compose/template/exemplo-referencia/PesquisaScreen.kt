// Tela de REFERÊNCIA mínima (Compose) com as tags e semânticas que os testes de exemplo esperam.
package br.com.itau.pesquisa

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.SemanticsPropertyKey
import androidx.compose.ui.semantics.SemanticsPropertyReceiver
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Marca um campo como sensível: o wrapper do SDK aplica a máscara do FullStory e os testes conferem a marcação. */
val DadoSensivelKey = SemanticsPropertyKey<Boolean>("DadoSensivel")
var SemanticsPropertyReceiver.dadoSensivel by DadoSensivelKey
fun Modifier.dadoSensivel(): Modifier = semantics { dadoSensivel = true } // + máscara do FullStory no app real

@Composable
fun PesquisaScreen(viewModel: PesquisaViewModel, aoFechar: () -> Unit) {
    val estado by viewModel.estado.collectAsState()
    val escopo = rememberCoroutineScope()
    Column {
        if (estado.enviada) {
            Text("Obrigado pela sua opinião", Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            return@Column
        }
        Text("De 1 a 5, quanto você recomenda o app?")
        Row {
            (1..5).forEach { n ->
                Button(
                    onClick = { viewModel.selecionarNota(n) },
                    modifier = Modifier.testTag("nota-$n").sizeIn(minWidth = 48.dp, minHeight = 48.dp)
                        .semantics { contentDescription = "Nota $n de 5" + if (estado.nota == n) ", selecionada" else "" },
                ) { Text("$n") }
            }
        }
        OutlinedTextField(
            value = estado.comentario,
            onValueChange = viewModel::atualizarComentario,
            label = { Text("Comentário (opcional)") },
            supportingText = { Text("${estado.comentario.length}/$LIMITE_COMENTARIO") },
            modifier = Modifier.testTag("comentario").dadoSensivel(),
        )
        estado.erro?.let { Text(it, Modifier.testTag("erro").semantics { liveRegion = LiveRegionMode.Assertive }) }
        Button(onClick = { escopo.launch { viewModel.enviar() } }, enabled = estado.podeEnviar, modifier = Modifier.testTag("enviar")) {
            Text(if (estado.erro != null) "Tentar novamente" else "Enviar")
        }
        Button(onClick = aoFechar, modifier = Modifier.testTag("fechar")) { Text("Fechar") }
    }
}

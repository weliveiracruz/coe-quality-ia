package br.com.itau.pesquisa

import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.assertHeightIsAtLeast
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertWidthIsAtLeast
import androidx.compose.ui.test.junit4.accessibility.enableAccessibilityChecks
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.dp
import org.junit.Before
import org.junit.Rule
import org.junit.Test

/**
 * Testes de UI Compose (instrumentados). No PR rodam no emulador do GitHub Actions dentro da janela 8h–20h;
 * no fechamento do pacote, na matriz da device farm.
 * Acessibilidade: o Accessibility Test Framework roda a cada interação (enableAccessibilityChecks)
 * e falha em contraste, área de toque, rótulos ausentes e itens duplicados.
 */
class PesquisaScreenTest {

    @get:Rule
    val compose = createComposeRule()

    private val repo = RepositorioFalso()

    @Before
    fun setup() {
        compose.enableAccessibilityChecks()
        compose.setContent { PesquisaScreen(viewModel = criarViewModel(repo), aoFechar = {}) }
    }

    @Test
    fun CEN_PESQ_001_responderNotaEEnviar() {
        compose.onNodeWithTag("nota-5").performClick()
        compose.onNodeWithTag("enviar").performClick()
        compose.onNodeWithText("Obrigado pela sua opinião").assertIsDisplayed()
        check(repo.enviadas.single().nota == 5)
    }

    @Test
    fun CEN_PESQ_002_enviarDesabilitadoSemNota() {
        compose.onNodeWithTag("enviar")
            .assertIsNotEnabled()
            // TalkBack anuncia "desativado": o estado precisa estar na semântica
            .assert(SemanticsMatcher.keyIsDefined(SemanticsProperties.Disabled))
    }

    @Test
    fun CEN_TRV_006_areaDeToqueMinima48dp() {
        val notas = compose.onAllNodesWithTag("nota-", useUnmergedTree = true, substring = true)
        notas.fetchSemanticsNodes().indices.forEach { i ->
            notas[i].assertWidthIsAtLeast(48.dp).assertHeightIsAtLeast(48.dp)
        }
    }

    @Test
    fun CEN_TRV_001_elementosComRotuloParaTalkBack() {
        (1..5).forEach { n ->
            compose.onNodeWithTag("nota-$n")
                .assert(SemanticsMatcher.keyIsDefined(SemanticsProperties.ContentDescription))
        }
    }
}

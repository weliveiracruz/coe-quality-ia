package br.com.itau.pesquisa

import kotlinx.coroutines.Dispatchers

/** Dublê de repositório para testes de UI: registra o que seria enviado ao BFF. */
class RepositorioFalso(var falhar: Boolean = false) : PesquisaRepository {
    val enviadas = mutableListOf<RespostaPesquisa>()
    override suspend fun enviar(resposta: RespostaPesquisa): Result<Unit> {
        if (falhar) return Result.failure(RuntimeException("503"))
        enviadas += resposta
        return Result.success(Unit)
    }
}

fun criarViewModel(repo: PesquisaRepository) = PesquisaViewModel(repo, Dispatchers.Main) { "r-ui-teste" }

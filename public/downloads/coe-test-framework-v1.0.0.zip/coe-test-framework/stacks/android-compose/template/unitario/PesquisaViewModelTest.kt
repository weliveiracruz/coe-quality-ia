package br.com.itau.pesquisa

import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import io.mockk.slot
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Test

/** Testes unitários (JUnit 5 + MockK). Rodam no runner do GitHub, a qualquer hora, sem ambiente. */
class PesquisaViewModelTest {

    private val repo = mockk<PesquisaRepository>()
    private val dispatcher = StandardTestDispatcher()
    private lateinit var vm: PesquisaViewModel

    @BeforeEach
    fun setup() {
        vm = PesquisaViewModel(repo, dispatcher) { "r-fixo" }
    }

    @Test
    @DisplayName("CEN-PESQ-001 Responder nota e enviar")
    fun CEN_PESQ_001_responderNotaEEnviar() = runTest(dispatcher) {
        val enviada = slot<RespostaPesquisa>()
        coEvery { repo.enviar(capture(enviada)) } returns Result.success(Unit)

        vm.selecionarNota(5)
        vm.enviar()

        assertThat(vm.estado.value.enviada).isTrue()
        assertThat(enviada.captured.nota).isEqualTo(5)
        assertThat(enviada.captured.canal).isEqualTo("android")
        assertThat(enviada.captured.comentario).isNull()
    }

    @Test
    @DisplayName("CEN-PESQ-002 Enviar desabilitado sem nota")
    fun CEN_PESQ_002_enviarDesabilitadoSemNota() = runTest(dispatcher) {
        assertThat(vm.estado.value.podeEnviar).isFalse()
        vm.enviar()
        coVerify(exactly = 0) { repo.enviar(any()) }
    }

    @Test
    @DisplayName("CEN-PESQ-003 Comentário limitado a 500 caracteres")
    fun CEN_PESQ_003_comentarioLimitado() {
        vm.atualizarComentario("a".repeat(600))
        assertThat(vm.estado.value.comentario).hasLength(LIMITE_COMENTARIO)
    }

    @Test
    @DisplayName("CEN-PESQ-005 Falha no envio mostra erro e permite reenviar")
    fun CEN_PESQ_005_falhaNoEnvioPermiteReenviar() = runTest(dispatcher) {
        coEvery { repo.enviar(any()) } returnsMany listOf(Result.failure(RuntimeException("503")), Result.success(Unit))
        vm.selecionarNota(3)

        vm.enviar()
        assertThat(vm.estado.value.erro).isNotNull()
        assertThat(vm.estado.value.podeEnviar).isTrue()

        vm.enviar()
        assertThat(vm.estado.value.enviada).isTrue()
        coVerify(exactly = 2) { repo.enviar(match { it.respostaId == "r-fixo" }) } // mesma resposta, sem duplicar ID
    }
}

// Trecho do CoE para o build.gradle.kts do módulo Android (Compose).
// Aplique com: apply(from = "coe-tests/build.gradle.coe.kts") ou copie os blocos.
// Versões centralizadas no catálogo do CoE (gradle/libs.versions.toml do framework).

plugins {
    id("org.jetbrains.kotlinx.kover")          // cobertura -> SonarQube
    id("de.mannodermaus.android-junit5")       // JUnit 5 em testes locais
    id("info.solidsoft.pitest") apply false    // mutação (opcional; ligar com camadas.mutacao)
}

android {
    defaultConfig {
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        // Orquestrador isola cada teste e reduz instabilidade
        testInstrumentationRunnerArguments["clearPackageData"] = "true"
        // TestStorage: arquivos gravados pelos testes (eventos para o scanner de privacidade) voltam para o build
        testInstrumentationRunnerArguments["useTestStorageService"] = "true"
    }
    testOptions {
        execution = "ANDROIDX_TEST_ORCHESTRATOR"
        animationsDisabled = true
        unitTests.isIncludeAndroidResources = true // Robolectric
        // Emuladores gerenciados: usados no PR dentro do GitHub Actions
        managedDevices {
            localDevices {
                create("coeApi34") { device = "Pixel 6"; apiLevel = 34; systemImageSource = "aosp-atd" }
                create("coeApi26") { device = "Pixel 2"; apiLevel = 26; systemImageSource = "aosp" }
            }
        }
    }
    sourceSets["test"].java.srcDirs("coe-tests/unitario", "coe-tests/transversais/unitario", "coe-tests/exemplo-referencia")
    sourceSets["androidTest"].java.srcDirs("coe-tests/ui", "coe-tests/webview", "coe-tests/transversais/instrumentado", "coe-tests/exemplo-referencia")
    // exemplo-referencia: remova das duas linhas quando apontar para o código real
}

dependencies {
    // Unitário
    testImplementation("org.junit.jupiter:junit-jupiter:5.11.3")
    testImplementation("io.mockk:mockk:1.13.13")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
    testImplementation("app.cash.turbine:turbine:1.2.0")
    testImplementation("com.google.truth:truth:1.4.4")
    testImplementation("org.robolectric:robolectric:4.14")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")

    // UI Compose + acessibilidade (ATF integrado ao Compose)
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.12.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4-accessibility")
    androidTestImplementation("androidx.test.espresso:espresso-web:3.6.1")
    androidTestImplementation("androidx.test.espresso:espresso-intents:3.6.1")
    androidTestImplementation("com.google.android.apps.common.testing.accessibility.framework:accessibility-test-framework:4.1.1")
    androidTestImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
    androidTestUtil("androidx.test:orchestrator:1.5.1")
    androidTestUtil("androidx.test.services:test-services:1.5.0")
    androidTestImplementation("androidx.test.services:storage:1.5.0")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

kover {
    reports {
        filters { excludes { classes("*ComposableSingletons*", "*_Factory", "*Hilt*", "*.BuildConfig") } }
        verify { rule { minBound(80) } } // espelha o quality gate do CoE para feedback local
    }
}

tasks.withType<Test>().configureEach {
    useJUnitPlatform()
    reports.junitXml.required.set(true)
    // Nova tentativa só para medir instabilidade; o teste continua contando como instável no relatório
    systemProperty("junit.jupiter.execution.timeout.default", "30s")
}

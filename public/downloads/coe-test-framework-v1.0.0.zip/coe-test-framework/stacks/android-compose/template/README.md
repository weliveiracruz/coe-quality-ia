# Template Android (Compose)

Criado por `coe-test init --stack android-compose`. Os exemplos rodam contra a implementação de referência em `exemplo-referencia/`. Troque pelos imports reais do módulo e apague a pasta.

| Pasta | Camada | Onde roda |
|---|---|---|
| `unitario/` | Unitário (JUnit 5, MockK, Turbine, Robolectric) | Runner do GitHub, a qualquer hora |
| `ui/` | UI Compose com Accessibility Test Framework | Emulador no PR (janela 8h–20h), device farm no release |
| `webview/` | Integração app ↔ página web (Espresso-Web) | Igual a `ui/` |
| `transversais/unitario/` | Rede instável e fila offline | Runner, a qualquer hora |
| `transversais/instrumentado/` | Privacidade, máscara do FullStory | Emulador |

## Como ligar
1. Aplique `build.gradle.coe.kts` no módulo (`apply(from = ...)`).
2. Mantenha os IDs `CEN_...` no nome dos testes: é por eles que a paridade e o IU Click enxergam o resultado.
3. Para gerar um teste novo a partir do catálogo: `coe-test esqueleto --cenario CEN-PESQ-004 --stack android-compose`.

## Comandos que o pipeline usa
```
./gradlew testDebugUnitTest koverXmlReportDebug          # unitário + cobertura
./gradlew coeApi34DebugAndroidTest                         # UI/WebView no emulador gerenciado
./gradlew pitest                                           # mutação (se camadas.mutacao)
```

package br.com.itau.pesquisa.transversais

import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Test

/**
 * Suíte transversal "rede instável no mobile" (CEN-TRV-004), nível unitário.
 * Simula queda de conexão e resposta lenta com MockWebServer; a fila offline do app
 * precisa guardar a resposta e reenviar uma única vez (idempotência pelo resposta_id).
 *
 * Contrato esperado da fila (adapte para a classe real da squad):
 *   FilaOffline.enfileirar(resposta) ; FilaOffline.drenar(): Int (quantidade enviada)
 */
class FilaOfflineTest {

    private val bff = MockWebServer()
    private lateinit var fila: FilaOfflineDeTeste

    @BeforeEach
    fun setup() {
        bff.start()
        fila = FilaOfflineDeTeste(bff.url("/bff/pesquisa/v1/respostas").toString())
    }

    @AfterEach
    fun tearDown() = bff.shutdown()

    @Test
    @DisplayName("CEN-TRV-004 Resposta offline enviada depois sem duplicar")
    fun CEN_TRV_004_offlineEnviaDepoisSemDuplicar() = runTest {
        bff.enqueue(MockResponse().setSocketPolicy(SocketPolicy.DISCONNECT_AT_START)) // sem rede
        fila.enfileirar("r-123", """{"resposta_id":"r-123","nota":4}""")
        assertThat(fila.drenar()).isEqualTo(0)
        assertThat(fila.pendentes()).isEqualTo(1)

        bff.enqueue(MockResponse().setResponseCode(201)) // rede voltou
        assertThat(fila.drenar()).isEqualTo(1)
        assertThat(fila.pendentes()).isEqualTo(0)

        // nova drenagem não reenvia
        assertThat(fila.drenar()).isEqualTo(0)
        assertThat(bff.requestCount).isEqualTo(2)
        bff.takeRequest(); val envio = bff.takeRequest()
        assertThat(envio.getHeader("Idempotency-Key")).isEqualTo("r-123")
    }

    @Test
    @DisplayName("CEN-TRV-004 Rede lenta acima do timeout mantém a resposta na fila")
    fun CEN_TRV_004_redeLentaMantemNaFila() = runTest {
        bff.enqueue(MockResponse().setResponseCode(201).setHeadersDelay(5, java.util.concurrent.TimeUnit.SECONDS))
        fila.enfileirar("r-9", """{"resposta_id":"r-9"}""")
        assertThat(fila.drenar(timeoutMs = 500)).isEqualTo(0)
        assertThat(fila.pendentes()).isEqualTo(1)
    }
}

/** Implementação mínima de referência para o exemplo rodar. Substitua pela fila real do app. */
class FilaOfflineDeTeste(private val url: String) {
    private val itens = LinkedHashMap<String, String>()
    fun enfileirar(id: String, json: String) { itens[id] = json }
    fun pendentes() = itens.size
    fun drenar(timeoutMs: Long = 2000): Int {
        val cliente = okhttp3.OkHttpClient.Builder().callTimeout(java.time.Duration.ofMillis(timeoutMs)).build()
        var enviados = 0
        for ((id, json) in itens.toMap()) {
            val req = okhttp3.Request.Builder().url(url).header("Idempotency-Key", id)
                .post(okhttp3.RequestBody.create("application/json".toMediaType(), json)).build()
            runCatching { cliente.newCall(req).execute().use { if (it.isSuccessful) { itens.remove(id); enviados++ } } }
        }
        return enviados
    }
    private fun String.toMediaType() = okhttp3.MediaType.get(this)
}

package br.com.itau.pesquisa.transversais

import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodes
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.services.storage.TestStorage
import br.com.itau.pesquisa.DadoSensivelKey
import br.com.itau.pesquisa.PesquisaScreen
import br.com.itau.pesquisa.RepositorioFalso
import br.com.itau.pesquisa.criarViewModel
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Rule
import org.junit.Test

/**
 * Suíte transversal de privacidade/LGPD (CEN-TRV-003) no Android.
 * 1) Todo campo de texto livre precisa estar marcado como sensível (máscara do FullStory aplicada pelo wrapper).
 * 2) Os eventos capturados durante o teste são gravados em artefatos/eventos/*.json;
 *    o pipeline roda "coe-test privacidade" sobre eles e reprova se houver CPF, e-mail etc. em claro.
 */
class PrivacidadeTest {

    @get:Rule
    val compose = createComposeRule()

    @Test
    fun CEN_TRV_003_camposDeTextoLivreMascaradosNoFullStory() {
        compose.setContent { PesquisaScreen(criarViewModel(RepositorioFalso()), aoFechar = {}) }
        val camposTexto = compose.onAllNodes(hasSetTextAction()).fetchSemanticsNodes()
        val semMascara = camposTexto.filter { DadoSensivelKey !in it.config }
        check(semMascara.isEmpty()) { "${semMascara.size} campo(s) de texto sem marcação de dado sensível (FullStory capturaria em claro)" }
    }

    @Test
    fun CEN_TRV_003_comentarioComCpfNaoVazaNosEventosDeAnalytics() {
        val analytics = AnalyticsFalso() // dublê da interface do SDK de Analytics (Firebase + FullStory)
        compose.setContent { PesquisaScreen(criarViewModel(RepositorioFalso()), aoFechar = {}) }
        compose.onNodeWithTag("nota-3").performClick()
        compose.onNodeWithTag("comentario").performTextInput("meu cpf é 529.982.247-25")
        compose.onNodeWithTag("enviar").performClick()

        // Os eventos de analytics capturados vão para artefatos/eventos; o scanner do pipeline reprova qualquer dado pessoal.
        // A resposta em si vai só para o BFF (destino legítimo), nunca para o analytics.
        // TestStorage: o Gradle traz o arquivo do aparelho/emulador para build/outputs/managed_device_android_test_additional_output
        TestStorage().openOutputFile("coe/eventos/android-privacidade.json").bufferedWriter().use {
            it.write(JSONArray(analytics.eventos.map { e -> JSONObject(e) }).toString())
        }
    }
}

/** Dublê do SDK de Analytics. No app real, injete-o no lugar do wrapper durante o teste. */
class AnalyticsFalso {
    val eventos = mutableListOf<Map<String, Any?>>()
    fun registrar(nome: String, params: Map<String, Any?>) { eventos += mapOf("evento" to nome) + params }
}

// Playwright do CoE: um único config para todas as plataformas web (Bankline e demais) e para o conteúdo da WebView.
// Variáveis: COE_PERFIL_WEB (bankline), COE_AMBIENTE (hml), COE_DEMO=1 (roda contra a demo local),
// COE_NAVEGADORES (chromium,firefox,webkit), COE_CHROME_CANAL=chrome (usa o Chrome instalado no runner).
import { defineConfig, devices } from '@playwright/test';
import path from 'node:path';
import { carregarPerfil, urlBase, demo } from './support/perfil';

const perfil = carregarPerfil();
const navegadores = (process.env.COE_NAVEGADORES?.split(',') ?? perfil.navegadores) as ('chromium' | 'firefox' | 'webkit')[];
const DISPOSITIVO = { chromium: devices['Desktop Chrome'], firefox: devices['Desktop Firefox'], webkit: devices['Desktop Safari'] };
const resultados = process.env.COE_RESULTADOS ?? path.resolve(__dirname, '../resultados');

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  // 1 nova tentativa: o teste que só passa na segunda vez é marcado como instável no relatório do CoE
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 4 : undefined,
  timeout: 30_000,
  expect: {
    timeout: 5_000,
    toHaveScreenshot: { maxDiffPixelRatio: perfil.visual.limiar_diferenca_pct / 100, animations: 'disabled' },
  },
  snapshotPathTemplate: '{testDir}/__snapshots__/{projectName}/{testFilePath}/{arg}{ext}',
  reporter: [
    ['list'],
    ['junit', { outputFile: path.join(resultados, 'e2e', `playwright-${perfil.id}.xml`) }],
    ['html', { outputFolder: path.join(process.env.COE_ARTEFATOS ?? path.resolve(__dirname, '../artefatos'), 'playwright-html'), open: 'never' }],
    ...(process.env.COE_ALLURE === '1' ? [['allure-playwright', { resultsDir: path.resolve(__dirname, '../allure-results') }] as const] : []),
  ],
  use: {
    baseURL: urlBase(perfil),
    locale: 'pt-BR',
    timezoneId: 'America/Sao_Paulo',
    viewport: perfil.viewport_padrao,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: process.env.COE_VIDEO === 'off' ? 'off' : 'retain-on-failure',
  },
  projects: navegadores.map((n) => ({
    name: `${perfil.id}-${n}`,
    use: { ...DISPOSITIVO[n], viewport: perfil.viewport_padrao, ...(n === 'chromium' && process.env.COE_CHROME_CANAL ? { channel: process.env.COE_CHROME_CANAL } : {}) },
  })),
  webServer: demo
    ? { command: 'node demo/servidor.mjs', url: 'http://localhost:4173/__coe/requisicoes', reuseExistingServer: !process.env.CI }
    : undefined,
});

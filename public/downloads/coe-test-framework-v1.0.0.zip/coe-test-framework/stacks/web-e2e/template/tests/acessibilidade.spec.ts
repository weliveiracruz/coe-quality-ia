// Acessibilidade (WCAG 2.2 AA) com axe-core em navegador real + verificações que o axe não cobre.
import { test, expect } from '../support/coe';

test.describe('Acessibilidade — web', () => {
  test('CEN-TRV-001 axe sem violações graves em todos os estados', async ({ page, abrirPesquisa, auditarA11y }) => {
    await abrirPesquisa();
    await auditarA11y('aberta');
    await page.getByRole('radio', { name: '4 de 5' }).check();
    await auditarA11y('nota selecionada');
    await page.getByRole('button', { name: 'Enviar' }).click();
    await expect(page.getByRole('status')).toBeVisible();
    await auditarA11y('enviada');
  });

  test('CEN-TRV-001 fluxo completo só com teclado', async ({ page, abrirPesquisa }) => {
    await abrirPesquisa();
    await page.keyboard.press('Tab');             // primeira nota
    await page.keyboard.press('ArrowRight');      // grupo de rádio navega por setas
    await page.keyboard.press('ArrowRight');
    await expect(page.getByRole('radio', { name: '3 de 5' })).toBeChecked();
    await page.getByRole('button', { name: 'Enviar' }).focus();
    await page.keyboard.press('Enter');
    await expect(page.getByRole('status')).toHaveText('Obrigado pela sua opinião');
  });

  test('CEN-TRV-002 zoom de 200% sem rolagem horizontal', async ({ page, abrirPesquisa, perfil }) => {
    const base = perfil.viewport_padrao;
    await page.setViewportSize({ width: Math.round(base.width / 2), height: Math.round(base.height / 2) });
    await abrirPesquisa();
    const rolagem = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    expect(rolagem, 'conteúdo exige rolagem horizontal (WCAG 1.4.10 Reflow)').toBe(false);
  });

  test('CEN-TRV-006 área de toque mínima de 24x24 px (WCAG 2.5.8)', async ({ page, abrirPesquisa }) => {
    await abrirPesquisa();
    const alvos = page.locator('[data-testid^=nota-], button');
    for (let i = 0; i < await alvos.count(); i++) {
      const caixa = await alvos.nth(i).boundingBox();
      if (!caixa) continue;
      expect(Math.min(caixa.width, caixa.height), `alvo ${i} menor que 24px`).toBeGreaterThanOrEqual(24);
    }
  });
});

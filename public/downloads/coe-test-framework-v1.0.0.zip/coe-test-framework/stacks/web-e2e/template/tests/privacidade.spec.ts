// Privacidade/LGPD (CEN-TRV-003): nada de dado pessoal em GA4/FullStory; campos livres mascarados.
import { test, expect } from '../support/coe';

const CPF = '529.982.247-25';
const EMAIL = 'cliente.teste@exemplo.com';

test('CEN-TRV-003 dado pessoal digitado não vaza para GA4 nem FullStory', async ({ page, abrirPesquisa, eventos }) => {
  await abrirPesquisa();
  await expect(page.getByLabel('Comentário (opcional)')).toHaveClass(/fs-mask/);
  await page.getByRole('radio', { name: '3 de 5' }).check();
  await page.getByLabel('Comentário (opcional)').fill(`meu cpf é ${CPF} e meu e-mail ${EMAIL}`);
  await page.getByRole('button', { name: 'Enviar' }).click();
  await expect(page.getByRole('status')).toBeVisible();

  const analytics = eventos.filter((e) => e.destino !== 'bff');
  expect(analytics.length, 'nenhum evento de analytics capturado: confira os hosts no perfil').toBeGreaterThan(0);
  const tudo = JSON.stringify(analytics);
  expect(tudo).not.toContain(CPF);
  expect(tudo).not.toContain(CPF.replace(/\D/g, ''));
  expect(tudo).not.toContain(EMAIL);
  // Varredura completa (CPF com DV, cartão, telefone...) roda no pipeline: coe-test privacidade --entrada artefatos/eventos
});

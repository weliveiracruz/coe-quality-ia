// Conteúdo da WebView testado no navegador, com a ponte nativa simulada (window.CoEPonte).
// A integração real com o app é coberta por Espresso-Web (Android) e XCUITest (iOS).
import { test, expect } from '../../support/coe';

test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    (window as any).__coe = { fechou: false };
    (window as any).CoEPonte = {
      obterToken: async () => 'token-do-app-123',
      fechar: () => { (window as any).__coe.fechou = true; },
    };
  });
});

test.describe('Pesquisa — WebView', () => {
  test('CEN-PESQ-006 página recebe o token do app pela ponte', async ({ page, abrirPesquisa, eventos }) => {
    await abrirPesquisa({ canal: 'webview' });
    await page.getByRole('radio', { name: '4 de 5' }).check();
    await page.getByRole('button', { name: 'Enviar' }).click();
    await expect(page.getByRole('status')).toHaveText('Obrigado pela sua opinião');
    const envio = eventos.find((e) => e.destino === 'bff')!;
    expect(envio.headers['authorization']).toBe('Bearer token-do-app-123');
    expect((envio.corpo as { canal: string }).canal).toBe('webview');
  });

  test('CEN-PESQ-007 "Fechar" devolve o controle ao app', async ({ page, abrirPesquisa }) => {
    await abrirPesquisa({ canal: 'webview' });
    await page.getByRole('button', { name: 'Fechar' }).click();
    expect(await page.evaluate(() => (window as any).__coe.fechou)).toBe(true);
  });

  test('CEN-TRV-004 resposta offline enviada depois sem duplicar', async ({ page, context, abrirPesquisa, eventos }) => {
    await abrirPesquisa({ canal: 'webview' });
    await page.getByRole('radio', { name: '3 de 5' }).check();
    await context.setOffline(true);
    await page.getByRole('button', { name: 'Enviar' }).click();
    await expect(page.getByText('Sem conexão. Sua resposta será enviada quando a conexão voltar.')).toBeVisible();

    await context.setOffline(false);
    await page.evaluate(() => window.dispatchEvent(new Event('online')));
    await expect(page.getByRole('status').filter({ hasText: 'Obrigado' })).toBeVisible();
    await page.waitForTimeout(500);
    const ids = eventos.filter((e) => e.destino === 'bff').map((e) => (e.corpo as { resposta_id: string }).resposta_id);
    // Pode haver tentativa que falhou offline; o que chega ao BFF é idempotente pela Idempotency-Key.
    expect(new Set(ids).size).toBe(1);
  });
});

// Cenários de negócio do Módulo de Pesquisa no canal web (Bankline e demais plataformas).
import { test, expect } from '../support/coe';
import Ajv2020 from 'ajv/dist/2020';
import fs from 'node:fs';
import path from 'node:path';

const schemaContrato = [
  process.env.COE_CONTRATOS_RAIZ && path.join(process.env.COE_CONTRATOS_RAIZ, 'schemas/resposta-pesquisa.schema.json'),
  path.resolve(process.cwd(), '.coe-framework/contracts/schemas/resposta-pesquisa.schema.json'),
  path.resolve(__dirname, '../../../../contracts/schemas/resposta-pesquisa.schema.json'),
].find((p): p is string => !!p && fs.existsSync(p));

test.describe('Pesquisa — web', () => {
  test('CEN-PESQ-001 Responder nota e enviar', async ({ page, abrirPesquisa, eventos }) => {
    await abrirPesquisa();
    await page.getByRole('radio', { name: '5 de 5' }).check();
    await page.getByRole('button', { name: 'Enviar' }).click();
    await expect(page.getByRole('status')).toHaveText('Obrigado pela sua opinião');

    const envio = eventos.find((e) => e.destino === 'bff');
    expect(envio, 'nenhuma chamada ao BFF').toBeTruthy();
    expect(envio!.headers['authorization']).toMatch(/^Bearer /);
    if (schemaContrato) {
      const validar = new Ajv2020({ strict: false }).compile(JSON.parse(fs.readFileSync(schemaContrato, 'utf8')));
      expect(validar(envio!.corpo), JSON.stringify(validar.errors)).toBe(true);
    }
  });

  test('CEN-PESQ-002 Enviar desabilitado sem nota', async ({ page, abrirPesquisa }) => {
    await abrirPesquisa();
    await expect(page.getByRole('button', { name: 'Enviar' })).toBeDisabled();
  });

  test('CEN-PESQ-003 Comentário limitado a 500 caracteres', async ({ page, abrirPesquisa }) => {
    await abrirPesquisa();
    const campo = page.getByLabel('Comentário (opcional)');
    await campo.fill('a'.repeat(550));
    await expect(campo).toHaveValue('a'.repeat(500));
    await expect(page.getByText('500 de 500 caracteres')).toBeVisible();
  });

  test('CEN-PESQ-004 Fechar a pesquisa sem responder', async ({ page, abrirPesquisa, eventos }) => {
    await abrirPesquisa();
    await page.getByRole('button', { name: 'Fechar' }).click();
    await expect(page.getByRole('dialog')).toBeHidden();
    await expect(page.getByRole('button', { name: 'Avaliar experiência' })).toBeFocused();
    expect(eventos.filter((e) => e.destino === 'bff')).toHaveLength(0);
  });

  test('CEN-PESQ-005 Falha no envio mostra alerta e permite tentar de novo', async ({ page, abrirPesquisa, perfil, eventos }) => {
    let primeira = true;
    await page.route((u) => perfil.analytics.bff.some((p) => u.pathname.endsWith(p)), async (rota) => {
      if (primeira) { primeira = false; return rota.fulfill({ status: 503 }); }
      return rota.continue();
    });
    await abrirPesquisa();
    await page.getByRole('radio', { name: '2 de 5' }).check();
    await page.getByRole('button', { name: 'Enviar' }).click();
    await expect(page.getByRole('alert')).toContainText('Tente novamente');
    await page.getByRole('button', { name: 'Tentar novamente' }).click();
    await expect(page.getByRole('status')).toHaveText('Obrigado pela sua opinião');
    const ids = eventos.filter((e) => e.destino === 'bff').map((e) => (e.corpo as { resposta_id: string }).resposta_id);
    expect(new Set(ids).size, 'a nova tentativa deve reenviar a MESMA resposta').toBe(1);
  });

  test('CEN-PESQ-009 Payload de referência para a paridade entre canais', async ({ page, abrirPesquisa, eventos }) => {
    // Resposta de referência combinada entre os canais: nota 4 + comentário "Referência CoE"
    await abrirPesquisa();
    await page.getByRole('radio', { name: '4 de 5' }).check();
    await page.getByLabel('Comentário (opcional)').fill('Referência CoE');
    await page.getByRole('button', { name: 'Enviar' }).click();
    await expect(page.getByRole('status')).toBeVisible();
    const corpo = eventos.find((e) => e.destino === 'bff')!.corpo;
    const dir = path.resolve(process.env.COE_ARTEFATOS ?? path.resolve(__dirname, '../../artefatos'), 'payloads');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'web.json'), JSON.stringify(corpo, null, 2));
    // o pipeline compara web.json, webview.json, android.json e ios.json com "coe-test payloads"
  });

  test('CEN-PESQ-008 Pesquisa como diálogo modal com foco no título e Esc fecha', async ({ page, abrirPesquisa }) => {
    await abrirPesquisa();
    await expect(page.getByRole('dialog', { name: 'Pesquisa de satisfação' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Pesquisa de satisfação' })).toBeFocused();
    await page.keyboard.press('Escape');
    await expect(page.getByRole('dialog')).toBeHidden();
  });
});

// Regressão visual. Diferença acima do limiar do perfil não reprova sozinha: vai para aprovação da squad no PR
// (o workflow publica as imagens de diferença e pede revisão; snapshots novos são atualizados com --update-snapshots).
import { test, expect } from '../support/coe';

test.describe('Visual — web', () => {
  test('pesquisa aberta', async ({ page, abrirPesquisa, perfil }) => {
    await abrirPesquisa();
    await expect(page).toHaveScreenshot('pesquisa-aberta.png', { mask: perfil.visual.mascarar.map((s) => page.locator(s)) });
  });

  test('pesquisa com erro de envio', async ({ page, abrirPesquisa, perfil }) => {
    await page.route((u) => perfil.analytics.bff.some((p) => u.pathname.endsWith(p)), (r) => r.fulfill({ status: 503 }));
    await abrirPesquisa();
    await page.getByRole('radio', { name: '1 de 5' }).check();
    await page.getByRole('button', { name: 'Enviar' }).click();
    await expect(page.getByRole('alert')).toBeVisible();
    await expect(page).toHaveScreenshot('pesquisa-erro.png', { mask: perfil.visual.mascarar.map((s) => page.locator(s)) });
  });
});

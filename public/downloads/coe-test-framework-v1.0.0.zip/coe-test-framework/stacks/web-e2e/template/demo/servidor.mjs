// Servidor da demo (COE_DEMO=1): serve a página de pesquisa e um BFF falso.
// GET  /pesquisa/satisfacao  -> página
// POST /bff/pesquisa/v1/respostas -> 201 (idempotente por Idempotency-Key)
// GET  /__coe/requisicoes     -> o que o BFF falso recebeu (para os testes conferirem)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
const pagina = fs.readFileSync(path.join(dir, 'pesquisa.html'));
const recebidas = [];
const vistas = new Set();
const porta = Number(process.env.PORT ?? 4173);

http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${porta}`);
  if (req.method === 'POST' && url.pathname === '/bff/pesquisa/v1/respostas') {
    let corpo = '';
    req.on('data', (c) => (corpo += c));
    req.on('end', () => {
      const chave = req.headers['idempotency-key'];
      if (!vistas.has(chave)) recebidas.push({ headers: { authorization: req.headers.authorization, 'idempotency-key': chave }, corpo: JSON.parse(corpo) });
      vistas.add(chave);
      res.writeHead(201, { 'Content-Type': 'application/json' }).end('{"status":"recebida"}');
    });
    return;
  }
  if (url.pathname === '/__coe/requisicoes') {
    res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify(recebidas));
    return;
  }
  if (url.pathname === '/__coe/limpar') { recebidas.length = 0; vistas.clear(); res.writeHead(204).end(); return; }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }).end(pagina);
}).listen(porta, () => console.log(`demo CoE em http://localhost:${porta}`));

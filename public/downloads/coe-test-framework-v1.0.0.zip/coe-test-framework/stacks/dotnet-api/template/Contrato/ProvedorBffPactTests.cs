using CoE.ApiEventos.Testes.Integracao;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PactNet.Verifier;
using Xunit;
using Xunit.Abstractions;

namespace CoE.ApiEventos.Testes.Contrato;

/// Sobe a API também em Kestrel (porta real), porque o verificador do Pact chama por HTTP.
/// Padrão para .NET 8: um host de teste para a fábrica e um host Kestrel para o Pact.
public sealed class ApiEventosKestrelFactory : ApiEventosFactory
{
    public Uri Url { get; private set; } = default!;

    protected override IHost CreateHost(IHostBuilder builder)
    {
        var hostDeTeste = builder.Build();
        builder.ConfigureWebHost(b => b.UseKestrel().UseUrls("http://127.0.0.1:0"));
        var hostReal = builder.Build();
        hostReal.Start();
        var enderecos = hostReal.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!;
        Url = new Uri(enderecos.Addresses.First());
        hostDeTeste.Start();
        return hostDeTeste;
    }
}

/// API de eventos como PROVEDOR: verifica o contrato do BFF versionado em contracts/bff-api (sem broker).
/// Se a API mudar algo que o BFF usa, este teste falha mostrando a interação. Roda no runner (estágio "contrato").
public class ProvedorBffPactTests(ApiEventosKestrelFactory fabrica, ITestOutputHelper saida) : IClassFixture<ApiEventosKestrelFactory>
{
    [Fact(DisplayName = "CEN-API-020 Contrato BFF -> API de eventos")]
    public void CEN_API_020_ContratoBffApiEventos()
    {
        using var _ = fabrica.CreateClient(); // força a criação dos hosts
        var pastaContratos = Environment.GetEnvironmentVariable("COE_CONTRATOS")
            ?? Path.Combine(Directory.GetCurrentDirectory(), ".coe-framework", "contracts", "bff-api");

        using var verificador = new PactVerifier("api-eventos", new PactVerifierConfig { Outputters = [new SaidaXunit(saida)] });
        verificador
            .WithHttpEndpoint(fabrica.Url)
            .WithDirectorySource(new DirectoryInfo(pastaContratos))
            .WithProviderStateUrl(new Uri(fabrica.Url, "/coe-teste/estados-provedor")) // endpoint só no ambiente CoeTeste
            .Verify();
    }

    private sealed class SaidaXunit(ITestOutputHelper o) : PactNet.Infrastructure.Outputters.IOutput
    {
        public void WriteLine(string line) => o.WriteLine(line);
    }
}

// Referência mínima usada pelos testes unitários de exemplo. A squad troca pelo validador real da API.
using System.Text.RegularExpressions;

namespace ApiEventos.Dominio;

public record Resposta(string PerguntaId, string Tipo, object Valor, bool Anonimizado = false);
public record Origem(string Canal, string ClienteRef, string? AppVersao = null);
public record DadosPesquisa(string PesquisaId, int VersaoPesquisa, IReadOnlyList<Resposta> Respostas, string? Jornada = null);
public record EventoPesquisa(string EventoId, string Tipo, Origem Origem, DateTimeOffset OcorridoEm, DadosPesquisa Dados, int VersaoSchema = 1);

public static partial class ValidadorEvento
{
    private static readonly HashSet<string> Canais = ["android", "ios", "webview", "web"];

    [GeneratedRegex("^sha256:[a-f0-9]{64}$")] private static partial Regex Pseudonimo();
    [GeneratedRegex(@"(?<!\d)\d{3}\.?\d{3}\.?\d{3}-?\d{2}(?!\d)")] private static partial Regex Cpf();

    public static IReadOnlyList<string> Validar(EventoPesquisa e, DateTimeOffset agora)
    {
        var erros = new List<string>();
        if (string.IsNullOrWhiteSpace(e.EventoId)) erros.Add("evento_id");
        if (e.Tipo != "pesquisa.respondida") erros.Add("tipo");
        if (!Canais.Contains(e.Origem.Canal)) erros.Add("origem.canal");
        if (!Pseudonimo().IsMatch(e.Origem.ClienteRef)) erros.Add("origem.cliente_ref");
        if (e.OcorridoEm > agora.AddMinutes(5)) erros.Add("ocorrido_em");
        if (e.Dados.Respostas.Count == 0) erros.Add("dados.respostas");
        foreach (var r in e.Dados.Respostas)
        {
            if (r.Tipo == "escala" && (r.Valor is not int n || n is < 1 or > 5)) erros.Add($"dados.respostas[{r.PerguntaId}].valor");
            if (r.Tipo == "texto" && Cpf().IsMatch(r.Valor.ToString() ?? "")) erros.Add($"dados.respostas[{r.PerguntaId}]: dado pessoal");
        }
        return erros;
    }
}

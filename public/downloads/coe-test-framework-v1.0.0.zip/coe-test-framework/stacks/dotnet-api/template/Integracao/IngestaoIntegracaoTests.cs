using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Testcontainers.PostgreSql;
using Xunit;

namespace CoE.ApiEventos.Testes.Integracao;

/// API de pé em memória (WebApplicationFactory) com banco real em container (Testcontainers).
/// Troque PostgreSql pelo armazenamento real da API (Kafka, SQL Server, Cosmos emulador...).
public class ApiEventosFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    private readonly PostgreSqlContainer _banco = new PostgreSqlBuilder().WithImage("postgres:16-alpine").Build();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("CoeTeste");
        builder.ConfigureAppConfiguration(c => c.AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["ConnectionStrings:Eventos"] = _banco.GetConnectionString(),
            ["Autenticacao:TokenServicoTeste"] = "token-servico-bff",
        }));
    }

    public Task InitializeAsync() => _banco.StartAsync();
    async Task IAsyncLifetime.DisposeAsync() => await _banco.DisposeAsync();
}

public class IngestaoIntegracaoTests(ApiEventosFactory fabrica) : IClassFixture<ApiEventosFactory>
{
    private static readonly string Pseudonimo = "sha256:" + string.Concat(Enumerable.Repeat("0f1e2d3c4b5a6978", 4));

    private HttpClient Cliente(string? idempotencia = null)
    {
        var c = fabrica.CreateClient();
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "token-servico-bff");
        if (idempotencia is not null) c.DefaultRequestHeaders.Add("Idempotency-Key", idempotencia);
        return c;
    }

    private static object Corpo(string id) => new
    {
        evento_id = id, tipo = "pesquisa.respondida", versao_schema = 1,
        origem = new { canal = "ios", cliente_ref = Pseudonimo },
        ocorrido_em = DateTimeOffset.UtcNow.AddSeconds(-5),
        dados = new { pesquisa_id = "PESQ-NPS-APP", versao_pesquisa = 3, respostas = new[] { new { pergunta_id = "nota", tipo = "escala", valor = 5 } } },
    };

    [Fact(DisplayName = "CEN-API-010 Ingestão aceita evento válido com 202")]
    public async Task CEN_API_010_IngestaoAceitaEventoValido()
    {
        var r = await Cliente("r-0000000401").PostAsJsonAsync("/v1/eventos", Corpo("r-0000000401"));
        r.StatusCode.Should().Be(HttpStatusCode.Accepted);
    }

    [Fact(DisplayName = "CEN-API-011 Mesmo evento duas vezes é gravado uma vez")]
    public async Task CEN_API_011_IdempotenciaNaIngestao()
    {
        await Cliente("r-0000000402").PostAsJsonAsync("/v1/eventos", Corpo("r-0000000402"));
        var segunda = await Cliente("r-0000000402").PostAsJsonAsync("/v1/eventos", Corpo("r-0000000402"));
        segunda.StatusCode.Should().BeOneOf(HttpStatusCode.OK, HttpStatusCode.Accepted);
        var consulta = await Cliente().GetFromJsonAsync<ContagemDto>("/v1/eventos/r-0000000402/contagem");
        consulta!.Total.Should().Be(1);
    }

    [Fact(DisplayName = "CEN-API-012 Sem credencial de serviço retorna 401")]
    public async Task CEN_API_012_SemCredencial()
    {
        var r = await fabrica.CreateClient().PostAsJsonAsync("/v1/eventos", Corpo("r-0000000403"));
        r.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    private record ContagemDto(int Total);
}

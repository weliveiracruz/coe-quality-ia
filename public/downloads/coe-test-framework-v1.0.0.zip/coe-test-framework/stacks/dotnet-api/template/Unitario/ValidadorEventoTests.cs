using ApiEventos.Dominio;
using FluentAssertions;
using Xunit;

namespace CoE.ApiEventos.Testes.Unitario;

/// Testes unitários (xUnit + FluentAssertions). Rodam no runner, a qualquer hora.
public class ValidadorEventoTests
{
    private static readonly DateTimeOffset Agora = new(2026, 11, 20, 12, 0, 0, TimeSpan.Zero);
    private static readonly string Pseudonimo = "sha256:" + string.Concat(Enumerable.Repeat("0f1e2d3c4b5a6978", 4));

    private static EventoPesquisa Evento(Origem? origem = null, params Resposta[] respostas) => new(
        "r-0000000001", "pesquisa.respondida", origem ?? new Origem("android", Pseudonimo), Agora,
        new DadosPesquisa("PESQ-NPS-APP", 3, respostas.Length > 0 ? respostas : [new Resposta("nota", "escala", 5)]));

    [Fact(DisplayName = "CEN-API-001 Evento válido é aceito")]
    public void CEN_API_001_EventoValidoAceito() =>
        ValidadorEvento.Validar(Evento(), Agora).Should().BeEmpty();

    [Fact(DisplayName = "CEN-API-002 CPF no lugar do pseudônimo é rejeitado")]
    public void CEN_API_002_CpfNoLugarDoPseudonimoRejeitado() =>
        ValidadorEvento.Validar(Evento(new Origem("web", "52998224725")), Agora).Should().Contain("origem.cliente_ref");

    [Theory(DisplayName = "CEN-API-003 Nota fora da escala é rejeitada")]
    [InlineData(0)]
    [InlineData(6)]
    public void CEN_API_003_NotaForaDaEscala(int nota) =>
        ValidadorEvento.Validar(Evento(null, new Resposta("nota", "escala", nota)), Agora).Should().ContainSingle();

    [Fact(DisplayName = "CEN-TRV-003 Texto livre com CPF não anonimizado é rejeitado (defesa em profundidade)")]
    public void CEN_TRV_003_TextoComCpfRejeitado() =>
        ValidadorEvento.Validar(Evento(null, new Resposta("nota", "escala", 4), new Resposta("motivo", "texto", "cpf 529.982.247-25")), Agora)
            .Should().ContainMatch("*dado pessoal*");

    [Fact(DisplayName = "CEN-API-004 Evento do futuro é rejeitado")]
    public void CEN_API_004_EventoDoFuturo() =>
        ValidadorEvento.Validar(Evento() with { OcorridoEm = Agora.AddHours(1) }, Agora).Should().Contain("ocorrido_em");
}

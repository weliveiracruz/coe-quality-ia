# Template API de eventos (.NET 8)

Criado por `coe-test init --stack dotnet-api`. Coloque o `ProjectReference` da API no `.csproj` e exponha `public partial class Program {}` para o `WebApplicationFactory`.

| Pasta | Camada | Ferramentas | Onde roda |
|---|---|---|---|
| `Unitario/` | Unitário | xUnit, FluentAssertions, NSubstitute | Runner, a qualquer hora |
| `Integracao/` | API em memória + banco real em container | WebApplicationFactory, Testcontainers | Runner |
| `Contrato/` | Provedor do contrato do BFF | PactNet, pasta versionada | Runner |

Também usados por este produto:
- Performance focada em volume e picos de ingestão: `suites/transversais/performance/api-eventos-ingestao.k6.js`, no fechamento do pacote.
- Mutação com Stryker.NET: `dotnet stryker -f coe-tests/stryker-config.json`.
- DAST com OWASP ZAP: workflow de release.

## Ambiente `CoeTeste`
A API precisa aceitar `ASPNETCORE_ENVIRONMENT=CoeTeste` com:
- token de serviço de teste (`Autenticacao:TokenServicoTeste`)
- endpoint `POST /coe-teste/estados-provedor`, que prepara os estados do Pact e só existe nesse ambiente
- endpoint `GET /v1/eventos/{id}/contagem`, usado pelos testes de idempotência e de qualidade de dados (também só em `CoeTeste` e homologação)

## Comandos que o pipeline usa
```
dotnet test coe-tests --filter "FullyQualifiedName~Unitario" --logger "junit;LogFilePath=../resultados/unitario/dotnet.xml" --collect:"XPlat Code Coverage"
dotnet test coe-tests --filter "FullyQualifiedName~Contrato"   --logger "junit;LogFilePath=../resultados/contrato/dotnet.xml"
dotnet test coe-tests --filter "FullyQualifiedName~Integracao" --logger "junit;LogFilePath=../resultados/integracao/dotnet.xml"
```

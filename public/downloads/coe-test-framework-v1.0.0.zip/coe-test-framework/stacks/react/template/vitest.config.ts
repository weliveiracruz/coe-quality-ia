import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./vitest.setup.ts'],
    include: ['**/*.test.{ts,tsx}'],
    exclude: ['**/node_modules/**', 'e2e/**'],
    reporters: ['default', 'junit'],
    outputFile: { junit: '../resultados/unitario/react-junit.xml' },
    retry: 1, // nova tentativa só para medir instabilidade (o CLI conta como instável)
    coverage: {
      provider: 'v8',
      reporter: ['lcov', 'text-summary'],
      reportsDirectory: '../artefatos/cobertura-react',
    },
  },
});

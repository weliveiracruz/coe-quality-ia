import fs from 'node:fs';
import path from 'node:path';
import { configureAxe } from 'vitest-axe';

/** axe no jsdom: contraste não é medível sem renderização real; ele é auditado no Playwright (navegador de verdade). */
export const axe = configureAxe({ rules: { 'color-contrast': { enabled: false } } });

/** Grava os eventos de analytics capturados para o scanner de privacidade do pipeline (coe-test privacidade). */
export function registrarEventosParaPrivacidade(nome: string, eventos: unknown[]) {
  const dir = path.resolve(process.env.COE_ARTEFATOS ?? 'artefatos', 'eventos');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, `${nome}.json`), JSON.stringify(eventos, null, 2));
}

// Testes de componente (Vitest + Testing Library + axe). Rodam no runner, a qualquer hora, sem ambiente.
import { describe, test, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Pesquisa, LIMITE_COMENTARIO, type RespostaPesquisa } from '../exemplo-referencia/Pesquisa';
import { registrarEventosParaPrivacidade, axe } from './suporte';

function montar(enviar = vi.fn<(r: RespostaPesquisa) => Promise<void>>().mockResolvedValue()) {
  const analytics = { registrar: vi.fn() };
  const user = userEvent.setup();
  const r = render(<Pesquisa enviar={enviar} analytics={analytics} gerarId={() => 'r-fixo'} />);
  return { ...r, user, enviar, analytics };
}

describe('Pesquisa (web)', () => {
  test('CEN-PESQ-001 Responder nota e enviar', async () => {
    const { user, enviar } = montar();
    await user.click(screen.getByRole('radio', { name: /5 de 5/ }));
    await user.click(screen.getByRole('button', { name: 'Enviar' }));
    expect(await screen.findByRole('status')).toHaveTextContent('Obrigado pela sua opinião');
    expect(enviar).toHaveBeenCalledWith(expect.objectContaining({ canal: 'web', resposta_id: 'r-fixo' }));
  });

  test('CEN-PESQ-002 Enviar desabilitado sem nota', () => {
    montar();
    expect(screen.getByRole('button', { name: 'Enviar' })).toBeDisabled();
  });

  test('CEN-PESQ-003 Comentário limitado a 500 caracteres', async () => {
    const { user } = montar();
    const campo = screen.getByLabelText('Comentário (opcional)');
    await user.click(campo);
    await user.paste('a'.repeat(LIMITE_COMENTARIO + 50));
    expect(campo).toHaveValue('a'.repeat(LIMITE_COMENTARIO));
    expect(screen.getByText(`${LIMITE_COMENTARIO} de ${LIMITE_COMENTARIO} caracteres`)).toBeInTheDocument();
  });

  test('CEN-PESQ-004 Fechar sem responder não envia', async () => {
    const aoFechar = vi.fn();
    const enviar = vi.fn();
    const user = userEvent.setup();
    render(<Pesquisa enviar={enviar} analytics={{ registrar: vi.fn() }} aoFechar={aoFechar} />);
    await user.click(screen.getByRole('button', { name: 'Fechar' }));
    expect(aoFechar).toHaveBeenCalled();
    expect(enviar).not.toHaveBeenCalled();
  });

  test('CEN-PESQ-005 Falha no envio mostra alerta e reenvia a mesma resposta', async () => {
    const enviar = vi.fn<(r: RespostaPesquisa) => Promise<void>>().mockRejectedValueOnce(new Error('503')).mockResolvedValueOnce();
    const { user } = montar(enviar);
    await user.click(screen.getByRole('radio', { name: /2 de 5/ }));
    await user.click(screen.getByRole('button', { name: 'Enviar' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Tente novamente');
    await user.click(screen.getByRole('button', { name: 'Tentar novamente' }));
    await screen.findByRole('status');
    expect(enviar.mock.calls.map(([r]) => r.resposta_id)).toEqual(['r-fixo', 'r-fixo']);
  });

  test('CEN-TRV-001 Sem violações de acessibilidade (axe)', async () => {
    const { container, user } = montar();
    expect(await axe(container)).toHaveNoViolations();
    await user.click(screen.getByRole('radio', { name: /4 de 5/ }));
    expect(await axe(container)).toHaveNoViolations();
  });

  test('CEN-TRV-003 Evento de analytics não leva o texto livre', async () => {
    const { user, analytics } = montar();
    await user.click(screen.getByRole('radio', { name: /3 de 5/ }));
    await user.type(screen.getByLabelText('Comentário (opcional)'), 'meu cpf é 529.982.247-25');
    await user.click(screen.getByRole('button', { name: 'Enviar' }));
    await screen.findByRole('status');
    const eventos = analytics.registrar.mock.calls.map(([nome, params]) => ({ evento: nome, ...params }));
    registrarEventosParaPrivacidade('react-pesquisa', eventos); // scanner do pipeline confere
    expect(JSON.stringify(eventos)).not.toContain('529.982.247-25');
  });

  test('CEN-TRV-003 Campo de texto livre mascarado no FullStory', () => {
    montar();
    expect(screen.getByLabelText('Comentário (opcional)')).toHaveClass('fs-mask');
  });
});

// Componente de REFERÊNCIA mínimo (React) para os testes de exemplo. A squad troca pelo componente real.
import { useId, useRef, useState } from 'react';

export const LIMITE_COMENTARIO = 500;

export type RespostaPesquisa = {
  pesquisa_id: string;
  versao_pesquisa: number;
  canal: 'web' | 'webview';
  resposta_id: string;
  respostas: { pergunta_id: string; tipo: string; valor: number | string }[];
};

export type Analytics = { registrar: (evento: string, params: Record<string, unknown>) => void };

type Props = {
  enviar: (r: RespostaPesquisa) => Promise<void>;
  analytics: Analytics;
  canal?: 'web' | 'webview';
  aoFechar?: () => void;
  gerarId?: () => string;
};

export function Pesquisa({ enviar, analytics, canal = 'web', aoFechar, gerarId = () => crypto.randomUUID() }: Props) {
  const [nota, setNota] = useState<number | null>(null);
  const [comentario, setComentario] = useState('');
  const [estado, setEstado] = useState<'aberta' | 'enviando' | 'erro' | 'enviada'>('aberta');
  const respostaId = useRef(gerarId());
  const idComentario = useId();

  async function aoEnviar(e: React.FormEvent) {
    e.preventDefault();
    if (nota === null) return;
    setEstado('enviando');
    const resposta: RespostaPesquisa = {
      pesquisa_id: 'PESQ-NPS-APP',
      versao_pesquisa: 3,
      canal,
      resposta_id: respostaId.current,
      respostas: [
        { pergunta_id: 'nota', tipo: 'escala', valor: nota },
        ...(comentario ? [{ pergunta_id: 'motivo', tipo: 'texto', valor: comentario }] : []),
      ],
    };
    try {
      await enviar(resposta);
      // Evento de analytics: só metadados, nunca o texto livre (LGPD).
      analytics.registrar('pesquisa_enviada', { pesquisa_id: resposta.pesquisa_id, nota, tem_comentario: comentario.length > 0, canal });
      setEstado('enviada');
    } catch {
      setEstado('erro');
    }
  }

  if (estado === 'enviada') {
    return <p role="status">Obrigado pela sua opinião</p>;
  }

  return (
    <form aria-labelledby="pesquisa-titulo" onSubmit={aoEnviar}>
      <h2 id="pesquisa-titulo" tabIndex={-1}>Pesquisa de satisfação</h2>
      <fieldset>
        <legend>De 1 a 5, quanto você recomenda o app?</legend>
        {[1, 2, 3, 4, 5].map((n) => (
          <label key={n} data-testid={`nota-${n}`} style={{ display: 'inline-flex', minWidth: 44, minHeight: 44, alignItems: 'center' }}>
            <input type="radio" name="nota" value={n} checked={nota === n} onChange={() => setNota(n)} />
            <span>{n}</span>
            <span className="sr-only">{` de 5`}</span>
          </label>
        ))}
      </fieldset>
      <label htmlFor={idComentario}>Comentário (opcional)</label>
      <textarea
        id={idComentario}
        data-testid="comentario"
        className="fs-mask"
        maxLength={LIMITE_COMENTARIO}
        value={comentario}
        aria-describedby={`${idComentario}-contador`}
        onChange={(e) => setComentario(e.target.value.slice(0, LIMITE_COMENTARIO))}
      />
      <p id={`${idComentario}-contador`} aria-live="polite">{`${comentario.length} de ${LIMITE_COMENTARIO} caracteres`}</p>
      {estado === 'erro' && <p role="alert">Não foi possível enviar. Tente novamente.</p>}
      <button type="submit" data-testid="enviar" disabled={nota === null || estado === 'enviando'}>
        {estado === 'erro' ? 'Tentar novamente' : 'Enviar'}
      </button>
      <button type="button" data-testid="fechar" onClick={aoFechar}>Fechar</button>
    </form>
  );
}

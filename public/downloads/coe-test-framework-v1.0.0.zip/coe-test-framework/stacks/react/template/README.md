# Template React

Criado por `coe-test init --stack react`. Junto vem `coe-tests/e2e/`, o Playwright compartilhado com o Angular (veja o README de lá).

| Pasta | Camada | Ferramentas | Onde roda |
|---|---|---|---|
| `unitario/` | Componente, acessibilidade (axe) e privacidade dos eventos | Vitest, Testing Library, vitest-axe | Runner, a qualquer hora |
| `e2e/` | Web (Bankline e perfis), WebView, acessibilidade, visual e privacidade | Playwright, axe-core, Lighthouse | Janela 8h–20h (ou demo local) |
| `stryker.conf.json` | Mutação | Stryker | Runner |

## Como ligar
1. Mescle `package.coe.json` (scripts e devDependencies) no `package.json` do projeto.
2. Troque `../exemplo-referencia/Pesquisa` pelo componente real e apague a pasta.
3. `npm run test:coe` gera o JUnit em `resultados/unitario` e a cobertura lcov para o SonarQube.

O contraste não é medido no jsdom; ele é auditado no navegador real pelo Playwright.

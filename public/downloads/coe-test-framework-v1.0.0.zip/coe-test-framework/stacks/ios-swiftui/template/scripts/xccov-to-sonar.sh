#!/usr/bin/env bash
# Converte a cobertura do Xcode (.xcresult) para o formato genérico do SonarQube.
# Uso: scripts/xccov-to-sonar.sh build/Resultado.xcresult > artefatos/sonar-cobertura-ios.xml
set -euo pipefail
xcresult="$1"

echo '<coverage version="1">'
xcrun xccov view --archive --file-list "$xcresult" | while read -r arquivo; do
  case "$arquivo" in *Tests*|*ExemploReferencia*) continue ;; esac
  echo "  <file path=\"${arquivo#$PWD/}\">"
  # linhas no formato "  12: 3" (executada) ou "  13: 0" (não executada); "*" = não executável
  xcrun xccov view --archive --file "$arquivo" "$xcresult" \
    | sed -nE 's/^ *([0-9]+): ([0-9]+).*$/    <lineToCover lineNumber="\1" covered="\2"\/>/p' \
    | sed -E 's/covered="0"/covered="false"/; s/covered="[1-9][0-9]*"/covered="true"/'
  echo '  </file>'
done
echo '</coverage>'

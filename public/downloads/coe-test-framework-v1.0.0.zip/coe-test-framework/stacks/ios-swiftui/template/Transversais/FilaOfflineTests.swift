import XCTest

/// Suíte transversal "rede instável" (CEN-TRV-004) no iOS, com URLProtocol simulando a rede.
final class FilaOfflineTests: XCTestCase {

    final class RedeSimulada: URLProtocol {
        static var respostas: [Result<Int, URLError>] = []
        static var recebidas: [URLRequest] = []
        override class func canInit(with request: URLRequest) -> Bool { true }
        override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
        override func startLoading() {
            Self.recebidas.append(request)
            switch Self.respostas.removeFirst() {
            case .success(let status):
                client?.urlProtocol(self, didReceive: HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: nil)!, cacheStoragePolicy: .notAllowed)
                client?.urlProtocolDidFinishLoading(self)
            case .failure(let erro):
                client?.urlProtocol(self, didFailWithError: erro)
            }
        }
        override func stopLoading() {}
    }

    /// Fila de referência. Substitua pela fila offline real do app.
    final class FilaOffline {
        private(set) var itens: [String: Data] = [:]
        let sessao: URLSession
        let url = URL(string: "https://bff.teste/bff/pesquisa/v1/respostas")!
        init(sessao: URLSession) { self.sessao = sessao }
        func enfileirar(id: String, corpo: Data) { itens[id] = corpo }
        func drenar() async -> Int {
            var enviados = 0
            for (id, corpo) in itens {
                var req = URLRequest(url: url); req.httpMethod = "POST"; req.httpBody = corpo
                req.setValue(id, forHTTPHeaderField: "Idempotency-Key")
                if let (_, resp) = try? await sessao.data(for: req), (resp as? HTTPURLResponse)?.statusCode == 201 {
                    itens[id] = nil; enviados += 1
                }
            }
            return enviados
        }
    }

    func test_CEN_TRV_004_offlineEnviaDepoisSemDuplicar() async {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.protocolClasses = [RedeSimulada.self]
        let fila = FilaOffline(sessao: URLSession(configuration: cfg))
        RedeSimulada.recebidas = []
        RedeSimulada.respostas = [.failure(URLError(.notConnectedToInternet)), .success(201)]

        fila.enfileirar(id: "r-123", corpo: Data(#"{"nota":4}"#.utf8))
        let primeira = await fila.drenar()
        XCTAssertEqual(primeira, 0)
        XCTAssertEqual(fila.itens.count, 1)

        let segunda = await fila.drenar()
        XCTAssertEqual(segunda, 1)
        let terceira = await fila.drenar()
        XCTAssertEqual(terceira, 0)
        XCTAssertEqual(RedeSimulada.recebidas.count, 2)
        XCTAssertEqual(RedeSimulada.recebidas.last?.value(forHTTPHeaderField: "Idempotency-Key"), "r-123")
    }
}

import XCTest
@testable import ModuloPesquisa

/// Testes unitários (XCTest). No PR rodam no runner macOS com o conjunto enxuto; sem ambiente.
@MainActor
final class PesquisaViewModelTests: XCTestCase {

    final class RepositorioFalso: PesquisaRepository {
        var enviadas: [RespostaPesquisa] = []
        var falhasRestantes = 0
        func enviar(_ resposta: RespostaPesquisa) async throws {
            if falhasRestantes > 0 { falhasRestantes -= 1; throw URLError(.badServerResponse) }
            enviadas.append(resposta)
        }
    }

    private var repo: RepositorioFalso!
    private var vm: PesquisaViewModel!

    override func setUp() async throws {
        repo = RepositorioFalso()
        vm = PesquisaViewModel(repo: repo, gerarId: { "r-fixo" })
    }

    func test_CEN_PESQ_001_responderNotaEEnviar() async {
        vm.selecionarNota(5)
        await vm.enviar()
        XCTAssertTrue(vm.enviada)
        XCTAssertEqual(repo.enviadas.first?.nota, 5)
        XCTAssertEqual(repo.enviadas.first?.canal, "ios")
    }

    func test_CEN_PESQ_002_enviarDesabilitadoSemNota() async {
        XCTAssertFalse(vm.podeEnviar)
        await vm.enviar()
        XCTAssertTrue(repo.enviadas.isEmpty)
    }

    func test_CEN_PESQ_003_comentarioLimitado() {
        vm.atualizarComentario(String(repeating: "a", count: 600))
        XCTAssertEqual(vm.comentario.count, limiteComentario)
    }

    func test_CEN_PESQ_005_falhaNoEnvioPermiteReenviarMesmaResposta() async {
        repo.falhasRestantes = 1
        vm.selecionarNota(2)
        await vm.enviar()
        XCTAssertNotNil(vm.erro)
        XCTAssertTrue(vm.podeEnviar)
        await vm.enviar()
        XCTAssertTrue(vm.enviada)
        XCTAssertEqual(repo.enviadas.map(\.respostaId), ["r-fixo"])
    }
}

import XCTest

/// Testes de UI SwiftUI (XCUITest) com auditoria de acessibilidade nativa (iOS 17+).
/// PR: simulador no runner macOS (janela 8h–20h). Release: matriz completa na device farm.
/// O app lê os argumentos de lançamento "-coe-ui-testing" (usa BFF falso) e "-coe-cenario <id>".
final class PesquisaUITests: XCTestCase {

    private var app: XCUIApplication!

    override func setUp() {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments += ["-coe-ui-testing"]
    }

    func test_CEN_PESQ_001_responderNotaEEnviar() {
        app.launch()
        app.buttons["nota-5"].tap()
        app.buttons["enviar"].tap()
        XCTAssertTrue(app.staticTexts["Obrigado pela sua opinião"].waitForExistence(timeout: 5))
    }

    func test_CEN_PESQ_002_enviarDesabilitadoSemNota() {
        app.launch()
        XCTAssertFalse(app.buttons["enviar"].isEnabled)
    }

    func test_CEN_PESQ_004_fecharSemResponder() {
        app.launch()
        app.buttons["fechar"].tap()
        XCTAssertFalse(app.buttons["enviar"].exists)
    }

    func test_CEN_PESQ_005_erroDoBffExibeMensagem() {
        app.launchArguments += ["-coe-bff-status", "503"]
        app.launch()
        app.buttons["nota-3"].tap()
        app.buttons["enviar"].tap()
        XCTAssertTrue(app.staticTexts["erro"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["Tentar novamente"].exists)
    }

    /// CEN-TRV-001 / CEN-TRV-006: VoiceOver (rótulos, traços), contraste, área de toque, texto cortado.
    @available(iOS 17.0, *)
    func test_CEN_TRV_001_auditoriaDeAcessibilidade() throws {
        app.launch()
        try app.performAccessibilityAudit()
        app.buttons["nota-4"].tap()
        try app.performAccessibilityAudit() // estado com nota selecionada e botão habilitado
    }

    /// CEN-TRV-002: maior tamanho de fonte de acessibilidade, sem texto cortado.
    @available(iOS 17.0, *)
    func test_CEN_TRV_002_dynamicTypeMaximo() throws {
        app.launchArguments += ["-UIPreferredContentSizeCategoryName", "UICTContentSizeCategoryAccessibilityXXXL"]
        app.launch()
        try app.performAccessibilityAudit(for: [.dynamicType, .textClipped])
        XCTAssertTrue(app.buttons["enviar"].isHittable)
    }
}

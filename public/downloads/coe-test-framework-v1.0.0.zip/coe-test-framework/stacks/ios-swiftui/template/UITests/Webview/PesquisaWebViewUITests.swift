import XCTest

/// Integração da página web (Angular ou React) com o app iOS via WKWebView.
/// O conteúdo web é testado pelo time web no Playwright; aqui o foco é a fronteira app <-> página.
/// "-coe-webview-url" aponta para a página em homologação ou para o servidor local do teste.
final class PesquisaWebViewUITests: XCTestCase {

    private var app: XCUIApplication!

    override func setUp() {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments += ["-coe-ui-testing", "-coe-abrir-pesquisa-webview"]
    }

    func test_CEN_PESQ_001_responderNotaEEnviarNaWebView() {
        app.launch()
        let web = app.webViews.firstMatch
        XCTAssertTrue(web.waitForExistence(timeout: 10), "WebView da pesquisa não carregou")
        web.buttons["Nota 5 de 5"].tap()
        web.buttons["Enviar"].tap()
        XCTAssertTrue(web.staticTexts["Obrigado pela sua opinião"].waitForExistence(timeout: 5))
    }

    func test_CEN_PESQ_006_paginaRecebeTokenDoApp() {
        app.launch()
        // O app em modo de teste expõe o último header Authorization recebido pelo BFF falso num rótulo oculto.
        app.webViews.firstMatch.buttons["Nota 4 de 5"].tap()
        app.webViews.firstMatch.buttons["Enviar"].tap()
        let auth = app.staticTexts["coe-ultimo-authorization"]
        XCTAssertTrue(auth.waitForExistence(timeout: 5))
        XCTAssertTrue(auth.label.hasPrefix("Bearer "), "Página não usou o token recebido pela ponte")
    }

    func test_CEN_PESQ_007_fecharDaPaginaDevolveControleAoApp() {
        app.launch()
        app.webViews.firstMatch.buttons["Fechar"].tap()
        XCTAssertFalse(app.webViews.firstMatch.waitForExistence(timeout: 2))
        XCTAssertTrue(app.otherElements["tela-origem"].exists)
    }

    @available(iOS 17.0, *)
    func test_CEN_TRV_001_auditoriaNoConteinerDaWebView() throws {
        app.launch()
        _ = app.webViews.firstMatch.waitForExistence(timeout: 10)
        try app.performAccessibilityAudit() // conteúdo web também é auditado com axe no Playwright
    }
}

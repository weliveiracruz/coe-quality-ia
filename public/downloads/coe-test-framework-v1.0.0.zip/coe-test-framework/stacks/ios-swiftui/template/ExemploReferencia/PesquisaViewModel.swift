// Implementação de REFERÊNCIA mínima para os testes de exemplo. Substitua pelo módulo real e apague esta pasta.
import Foundation

public let limiteComentario = 500

public struct RespostaPesquisa: Codable, Equatable {
    public let pesquisaId: String
    public let versaoPesquisa: Int
    public let canal: String
    public let respostaId: String
    public let nota: Int
    public let comentario: String?
}

public protocol PesquisaRepository {
    func enviar(_ resposta: RespostaPesquisa) async throws
}

@MainActor
public final class PesquisaViewModel: ObservableObject {
    @Published public private(set) var nota: Int?
    @Published public private(set) var comentario = ""
    @Published public private(set) var enviando = false
    @Published public private(set) var erro: String?
    @Published public private(set) var enviada = false

    private let repo: PesquisaRepository
    private let gerarId: () -> String

    public init(repo: PesquisaRepository, gerarId: @escaping () -> String = { UUID().uuidString }) {
        self.repo = repo
        self.gerarId = gerarId
    }

    public var podeEnviar: Bool { nota != nil && !enviando }

    public func selecionarNota(_ n: Int) { precondition((1...5).contains(n)); nota = n; erro = nil }

    public func atualizarComentario(_ texto: String) { comentario = String(texto.prefix(limiteComentario)) }

    private lazy var respostaId = gerarId()

    public func enviar() async {
        guard let nota else { return }
        enviando = true; erro = nil
        let r = RespostaPesquisa(pesquisaId: "PESQ-NPS-APP", versaoPesquisa: 3, canal: "ios",
                                 respostaId: respostaId, nota: nota, comentario: comentario.isEmpty ? nil : comentario)
        do { try await repo.enviar(r); enviada = true } catch { erro = "Não foi possível enviar. Tente novamente." }
        enviando = false
    }
}

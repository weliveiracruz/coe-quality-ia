# Template iOS (SwiftUI)

Criado por `coe-test init --stack ios-swiftui`. Os exemplos usam a referência em `ExemploReferencia/`. Aponte para o módulo real (`@testable import`) e apague a pasta.

| Pasta | Camada | Onde roda |
|---|---|---|
| `Unit/` | Unitário (XCTest) | Runner macOS no PR, sem ambiente |
| `UITests/` | UI SwiftUI + `performAccessibilityAudit` (VoiceOver, Dynamic Type, contraste, área de toque) | Simulador no PR (janela 8h–20h); device farm no release |
| `UITests/Webview/` | Integração app ↔ página web (WKWebView) | Igual a `UITests/` |
| `Transversais/` | Rede instável e fila offline | Runner macOS |

## Custo do runner macOS
O runner macOS custa mais. Por isso o PR roda o test plan `PR`, com unitários e um conjunto enxuto de UI. A matriz completa de aparelhos fica para o fechamento do pacote.

## Comandos que o pipeline usa
```
xcodebuild test -scheme App -testPlan CoE -only-test-configuration PR \
  -destination 'platform=iOS Simulator,name=iPhone 15' -resultBundlePath build/Resultado.xcresult
scripts/xccov-to-sonar.sh build/Resultado.xcresult > artefatos/sonar-cobertura-ios.xml
xcrun xcresulttool ... | xcresult-to-junit   # JUnit para o CLI do CoE (action ios-junit)
```

O app precisa tratar os argumentos de lançamento `-coe-ui-testing` (BFF falso), `-coe-bff-status <código>` e `-coe-abrir-pesquisa-webview`.

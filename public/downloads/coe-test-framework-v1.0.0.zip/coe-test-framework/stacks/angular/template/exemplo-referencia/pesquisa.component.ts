// Componente de REFERÊNCIA mínimo (Angular standalone) para os testes de exemplo. A squad troca pelo real.
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';

export const LIMITE_COMENTARIO = 500;

export interface RespostaPesquisa {
  pesquisa_id: string;
  versao_pesquisa: number;
  canal: 'web' | 'webview';
  resposta_id: string;
  respostas: { pergunta_id: string; tipo: string; valor: number | string }[];
}

export interface Analytics {
  registrar(evento: string, params: Record<string, unknown>): void;
}

@Component({
  selector: 'coe-pesquisa',
  standalone: true,
  template: `
    @if (estado() === 'enviada') {
      <p role="status">Obrigado pela sua opinião</p>
    } @else {
      <form aria-labelledby="pesquisa-titulo" (submit)="aoEnviar($event)">
        <h2 id="pesquisa-titulo" tabindex="-1">Pesquisa de satisfação</h2>
        <fieldset>
          <legend>De 1 a 5, quanto você recomenda o app?</legend>
          @for (n of notas; track n) {
            <label [attr.data-testid]="'nota-' + n" class="nota">
              <input type="radio" name="nota" [value]="n" [checked]="nota() === n" (change)="nota.set(n)" />
              <span>{{ n }}</span><span class="sr-only"> de 5</span>
            </label>
          }
        </fieldset>
        <label for="comentario">Comentário (opcional)</label>
        <textarea id="comentario" data-testid="comentario" class="fs-mask" [attr.maxlength]="limite"
          aria-describedby="contador" [value]="comentario()" (input)="aoDigitar($event)"></textarea>
        <p id="contador" aria-live="polite">{{ comentario().length }} de {{ limite }} caracteres</p>
        @if (estado() === 'erro') { <p role="alert">Não foi possível enviar. Tente novamente.</p> }
        <button type="submit" data-testid="enviar" [disabled]="nota() === null || estado() === 'enviando'">
          {{ estado() === 'erro' ? 'Tentar novamente' : 'Enviar' }}
        </button>
        <button type="button" data-testid="fechar" (click)="fechar.emit()">Fechar</button>
      </form>
    }
  `,
  styles: [`.nota { display: inline-flex; min-width: 44px; min-height: 44px; align-items: center; }`],
})
export class PesquisaComponent {
  @Input({ required: true }) enviar!: (r: RespostaPesquisa) => Promise<void>;
  @Input({ required: true }) analytics!: Analytics;
  @Input() canal: 'web' | 'webview' = 'web';
  @Input() gerarId: () => string = () => crypto.randomUUID();
  @Output() fechar = new EventEmitter<void>();

  readonly notas = [1, 2, 3, 4, 5];
  readonly limite = LIMITE_COMENTARIO;
  nota = signal<number | null>(null);
  comentario = signal('');
  estado = signal<'aberta' | 'enviando' | 'erro' | 'enviada'>('aberta');
  private respostaId?: string;

  aoDigitar(e: Event) {
    this.comentario.set((e.target as HTMLTextAreaElement).value.slice(0, LIMITE_COMENTARIO));
  }

  async aoEnviar(e: Event) {
    e.preventDefault();
    const nota = this.nota();
    if (nota === null) return;
    this.respostaId ??= this.gerarId();
    this.estado.set('enviando');
    const resposta: RespostaPesquisa = {
      pesquisa_id: 'PESQ-NPS-APP',
      versao_pesquisa: 3,
      canal: this.canal,
      resposta_id: this.respostaId,
      respostas: [
        { pergunta_id: 'nota', tipo: 'escala', valor: nota },
        ...(this.comentario() ? [{ pergunta_id: 'motivo', tipo: 'texto', valor: this.comentario() }] : []),
      ],
    };
    try {
      await this.enviar(resposta);
      this.analytics.registrar('pesquisa_enviada', { pesquisa_id: resposta.pesquisa_id, nota, tem_comentario: !!this.comentario(), canal: this.canal });
      this.estado.set('enviada');
    } catch {
      this.estado.set('erro');
    }
  }
}

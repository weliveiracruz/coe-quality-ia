# Template Angular

Criado por `coe-test init --stack angular`. Junto vem `coe-tests/e2e/`, o Playwright compartilhado com o React (veja o README de lá).

| Pasta | Camada | Ferramentas | Onde roda |
|---|---|---|---|
| `unitario/` | Componente, acessibilidade (axe) e privacidade dos eventos | Jest, jest-preset-angular, Angular Testing Library, jest-axe | Runner, a qualquer hora |
| `e2e/` | Web (Bankline e perfis), WebView, acessibilidade, visual e privacidade | Playwright, axe-core, Lighthouse | Janela 8h–20h (ou demo local) |
| `stryker.conf.json` | Mutação | Stryker | Runner |

## Como ligar
1. Mescle `package.coe.json` no `package.json` do projeto. A Angular Testing Library também precisa de `@angular/router`, que já existe em quase todo app.
2. Troque `../exemplo-referencia/pesquisa.component` pelo componente real e apague a pasta.
3. Mantenha o `tsconfig.spec.json` desta pasta com `target: ES2016`. Assim o async/await é convertido, e o zone.js consegue rastrear as promessas. Sem isso, um erro tratado com try/catch aparece como "unhandled".
4. `npm run test:coe` gera o JUnit em `resultados/unitario` e a cobertura lcov para o SonarQube.

// Testes de componente Angular (Jest + Angular Testing Library + jest-axe). Rodam no runner, sem ambiente.
import { render, screen } from '@testing-library/angular';
import userEvent from '@testing-library/user-event';
import { axe } from 'jest-axe';
import fs from 'node:fs';
import path from 'node:path';
import { PesquisaComponent, LIMITE_COMENTARIO, RespostaPesquisa } from '../exemplo-referencia/pesquisa.component';

async function montar(enviar: jest.Mock = jest.fn().mockResolvedValue(undefined)) {
  const analytics = { registrar: jest.fn() };
  const r = await render(PesquisaComponent, {
    componentInputs: { enviar, analytics, gerarId: () => 'r-fixo' },
  });
  return { ...r, user: userEvent.setup(), enviar, analytics };
}

describe('PesquisaComponent (Angular)', () => {
  it('CEN-PESQ-001 Responder nota e enviar', async () => {
    const { user, enviar } = await montar();
    await user.click(screen.getByRole('radio', { name: /5 de 5/ }));
    await user.click(screen.getByRole('button', { name: 'Enviar' }));
    expect(await screen.findByRole('status')).toHaveTextContent('Obrigado pela sua opinião');
    expect(enviar).toHaveBeenCalledWith(expect.objectContaining<Partial<RespostaPesquisa>>({ canal: 'web', resposta_id: 'r-fixo' }));
  });

  it('CEN-PESQ-002 Enviar desabilitado sem nota', async () => {
    await montar();
    expect(screen.getByRole('button', { name: 'Enviar' })).toBeDisabled();
  });

  it('CEN-PESQ-003 Comentário limitado a 500 caracteres', async () => {
    const { user } = await montar();
    const campo = screen.getByLabelText('Comentário (opcional)');
    await user.click(campo);
    await user.paste('a'.repeat(LIMITE_COMENTARIO + 50));
    expect(campo).toHaveValue('a'.repeat(LIMITE_COMENTARIO));
  });

  it('CEN-PESQ-005 Falha no envio mostra alerta e reenvia a mesma resposta', async () => {
    const enviar = jest.fn().mockRejectedValueOnce(new Error('503')).mockResolvedValueOnce(undefined);
    const { user } = await montar(enviar);
    await user.click(screen.getByRole('radio', { name: /2 de 5/ }));
    await user.click(screen.getByRole('button', { name: 'Enviar' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Tente novamente');
    await user.click(screen.getByRole('button', { name: 'Tentar novamente' }));
    await screen.findByRole('status');
    expect(enviar.mock.calls.map(([r]) => r.resposta_id)).toEqual(['r-fixo', 'r-fixo']);
  });

  it('CEN-TRV-001 Sem violações de acessibilidade (axe)', async () => {
    const { container } = await montar();
    expect(await axe(container, { rules: { 'color-contrast': { enabled: false } } })).toHaveNoViolations();
  });

  it('CEN-TRV-003 Evento de analytics não leva o texto livre e o campo é mascarado', async () => {
    const { user, analytics } = await montar();
    expect(screen.getByLabelText('Comentário (opcional)')).toHaveClass('fs-mask');
    await user.click(screen.getByRole('radio', { name: /3 de 5/ }));
    await user.type(screen.getByLabelText('Comentário (opcional)'), 'meu cpf é 529.982.247-25');
    await user.click(screen.getByRole('button', { name: 'Enviar' }));
    await screen.findByRole('status');
    const eventos = analytics.registrar.mock.calls.map(([evento, params]) => ({ evento, ...params }));
    const dir = path.resolve(process.env['COE_ARTEFATOS'] ?? 'artefatos', 'eventos');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'angular-pesquisa.json'), JSON.stringify(eventos));
    expect(JSON.stringify(eventos)).not.toContain('529.982.247-25');
  });
});

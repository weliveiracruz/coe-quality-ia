import type { Config } from 'jest';

const config: Config = {
  // tsconfig.spec.json (nesta pasta) usa target ES2016: o zone.js precisa do async/await convertido para rastrear promessas
  preset: 'jest-preset-angular',
  rootDir: '.',
  setupFilesAfterEnv: ['<rootDir>/setup-jest.ts'],
  testMatch: ['<rootDir>/**/*.spec.ts'],
  testPathIgnorePatterns: ['/node_modules/', '/e2e/'],
  collectCoverage: true,
  coverageDirectory: '../artefatos/cobertura-angular',
  coverageReporters: ['lcov', 'text-summary'],
  reporters: ['default', ['jest-junit', { outputDirectory: '<rootDir>/../resultados/unitario', outputName: 'angular-junit.xml', classNameTemplate: '{classname}', titleTemplate: '{title}' }]],
};

export default config;

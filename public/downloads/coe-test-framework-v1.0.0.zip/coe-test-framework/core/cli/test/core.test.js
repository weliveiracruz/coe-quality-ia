import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { validarConfig, mesclar, padroesCoE, estagiosCoE, carregarConfig } from '../src/lib/config.js';
import { avaliarJanela } from '../src/lib/janela.js';
import { montarPlano } from '../src/lib/plano.js';
import { varrer, cpfValido, luhnValido } from '../src/lib/privacidade.js';
import { lerCatalogo, mapearImplementacoes, relatorioParidade } from '../src/lib/catalogo.js';
import { lerJunit, montarMetricas, resultadosPorCenario, calcularNivel } from '../src/lib/metricas.js';
import { avaliarGates } from '../src/lib/gates.js';
import { planejarAcoes, extrairHistorias } from '../src/lib/iuclick.js';
import { compararBump } from '../src/lib/bump.js';
import { gerarEsqueleto } from '../src/lib/esqueleto.js';
import { init } from '../src/commands/init.js';
import { cpfFicticio, rng } from '../../test-data/geradores.js';

const FIX = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fixtures');
const base = { versao: 1, squad: { nome: 'Squad Teste' }, produto: 'modulo-pesquisa', stack: 'android-compose', canais: ['android'] };
const efetiva = (sobre = {}) => mesclar(padroesCoE(), mesclar(base, sobre));
// 20/11/2026 é sexta-feira. Horários em UTC-3.
const as = (hhmm) => new Date(`2026-11-20T${hhmm}:00-03:00`);

describe('configuração', () => {
  test('config mínima válida', () => assert.deepEqual(validarConfig(base), []));
  test('stack desconhecida é rejeitada', () => assert.ok(validarConfig({ ...base, stack: 'flutter' }).length > 0));
  test('squad não pode baixar cobertura mínima', () => {
    const erros = validarConfig({ ...base, quality_gate: { cobertura_minima_codigo_novo: 50 } });
    assert.match(erros.join(), /abaixo do mínimo do CoE/);
  });
  test('squad pode endurecer o gate', () => assert.deepEqual(validarConfig({ ...base, quality_gate: { cobertura_minima_codigo_novo: 90, duplicacao_maxima: 1 } }), []));
  test('squad não pode afrouxar violações de acessibilidade', () => {
    assert.match(validarConfig({ ...base, quality_gate: { a11y_violacoes_graves_max: 3 } }).join(), /acima do máximo/);
  });
  test('canal incompatível com a stack', () => assert.match(validarConfig({ ...base, canais: ['ios'] }).join(), /android-compose/));
  test('mescla mantém padrões e aplica sobrescritas', () => {
    const c = efetiva({ camadas: { e2e: true } });
    assert.equal(c.camadas.e2e, true);
    assert.equal(c.camadas.unitario, true);
    assert.equal(c.janela.fim, '20:00');
  });
});

describe('janela 8h–20h', () => {
  const j = padroesCoE().janela;
  test('dentro da janela', () => assert.equal(avaliarJanela(j, { agora: as('10:00') }).aberta, true));
  test('antes das 8h', () => {
    const r = avaliarJanela(j, { agora: as('07:30') });
    assert.equal(r.aberta, false);
    assert.equal(r.proxima_abertura_min, 30);
  });
  test('depois das 20h abre no dia seguinte', () => assert.equal(avaliarJanela(j, { agora: as('21:00') }).proxima_abertura_min, 11 * 60));
  test('não cabe perto do desligamento', () => {
    const r = avaliarJanela(j, { agora: as('19:30'), duracaoMin: 40 });
    assert.equal(r.aberta, true);
    assert.equal(r.cabe, false);
  });
  test('dias configuráveis (só dias úteis)', () => {
    const r = avaliarJanela({ ...j, dias: ['seg', 'ter', 'qua', 'qui', 'sex'] }, { agora: new Date('2026-11-21T10:00:00-03:00') });
    assert.equal(r.aberta, false);
    assert.equal(r.proxima_abertura_min, (2 * 24 - 2) * 60);
  });
});

describe('plano de execução', () => {
  const cfg = efetiva({ camadas: { e2e: true, performance: true, device_farm: true } });
  const est = estagiosCoE();
  test('PR fora da janela: só runner agora, ambiente pendente', () => {
    const p = montarPlano(cfg, est, 'pr', { agora: as('22:00') });
    assert.ok(p.executar_agora.includes('unitario'));
    assert.deepEqual(p.executar_com_ambiente, []);
    assert.ok(p.pendentes_janela.includes('e2e'));
    assert.equal(p.bloqueado, false);
  });
  test('PR na janela: roda tudo de PR, nada de release', () => {
    const p = montarPlano(cfg, est, 'pr', { agora: as('10:00') });
    assert.ok(p.executar_com_ambiente.includes('e2e'));
    assert.ok(!p.executar_com_ambiente.includes('performance'));
  });
  test('release que não cabe antes das 20h é bloqueado', () => {
    const p = montarPlano(cfg, est, 'release', { agora: as('19:00') });
    assert.equal(p.bloqueado, true);
    assert.match(p.motivo_bloqueio, /não cabe/);
  });
  test('release cedo inclui suítes pesadas', () => {
    const p = montarPlano(cfg, est, 'release', { agora: as('09:00') });
    assert.ok(p.executar_com_ambiente.includes('performance'));
    assert.ok(p.executar_com_ambiente.includes('device_farm'));
  });
  test('sobrescrita: integração só com Testcontainers roda sem ambiente', () => {
    const p = montarPlano(efetiva({ estagios: { integracao: { precisa_ambiente: false } } }), est, 'pr', { agora: as('23:00') });
    assert.ok(p.executar_agora.includes('integracao'));
  });
});

describe('privacidade / LGPD', () => {
  test('CPF válido gerado é reconhecido', () => assert.ok(cpfValido(cpfFicticio(rng(1)))));
  test('detecta CPF válido em texto livre', () => {
    const cpf = cpfFicticio(rng(7));
    const achados = varrer({ respostas: [{ valor: `meu cpf é ${cpf}` }] });
    assert.equal(achados[0].tipo, 'cpf');
    assert.equal(achados[0].caminho, '$.respostas[0].valor');
  });
  test('ignora sequência de 11 dígitos que não é CPF', () => assert.equal(varrer({ id: '12345678900' }).filter((a) => a.tipo === 'cpf').length, 0));
  test('cartão só com Luhn válido', () => {
    assert.ok(luhnValido('4111 1111 1111 1111'));
    assert.equal(varrer('pedido 1234 5678 9012 3456').length, 0);
  });
  test('campo proibido em claro e permitido quando mascarado', () => {
    assert.equal(varrer({ saldo: '1500.00' })[0].tipo, 'campo_proibido');
    assert.equal(varrer({ saldo: '****' }).length, 0);
  });
  test('e-mail em evento é detectado', () => assert.equal(varrer({ motivo: 'me liga fulano@exemplo.com' })[0].tipo, 'email'));
});

describe('catálogo e paridade', () => {
  test('catálogo válido', () => assert.deepEqual(lerCatalogo(path.join(FIX, 'catalogo.yml')).erros, []));
  test('paridade aponta lacuna no canal web', () => {
    const { catalogo } = lerCatalogo(path.join(FIX, 'catalogo.yml'));
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'coe-'));
    fs.mkdirSync(path.join(tmp, 'android'));
    fs.mkdirSync(path.join(tmp, 'web'));
    fs.writeFileSync(path.join(tmp, 'android/T.kt'), 'fun CEN_PESQ_001_x() {}\nfun CEN_PESQ_002_y() {}');
    fs.writeFileSync(path.join(tmp, 'web/t.spec.ts'), "test('CEN-PESQ-001 x')");
    const mapa = mapearImplementacoes({ android: ['android'], web: ['web'] }, tmp);
    const rel = relatorioParidade(catalogo, mapa);
    assert.equal(rel.lacunas, 1);
    assert.equal(rel.linhas[1].canais.web, 'falta');
    assert.equal(rel.cobertura_pct, 75);
  });
});

describe('métricas', () => {
  const casos = lerJunit(path.join(FIX, 'junit-android.xml'));
  test('lê JUnit e identifica instáveis', () => {
    assert.equal(casos.length, 4);
    assert.equal(casos.filter((c) => c.instavel).length, 1);
    assert.equal(casos.filter((c) => c.status === 'falhou').length, 1);
  });
  test('resultados por cenário normalizam underscore', () => {
    const r = resultadosPorCenario(casos, 'android');
    assert.equal(r['CEN-PESQ-001'].android, 'passou');
    assert.equal(r['CEN-PESQ-002'].android, 'falhou');
  });
  test('nível ouro exige camadas e nenhum gate reprovado', () => {
    const cfg = efetiva();
    assert.equal(calcularNivel(cfg, []), 'prata');
    assert.equal(calcularNivel(cfg, [{ id: 'sonar', status: 'reprovado' }]), 'nenhum');
  });
  test('JSON de métricas no formato do schema', () => {
    const m = montarMetricas({ config: efetiva(), casos, gates: [], execucao: { id: '1', momento: 'pr', inicio: new Date().toISOString(), duracao_s: 10 } });
    assert.equal(m.testes.total, 4);
    assert.equal(m.squad, 'Squad Teste');
  });
});

describe('gates', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gates-'));
  fs.writeFileSync(path.join(dir, 'acessibilidade.json'), JSON.stringify([{ id: 'color-contrast', impact: 'serious' }, { id: 'region', impact: 'moderate' }]));
  fs.writeFileSync(path.join(dir, 'performance.json'), JSON.stringify({ metrics: { http_req_duration: { 'p(95)': 420 }, http_req_failed: { value: 0.001 } } }));
  const a = (n) => path.join(dir, n);
  test('violação grave de acessibilidade reprova; moderada não', () => {
    const g = avaliarGates(efetiva(), { acessibilidade: a('acessibilidade.json') });
    const ac = g.find((x) => x.id === 'acessibilidade');
    assert.equal(ac.status, 'reprovado');
    assert.match(ac.motivo, /color-contrast/);
  });
  test('performance dentro do SLO aprova', () => assert.equal(avaliarGates(efetiva(), { performance: a('performance.json') }).find((x) => x.id === 'performance').status, 'aprovado'));
  test('gate sem artefato de estágio pendente fica pendente', () => assert.equal(avaliarGates(efetiva(), {}, ['e2e', 'acessibilidade']).find((x) => x.id === 'acessibilidade').status, 'pendente'));
});

describe('IU Click', () => {
  const cfg = efetiva({ iuclick: { habilitado: true, mover_tasks: true, status: { aprovado: 'Homologado' } } });
  const metr = (gates) => ({ squad: 'S', execucao: { momento: 'pr' }, testes: { total: 1, passaram: 1, falharam: 0, instaveis: 0 }, gates });
  test('status de destino é parametrizável', () => {
    const { acoes } = planejarAcoes(cfg, metr([{ id: 'sonar', status: 'aprovado' }]), ['PESQ-1']);
    assert.equal(acoes.find((a) => a.ferramenta === 'iuclick_move_task').argumentos.status, 'Homologado');
  });
  test('reprovado volta com o motivo', () => {
    const { acoes } = planejarAcoes(cfg, metr([{ id: 'contrato', status: 'reprovado', motivo: 'campo nota removido' }]), ['PESQ-1']);
    const mover = acoes.find((a) => a.ferramenta === 'iuclick_move_task');
    assert.equal(mover.argumentos.status, 'Em desenvolvimento');
    assert.match(mover.argumentos.reason, /campo nota/);
  });
  test('com gate pendente não move a task', () => {
    const { acoes } = planejarAcoes(cfg, metr([{ id: 'e2e', status: 'pendente' }]), ['PESQ-1']);
    assert.equal(acoes.filter((a) => a.ferramenta === 'iuclick_move_task').length, 0);
  });
  test('extrai histórias do título do PR, ignorando IDs de cenário', () => assert.deepEqual(extrairHistorias('PESQ-1234: corrige CEN-PESQ-001 e PESQ-99'), ['PESQ-1234', 'PESQ-99']));
});

describe('bump do FullStory', () => {
  const b = { versao_fullstory: '1.50.0', tamanho_bytes: 1000, inicializacao_ms_p50: 100, api_publica: ['track(String)', 'identify(String)'], inicializou: true, firebase_eventos_ok: true, sessao_capturada: true, testes: { total: 10, falharam: 0 } };
  test('bump sem regressão aprova', () => assert.equal(compararBump(b, { ...b, versao_fullstory: '1.51.0', tamanho_bytes: 1030 }).aprovado, true));
  test('API removida reprova', () => {
    const r = compararBump(b, { ...b, api_publica: ['track(String)'] });
    assert.equal(r.aprovado, false);
    assert.match(r.verificacoes.find((v) => v.id === 'api_publica_wrapper').detalhe, /identify/);
  });
  test('inicialização 20% mais lenta reprova', () => assert.equal(compararBump(b, { ...b, inicializacao_ms_p50: 120 }).aprovado, false));
});

describe('esqueleto e init', () => {
  const c = { id: 'CEN-PESQ-001', titulo: 'Responder nota e enviar', gherkin: 'Dado A\nQuando B\nEntão C' };
  test('esqueleto Android usa underscore e traz os passos', () => {
    const s = gerarEsqueleto(c, 'android-compose');
    assert.match(s, /fun CEN_PESQ_001_responderNotaEEnviar\(\)/);
    assert.match(s, /\/\/ Então C/);
  });
  test('esqueleto web usa o ID com hífen', () => assert.match(gerarEsqueleto(c, 'react'), /test\('CEN-PESQ-001 Responder nota e enviar'/));
  test('init gera coe-test.yml válido e workflow', async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'init-'));
    await init({ stack: 'react', produto: 'modulo-pesquisa', squad: 'Squad Web', canais: 'web,webview', dir }, { log: () => {}, interativo: false });
    const cfg = carregarConfig(path.join(dir, 'coe-test.yml'));
    assert.deepEqual(cfg.perfis_web, ['bankline']);
    assert.ok(fs.existsSync(path.join(dir, '.github/workflows/coe-qualidade.yml')));
    await assert.rejects(init({ stack: 'react', produto: 'x', squad: 'y', dir }, { log: () => {}, interativo: false }), /Já existe/);
  });
});

import { compararPayloads } from '../src/lib/payload.js';
describe('paridade de payload (CEN-PESQ-009)', () => {
  const web = { pesquisa_id: 'PESQ-NPS-APP', versao_pesquisa: 3, canal: 'web', resposta_id: 'r-aaaaaaaa', respostas: [{ pergunta_id: 'nota', tipo: 'escala', valor: 4 }], contexto: { plataforma: 'web' } };
  test('variam só canal e plataforma', () => assert.equal(compararPayloads({ web, android: { ...web, canal: 'android', resposta_id: 'r-bbbbbbbb', contexto: { plataforma: 'android' } } }).ok, true));
  test('nota como texto no iOS diverge', () => {
    const r = compararPayloads({ web, ios: { ...web, canal: 'ios', respostas: [{ pergunta_id: 'nota', tipo: 'escala', valor: '4' }] } });
    assert.equal(r.ok, false);
    assert.match(r.divergencias[0], /valor/);
  });
});

import Ajv2020 from 'ajv/dist/2020.js';
describe('contratos versionados', () => {
  const RAIZ_FW = path.resolve(FIX, '../../../..');
  const ajv = new Ajv2020({ strict: false });
  ajv.addFormat('date-time', (s) => !Number.isNaN(Date.parse(s)));
  const camadas = [['canais-bff', 'resposta-pesquisa'], ['bff-api', 'evento-pesquisa']];
  for (const [camada, schema] of camadas) {
    const validar = ajv.compile(JSON.parse(fs.readFileSync(path.join(RAIZ_FW, 'contracts/schemas', `${schema}.schema.json`), 'utf8')));
    for (const arq of fs.readdirSync(path.join(RAIZ_FW, 'contracts', camada))) {
      test(`${camada}/${arq}: exemplos de sucesso respeitam o schema ${schema}`, () => {
        const pact = JSON.parse(fs.readFileSync(path.join(RAIZ_FW, 'contracts', camada, arq), 'utf8'));
        for (const it of pact.interactions.filter((i) => i.response.status < 400)) {
          assert.ok(validar(it.request.body), `${it.description}: ${JSON.stringify(validar.errors)}`);
        }
      });
    }
  }
});

import { compararRespostaEvento } from '../../../suites/transversais/qualidade-dados/regras.mjs';
describe('qualidade de dados ponta a ponta', () => {
  const resposta = { pesquisa_id: 'PESQ-NPS-APP', versao_pesquisa: 3, canal: 'ios', resposta_id: 'r-1', respostas: [{ pergunta_id: 'nota', tipo: 'escala', valor: 4 }, { pergunta_id: 'motivo', tipo: 'texto', valor: 'cpf 529.982.247-25' }] };
  const ok = { evento_id: 'r-1', origem: { canal: 'ios', cliente_ref: `sha256:${'a'.repeat(64)}` }, dados: { pesquisa_id: 'PESQ-NPS-APP', versao_pesquisa: 3, respostas: [{ pergunta_id: 'nota', tipo: 'escala', valor: 4 }, { pergunta_id: 'motivo', tipo: 'texto', valor: 'cpf [cpf]', anonimizado: true }] } };
  test('evento íntegro', () => assert.deepEqual(compararRespostaEvento(resposta, ok), []));
  test('nota alterada e CPF gravado em claro são apontados', () => {
    const ruim = structuredClone(ok);
    ruim.dados.respostas[0].valor = 5;
    ruim.dados.respostas[1] = { pergunta_id: 'motivo', tipo: 'texto', valor: 'cpf 529.982.247-25' };
    const f = compararRespostaEvento(resposta, ruim);
    assert.ok(f.some((x) => x.includes('nota')));
    assert.ok(f.some((x) => x.includes('não anonimizado')));
    assert.ok(f.some((x) => x.includes('dado pessoal gravado')));
  });
  test('evento ausente', () => assert.deepEqual(compararRespostaEvento(resposta, null), ['evento não encontrado na API de eventos']));
});

// coe-test init: cria a estrutura de testes da squad a partir do template da stack.
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import YAML from 'yaml';
import { RAIZ, validarConfig } from '../lib/config.js';

const STACKS = ['android-compose', 'ios-swiftui', 'kotlin-bff', 'dotnet-api', 'angular', 'react'];
const CANAIS_POR_STACK = {
  'android-compose': ['android', 'webview'],
  'ios-swiftui': ['ios', 'webview'],
  angular: ['web', 'webview'],
  react: ['web', 'webview'],
  'kotlin-bff': [],
  'dotnet-api': [],
};
const CAMADAS_POR_STACK = {
  'android-compose': { mutacao: false, e2e: true, rede_instavel: true, device_farm: true, visual: false },
  'ios-swiftui': { mutacao: false, e2e: true, rede_instavel: true, device_farm: true },
  angular: { e2e: true, visual: true, mutacao: true },
  react: { e2e: true, visual: true, mutacao: true },
  'kotlin-bff': { mutacao: true, performance: true, dast: true, resiliencia: true, acessibilidade: false, qualidade_dados: true },
  'dotnet-api': { mutacao: true, performance: true, dast: true, acessibilidade: false, qualidade_dados: true },
};

const IGNORAR = new Set(['node_modules', 'test-results', 'package.json', 'package-lock.json', '.DS_Store']);

function copiarDir(origem, destino, criados) {
  for (const ent of fs.readdirSync(origem, { withFileTypes: true })) {
    if (IGNORAR.has(ent.name)) continue;
    const o = path.join(origem, ent.name);
    const d = path.join(destino, ent.name);
    if (ent.isDirectory()) copiarDir(o, d, criados);
    else if (!fs.existsSync(d)) {
      fs.mkdirSync(path.dirname(d), { recursive: true });
      fs.copyFileSync(o, d);
      criados.push(d);
    }
  }
}

export function montarConfig({ squad, produto, stack, canais, nivel = 'bronze', perfisWeb = [] }) {
  const cfg = {
    versao: 1,
    framework_versao: 'v1',
    squad: { nome: squad, pm: '', tech_lead: '', nivel_alvo: nivel },
    produto,
    stack,
    ...(canais.length ? { canais } : {}),
    camadas: CAMADAS_POR_STACK[stack],
    ambientes: { hml: { url: 'https://hml.exemplo.itau', auth: 'token-servico' } },
    ...(perfisWeb.length ? { perfis_web: perfisWeb } : {}),
    catalogo: {
      // O catálogo é central (products/<produto>/catalogo/cenarios.yml no framework); aqui só o mapa canal -> pastas.
      implementacoes: Object.fromEntries((canais.length ? canais : ['servico']).map((c) => [c, ['coe-tests']])),
    },
    iuclick: { habilitado: false, projeto: '' },
  };
  return cfg;
}

function workflow(stack) {
  return `# Gerado por coe-test init. A lógica fica no workflow reutilizável do CoE; a squad só chama.
name: Qualidade CoE
on:
  pull_request:
  push:
    branches: [main, "release/**"]
  schedule:
    - cron: "5 11 * * *"   # 08:05 em Brasília: janela abriu, reexecuta PRs com testes de ambiente pendentes
  workflow_dispatch:
    inputs:
      momento:
        description: "pr | release (fechamento do pacote para produção)"
        default: pr

jobs:
  qualidade:
    uses: itau-coe/coe-test-framework/.github/workflows/coe-pipeline.yml@v1
    with:
      stack: ${stack}
      momento: \${{ github.event_name == 'schedule' && 'agendado' || startsWith(github.ref_name, 'release/') && 'release' || inputs.momento || 'pr' }}
    secrets: inherit
`;
}

export async function init(opcoes, { log = console.log, interativo = process.stdin.isTTY } = {}) {
  let { stack, produto, squad, canais, dir = '.', nivel, perfis } = opcoes;
  if (interativo && (!stack || !produto || !squad)) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    squad ||= await rl.question('Nome da squad: ');
    stack ||= await rl.question(`Stack (${STACKS.join(', ')}): `);
    produto ||= await rl.question('Produto (ex.: modulo-pesquisa, bff-kotlin, api-eventos): ');
    if (!canais && CANAIS_POR_STACK[stack]?.length) {
      canais = await rl.question(`Canais (${CANAIS_POR_STACK[stack].join(', ')}) separados por vírgula: `);
    }
    rl.close();
  }
  if (!STACKS.includes(stack)) throw new Error(`Stack inválida: ${stack}. Use uma de: ${STACKS.join(', ')}`);
  if (!produto || !squad) throw new Error('Informe --produto e --squad.');
  const listaCanais = (canais ? String(canais).split(',').map((c) => c.trim()).filter(Boolean) : CANAIS_POR_STACK[stack].slice(0, 1));
  const perfisWeb = perfis ? String(perfis).split(',') : ['web', 'webview'].some((c) => listaCanais.includes(c)) ? ['bankline'] : [];

  const destino = path.resolve(dir);
  const arqCfg = path.join(destino, 'coe-test.yml');
  if (fs.existsSync(arqCfg)) throw new Error(`Já existe ${arqCfg}. Edite o arquivo ou apague para recriar.`);

  const cfg = montarConfig({ squad, produto, stack, canais: listaCanais, nivel, perfisWeb });
  const erros = validarConfig(cfg);
  if (erros.length) throw new Error(`Configuração gerada inválida:\n - ${erros.join('\n - ')}`);

  const criados = [];
  fs.mkdirSync(destino, { recursive: true });
  fs.writeFileSync(arqCfg, `# Configuração de testes da squad — único arquivo que a squad edita.\n# Referência: docs/guia-adocao.md | Schema: core/schemas/coe-test.schema.json\n${YAML.stringify(cfg)}`);
  criados.push(arqCfg);

  const wf = path.join(destino, '.github/workflows/coe-qualidade.yml');
  fs.mkdirSync(path.dirname(wf), { recursive: true });
  if (!fs.existsSync(wf)) { fs.writeFileSync(wf, workflow(stack)); criados.push(wf); }

  const template = path.join(RAIZ, 'stacks', stack, 'template');
  if (fs.existsSync(template)) copiarDir(template, path.join(destino, 'coe-tests'), criados);
  // Angular e React compartilham o E2E (Playwright): web, demais plataformas e conteúdo da WebView
  if (['angular', 'react'].includes(stack)) {
    copiarDir(path.join(RAIZ, 'stacks', 'web-e2e', 'template'), path.join(destino, 'coe-tests', 'e2e'), criados);
  }

  log(`Squad ${squad} pronta (${stack}, produto ${produto}, canais: ${listaCanais.join(', ') || 'n/a'}).`);
  log(`${criados.length} arquivo(s) criado(s):`);
  for (const c of criados) log(`  + ${path.relative(destino, c)}`);
  log('Próximos passos: revisar coe-test.yml, rodar "coe-test validate" e abrir o primeiro PR.');
  return criados;
}

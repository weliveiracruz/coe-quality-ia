// Massa de dados sintética do CoE. Nunca usar dados reais de cliente em teste.
// Gera CPFs válidos porém fictícios, tokens de teste e respostas de pesquisa.
// Uso: node core/test-data/geradores.js respostas 10 > respostas.json

export function rng(semente = 42) {
  let s = semente >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 2 ** 32);
}

export function cpfFicticio(aleatorio = Math.random) {
  const d = Array.from({ length: 9 }, () => Math.floor(aleatorio() * 10));
  const dv = (base) => {
    const s = base.reduce((acc, n, i) => acc + n * (base.length + 1 - i), 0);
    const r = (s * 10) % 11;
    return r === 10 ? 0 : r;
  };
  d.push(dv(d));
  d.push(dv(d));
  return d.join('');
}

export function tokenTeste({ sub = 'cliente-teste', expiraEmSeg = 3600, agora = Math.floor(Date.now() / 1000) } = {}) {
  const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
  return `${b64({ alg: 'none', typ: 'JWT' })}.${b64({ sub, iat: agora, exp: agora + expiraEmSeg, aud: 'bff-pesquisa' })}.`;
}

export const CANAIS = ['android', 'ios', 'webview', 'web'];

/** Resposta de pesquisa no formato do contrato canais -> BFF (contracts/schemas/resposta-pesquisa.schema.json). */
export function respostaPesquisa(aleatorio = Math.random, canal = 'web') {
  const nota = 1 + Math.floor(aleatorio() * 5);
  return {
    pesquisa_id: 'PESQ-NPS-APP',
    versao_pesquisa: 3,
    canal,
    resposta_id: `r-${Math.floor(aleatorio() * 1e12).toString(36)}`,
    respondida_em: new Date(Date.UTC(2026, 10, 20, 12, 0, 0)).toISOString(),
    respostas: [
      { pergunta_id: 'nota', tipo: 'escala', valor: nota },
      { pergunta_id: 'motivo', tipo: 'texto', valor: nota >= 4 ? 'App rápido' : 'Demorou para carregar' },
    ],
    contexto: { jornada: 'pix', app_versao: '9.12.0', plataforma: canal },
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const [tipo = 'respostas', qtd = '5'] = process.argv.slice(2);
  const r = rng(Number(process.env.SEMENTE ?? 42));
  const lista = Array.from({ length: Number(qtd) }, (_, i) =>
    tipo === 'cpf' ? cpfFicticio(r) : respostaPesquisa(r, CANAIS[i % CANAIS.length]));
  console.log(JSON.stringify(lista, null, 2));
}

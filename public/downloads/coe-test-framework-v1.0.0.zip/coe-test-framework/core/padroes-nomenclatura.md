# Padrões de nomenclatura

## Cenários
- ID: `CEN-<PRODUTO>-<NNN>`, por exemplo `CEN-PESQ-001` (módulo de pesquisa), `CEN-BFF-004`, `CEN-API-002`. Os transversais do CoE usam `CEN-TRV-NNN`.
- Em linguagens que não aceitam hífen em nome de método (Kotlin, Swift, C#), use underscore: `CEN_PESQ_001_...`. O framework entende os dois formatos.
- Todo teste ligado a um cenário leva o ID **no nome do teste**. É assim que a paridade entre canais e o IU Click enxergam o resultado.

## Testes
| Stack | Padrão | Exemplo |
|---|---|---|
| Android / BFF (Kotlin) | `CEN_XXX_NNN_descricaoEmCamelCase` | `CEN_PESQ_001_responderNotaEEnviar()` |
| iOS (Swift) | `test_CEN_XXX_NNN_descricao` | `test_CEN_PESQ_001_responderNotaEEnviar()` |
| .NET | `CEN_XXX_NNN_Descricao` + `DisplayName` com hífen | `[Fact(DisplayName = "CEN-API-001 ...")]` |
| Web (Playwright/Jest/Vitest) | `'CEN-XXX-NNN descrição em português'` | `test('CEN-PESQ-001 responder nota e enviar')` |

Testes técnicos sem cenário de negócio (por exemplo, um utilitário) seguem `deve<Comportamento>Quando<Condicao>`.

## Pastas na squad
```
coe-tests/
  unitario/        testes unitários (ou src/test, conforme a stack)
  integracao/
  contrato/
  e2e/
  acessibilidade/
  performance/
resultados/<camada>/*.xml   saída JUnit consumida pelo CLI (a pasta define a camada)
artefatos/*.json            insumos dos gates (sonar.json, acessibilidade.json, ...)
```

## Histórias do IU Click
- Título do PR ou commit com o ID da história, por exemplo `PESQ-1234: ajusta botão enviar`. O pipeline extrai o ID e grava o resultado nela.
- No catálogo, o campo `historia` do cenário aponta para a história de origem.

## Massa de dados
- Somente dados sintéticos de `core/test-data` (CPF válido porém fictício, tokens de teste).
- É proibido usar dado de produção em teste, inclusive mascarado.

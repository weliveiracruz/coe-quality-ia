#!/usr/bin/env bash
# Cria/atualiza o quality gate "CoE" no SonarQube interno e o define como padrão.
# Executado uma vez pelo CoE (e a cada mudança de regra). Requer token de administrador.
# Uso: SONAR_HOST_URL=https://sonar.interno SONAR_TOKEN=... core/sonar/configurar-quality-gate.sh
set -euo pipefail
: "${SONAR_HOST_URL:?defina SONAR_HOST_URL}"; : "${SONAR_TOKEN:?defina SONAR_TOKEN}"
NOME=${COE_QG_NOME:-CoE}
api() { curl -sf -u "$SONAR_TOKEN:" -X POST "$SONAR_HOST_URL/api/$1" "${@:2}"; }

# Valores espelham core/defaults/coe-defaults.yml (quality_gate)
COBERTURA=$(grep cobertura_minima_codigo_novo core/defaults/coe-defaults.yml | awk '{print $2}')
DUPLICACAO=$(grep duplicacao_maxima core/defaults/coe-defaults.yml | awk '{print $2}')

api qualitygates/create --data-urlencode "name=$NOME" >/dev/null 2>&1 || echo "Quality gate $NOME já existe; recriando condições."
# remove condições antigas
for id in $(curl -sf -u "$SONAR_TOKEN:" "$SONAR_HOST_URL/api/qualitygates/show?name=$NOME" | jq -r '.conditions[].id'); do
  api qualitygates/delete_condition --data-urlencode "id=$id" >/dev/null
done

cond() { api qualitygates/create_condition --data-urlencode "gateName=$NOME" --data-urlencode "metric=$1" --data-urlencode "op=$2" --data-urlencode "error=$3" >/dev/null; echo "  + $1 $2 $3"; }
echo "Condições do quality gate $NOME (código novo):"
cond new_coverage LT "$COBERTURA"                 # cobertura mínima no código novo
cond new_duplicated_lines_density GT "$DUPLICACAO" # duplicação máxima
cond new_reliability_rating GT 1                   # zero bugs (nota A)
cond new_security_rating GT 1                      # zero vulnerabilidades (nota A)
cond new_blocker_violations GT 0                   # zero bloqueantes
cond new_security_hotspots_reviewed LT 100         # hotspots revisados

api qualitygates/set_as_default --data-urlencode "name=$NOME" >/dev/null
echo "Quality gate $NOME definido como padrão."

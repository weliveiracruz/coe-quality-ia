# Produto: API de eventos (.NET)

Só recebe chamadas do BFF. Valida o evento (defesa em profundidade contra dado pessoal), aplica idempotência e grava.

## O que o framework cobre
- **Unitário:** validação de evento (CEN-API-001 a 004 e CEN-TRV-003).
- **Integração:** ingestão, idempotência e credencial com banco em container (CEN-API-010 a 012).
- **Contrato:** provedor de `contracts/bff-api` (CEN-API-020).
- **Performance:** volume e picos de ingestão com k6, no fechamento do pacote.
- **Qualidade de dados ponta a ponta:** resposta enviada no canal chega íntegra aqui (`suites/transversais/qualidade-dados`).
- **Mutação:** Stryker.NET. **Segurança:** Semgrep, Dependency-Check e ZAP.

Catálogo: `catalogo/cenarios.yml`. Template: `stacks/dotnet-api/template`. Exemplo de configuração: `examples/coe-test.api-eventos.yml`.

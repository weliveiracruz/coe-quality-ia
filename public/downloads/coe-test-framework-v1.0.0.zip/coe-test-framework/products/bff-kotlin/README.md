# Produto: BFF Kotlin (pesquisa)

Porta única dos canais. Valida token e demais camadas, anonimiza texto livre, aplica idempotência e encaminha à API de eventos .NET.

## O que o framework cobre
- **Contrato duplo:** provedor dos quatro canais (`contracts/canais-bff`) e consumidor da API (`contracts/bff-api`).
- **Autenticação:** token válido, expirado, inválido, ausente e de outra audiência (CEN-BFF-010 a 014).
- **Resiliência:** retry, timeout, API fora do ar e circuit breaker (CEN-BFF-020 a 023). No release, repete com Toxiproxy no ambiente.
- **Privacidade:** anonimização e pseudônimo do cliente (CEN-BFF-002 e CEN-TRV-003).
- **Performance:** k6 com os SLOs do `coe-test.yml` (p95, p99, taxa de erro), no fechamento do pacote.
- **Segurança:** Semgrep, Gitleaks, Dependency-Check no PR; OWASP ZAP no release.

Catálogo: `catalogo/cenarios.yml`. Template: `stacks/kotlin-bff/template`. Exemplo de configuração: `examples/coe-test.bff-kotlin.yml`.

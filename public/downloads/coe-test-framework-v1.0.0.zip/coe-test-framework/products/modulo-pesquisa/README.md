# Produto: Módulo de Pesquisa

Pesquisa de satisfação disponível em quatro canais. Todos falam **somente com o BFF Kotlin**, que valida o token e repassa para a API de eventos .NET.

```
Android (Compose) ─┐
iOS (SwiftUI) ─────┤
WebView (Angular/React) ─┼──> BFF Kotlin (token, camadas) ──> API de eventos .NET
Web: Bankline e outras ──┘
```

## Onde está cada coisa
| Item | Local |
|---|---|
| Catálogo de cenários (PM escreve, todos implementam) | `catalogo/cenarios.yml` |
| Cenários transversais herdados | `suites/transversais/catalogo-transversal.yml` |
| Contrato canais → BFF | `contracts/schemas/resposta-pesquisa.schema.json` e `contracts/canais-bff/` |
| Testes por canal | `stacks/android-compose`, `stacks/ios-swiftui`, `stacks/angular`, `stacks/react`, `stacks/web-e2e` |
| Perfis web | `platforms/web/perfis/` |

## Paridade entre canais
`coe-test catalogo paridade --produto modulo-pesquisa` cruza o catálogo com os testes de cada canal e mostra o que falta. No nível ouro, a lacuna bloqueia o merge.

Exemplo de saída (dentro do próprio framework, contra os templates):
```
| Cenário | android | ios | webview | web |
| CEN-PESQ-001 Responder nota e enviar | implementado | implementado | implementado | implementado |
| CEN-PESQ-004 Fechar a pesquisa sem responder | FALTA | implementado | FALTA | implementado |
```

## Matriz de testes do produto
| Camada | Android | iOS | WebView | Web |
|---|---|---|---|---|
| Unitário / componente | JUnit 5, MockK | XCTest | Jest/Vitest (Angular/React) | Jest/Vitest |
| UI / E2E | Compose UI Test | XCUITest | Espresso-Web, XCUITest e Playwright com ponte simulada | Playwright (Chromium, Firefox, WebKit) |
| Acessibilidade | ATF (TalkBack, contraste, toque) | `performAccessibilityAudit` | axe + auditoria nativa | axe, teclado, reflow, Lighthouse |
| Visual | não se aplica | não se aplica | Playwright | Playwright |
| Privacidade | Marcação de campo sensível + scanner | Scanner | Scanner | Scanner + `fs-mask` |
| Rede instável | MockWebServer | URLProtocol | `setOffline` | não se aplica |
| Contrato | Schema + Pact (consumidor) | Schema + Pact | Schema | Schema + Pact |

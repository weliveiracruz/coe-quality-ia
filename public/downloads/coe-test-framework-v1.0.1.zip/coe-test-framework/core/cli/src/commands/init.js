// coe-test init: cria a estrutura de testes da squad a partir do template da stack.
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import YAML from 'yaml';
import { RAIZ, validarConfig } from '../lib/config.js';

const STACKS = ['android-compose', 'ios-swiftui', 'kotlin-bff', 'dotnet-api', 'angular', 'react'];
const CANAIS_POR_STACK = {
  'android-compose': ['android', 'webview'],
  'ios-swiftui': ['ios', 'webview'],
  angular: ['web', 'webview'],
  react: ['web', 'webview'],
  'kotlin-bff': [],
  'dotnet-api': [],
};
const CAMADAS_POR_STACK = {
  'android-compose': { mutacao: false, e2e: true, rede_instavel: true, device_farm: true, visual: false },
  'ios-swiftui': { mutacao: false, e2e: true, rede_instavel: true, device_farm: true },
  angular: { e2e: true, visual: true, mutacao: true },
  react: { e2e: true, visual: true, mutacao: true },
  'kotlin-bff': { mutacao: true, performance: true, dast: true, resiliencia: true, acessibilidade: false, qualidade_dados: true },
  'dotnet-api': { mutacao: true, performance: true, dast: true, acessibilidade: false, qualidade_dados: true },
};

const IGNORAR = new Set(['node_modules', 'test-results', 'package.json', 'package-lock.json', '.DS_Store']);

function copiarDir(origem, destino, criados) {
  for (const ent of fs.readdirSync(origem, { withFileTypes: true })) {
    if (IGNORAR.has(ent.name)) continue;
    const o = path.join(origem, ent.name);
    const d = path.join(destino, ent.name);
    if (ent.isDirectory()) copiarDir(o, d, criados);
    else if (!fs.existsSync(d)) {
      fs.mkdirSync(path.dirname(d), { recursive: true });
      fs.copyFileSync(o, d);
      criados.push(d);
    }
  }
}

export function montarConfig({ squad, produto, stack, canais, nivel = 'bronze', perfisWeb = [], catalogoLocal = null }) {
  const cfg = {
    versao: 1,
    framework_versao: 'v1',
    squad: { nome: squad, pm: '', tech_lead: '', nivel_alvo: nivel },
    produto,
    stack,
    ...(canais.length ? { canais } : {}),
    camadas: CAMADAS_POR_STACK[stack],
    ambientes: { hml: { url: 'https://hml.exemplo.itau', auth: 'token-servico' } },
    ...(perfisWeb.length ? { perfis_web: perfisWeb } : {}),
    catalogo: {
      // O catálogo é central (products/<produto>/catalogo/cenarios.yml no framework). Produto novo: catálogo no repositório da squad.
      ...(catalogoLocal ? { arquivo: catalogoLocal } : {}),
      implementacoes: Object.fromEntries((canais.length ? canais : ['servico']).map((c) => [c, ['coe-tests']])),
    },
    iuclick: { habilitado: false, projeto: '' },
  };
  return cfg;
}

function workflow(stack) {
  return `# Gerado por coe-test init. A lógica fica no workflow reutilizável do CoE; a squad só chama.
name: Qualidade CoE
on:
  pull_request:
  push:
    branches: [main, "release/**"]
  schedule:
    - cron: "5 11 * * *"   # 08:05 em Brasília: janela abriu, reexecuta PRs com testes de ambiente pendentes
  workflow_dispatch:
    inputs:
      momento:
        description: "pr | release (fechamento do pacote para produção)"
        default: pr

jobs:
  qualidade:
    uses: itau-coe/coe-test-framework/.github/workflows/coe-pipeline.yml@v1
    with:
      stack: ${stack}
      momento: \${{ github.event_name == 'schedule' && 'agendado' || startsWith(github.ref_name, 'release/') && 'release' || inputs.momento || 'pr' }}
    secrets: inherit
`;
}

/** Sigla do ID de cenário a partir do produto: "site-coe-quality-ia" -> "SCQI", "pagamentos" -> "PAGA". */
export function siglaDoProduto(produto) {
  const partes = produto.split('-').filter(Boolean);
  const sigla = partes.length > 1 ? partes.map((p) => p[0]).join('') : partes[0]?.slice(0, 4) ?? 'PROD';
  return sigla.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 6).padEnd(2, 'X');
}

export async function init(opcoes, { log = console.log, interativo = process.stdin.isTTY } = {}) {
  let { stack, produto, squad, canais, dir = '.', nivel, perfis } = opcoes;
  if (interativo && (!stack || !produto || !squad)) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    squad ||= await rl.question('Nome da squad: ');
    stack ||= await rl.question(`Stack (${STACKS.join(', ')}): `);
    produto ||= await rl.question('Produto (ex.: modulo-pesquisa, bff-kotlin, api-eventos): ');
    if (!canais && CANAIS_POR_STACK[stack]?.length) {
      canais = await rl.question(`Canais (${CANAIS_POR_STACK[stack].join(', ')}) separados por vírgula: `);
    }
    rl.close();
  }
  if (!STACKS.includes(stack)) throw new Error(`Stack inválida: ${stack}. Use uma de: ${STACKS.join(', ')}`);
  if (!produto || !squad) throw new Error('Informe --produto e --squad.');
  const listaCanais = (canais ? String(canais).split(',').map((c) => c.trim()).filter(Boolean) : CANAIS_POR_STACK[stack].slice(0, 1));
  const temWeb = ['web', 'webview'].some((c) => listaCanais.includes(c));
  // Sem --perfis, a squad web ganha um perfil próprio (coe-tests/perfis/<produto>.yml), e não o do Bankline.
  const perfilProprio = !perfis && temWeb;
  const perfisWeb = perfis ? String(perfis).split(',').map((p) => p.trim()).filter(Boolean) : perfilProprio ? [produto] : [];
  // Produto sem catálogo no framework: o catálogo nasce no repositório da squad a partir do modelo.
  const catalogoCentral = path.join(RAIZ, 'products', produto, 'catalogo', 'cenarios.yml');
  const catalogoLocal = fs.existsSync(catalogoCentral) ? null : 'coe-tests/catalogo/cenarios.yml';

  const destino = path.resolve(dir);
  const arqCfg = path.join(destino, 'coe-test.yml');
  if (fs.existsSync(arqCfg)) throw new Error(`Já existe ${arqCfg}. Edite o arquivo ou apague para recriar.`);

  const cfg = montarConfig({ squad, produto, stack, canais: listaCanais, nivel, perfisWeb, catalogoLocal });
  const erros = validarConfig(cfg);
  if (erros.length) throw new Error(`Configuração gerada inválida:\n - ${erros.join('\n - ')}`);

  const criados = [];
  fs.mkdirSync(destino, { recursive: true });
  fs.writeFileSync(arqCfg, `# Configuração de testes da squad — único arquivo que a squad edita.\n# Referência: docs/guia-adocao.md | Schema: core/schemas/coe-test.schema.json\n${YAML.stringify(cfg)}`);
  criados.push(arqCfg);

  const wf = path.join(destino, '.github/workflows/coe-qualidade.yml');
  fs.mkdirSync(path.dirname(wf), { recursive: true });
  if (!fs.existsSync(wf)) { fs.writeFileSync(wf, workflow(stack)); criados.push(wf); }

  const template = path.join(RAIZ, 'stacks', stack, 'template');
  if (fs.existsSync(template)) copiarDir(template, path.join(destino, 'coe-tests'), criados);
  // Angular e React compartilham o E2E (Playwright): web, demais plataformas e conteúdo da WebView
  if (['angular', 'react'].includes(stack)) {
    copiarDir(path.join(RAIZ, 'stacks', 'web-e2e', 'template'), path.join(destino, 'coe-tests', 'e2e'), criados);
    // package.json não é copiado pelo copiarDir; o do E2E só marca a pasta como CommonJS (projetos "type": "module").
    const pkgE2e = path.join(destino, 'coe-tests', 'e2e', 'package.json');
    if (!fs.existsSync(pkgE2e)) {
      fs.copyFileSync(path.join(RAIZ, 'stacks', 'web-e2e', 'template', 'package.json'), pkgE2e);
      criados.push(pkgE2e);
    }
  }

  if (catalogoLocal) {
    const arq = path.join(destino, catalogoLocal);
    if (!fs.existsSync(arq)) {
      const modelo = fs.readFileSync(path.join(RAIZ, 'core/defaults/catalogo-modelo.yml'), 'utf8');
      fs.mkdirSync(path.dirname(arq), { recursive: true });
      fs.writeFileSync(arq, modelo.replace('__PRODUTO__', produto).replace('__SIGLA__', siglaDoProduto(produto)).replace('__CANAIS__', (listaCanais.length ? listaCanais : ['servico']).join(', ')));
      criados.push(arq);
    }
    log(`Aviso: o produto "${produto}" não tem catálogo no framework (products/${produto}/). O catálogo foi criado em ${catalogoLocal}.`);
  }
  if (perfilProprio) {
    const arq = path.join(destino, 'coe-tests', 'perfis', `${produto}.yml`);
    if (!fs.existsSync(arq)) {
      const modelo = fs.readFileSync(path.join(RAIZ, 'platforms/web/perfis/_modelo.yml'), 'utf8');
      fs.mkdirSync(path.dirname(arq), { recursive: true });
      fs.writeFileSync(arq, modelo.replace(/^id: .*$/m, `id: ${produto}`).replace(/^nome: .*$/m, `nome: ${squad}`).replace(/^frameworks: .*$/m, `frameworks: [${stack === 'react' ? 'react' : 'angular'}]`));
      criados.push(arq);
    }
  }

  log(`Squad ${squad} pronta (${stack}, produto ${produto}, canais: ${listaCanais.join(', ') || 'n/a'}).`);
  log(`${criados.length} arquivo(s) criado(s):`);
  for (const c of criados) log(`  + ${path.relative(destino, c)}`);
  log('Próximos passos: revisar coe-test.yml, rodar "coe-test validate" e abrir o primeiro PR.');
  return criados;
}

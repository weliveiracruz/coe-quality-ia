# Changelog

## v1.0.1 — 2026-11-20
Correções encontradas na adoção do framework pelo site COE Quality IA (Angular). Compatível com a v1.0.0: as squads continuam em `@v1`.

- **Template Angular:**
  - `ts-node` incluído no `package.coe.json`. Sem ele, o `jest.config.ts` não carregava.
  - Jest com `rootDir` na raiz do projeto. A cobertura passa a medir `src/`, e o lcov chega ao SonarQube (antes saía 0/0).
  - Stryker com `tsconfig.app.json`, sem checker de TypeScript e com `coverageAnalysis: off` (a análise perTest derrubava o processo com zone.js no Node 22).
- **CLI:**
  - `coe-test gates` passa a ser idempotente: rodar de novo não duplica as violações de acessibilidade.
  - Novo gate `cobertura` (`gates --cobertura n`): sinaliza cobertura do código novo abaixo do mínimo do CoE mesmo sem SonarQube.
  - `coe-test init` com produto sem catálogo no framework avisa e cria `coe-tests/catalogo/cenarios.yml` a partir do modelo (`core/defaults/catalogo-modelo.yml`), já apontado em `catalogo.arquivo`.
  - `coe-test init` deixa de colocar `perfis_web: [bankline]` em toda squad web. Sem `--perfis`, gera o perfil da própria squad em `coe-tests/perfis/<produto>.yml`.
  - Catálogo ausente gera uma mensagem com o caminho e a solução, no lugar de `ENOENT`.
  - Novo comando `coe-test specs`: lista os specs do Playwright por camada, por convenção de nome (`acessibilidade*`, `visual*`, demais = e2e).
- **E2E web (Playwright):**
  - Perfil padrão: o primeiro de `perfis_web` no `coe-test.yml`, procurado também em `coe-tests/perfis/`.
  - Ambiente `local` no perfil, com `servidor`: o Playwright sobe a aplicação da squad no runner.
  - Artefatos e resultados na raiz do projeto, também sem `COE_ARTEFATOS` e `COE_RESULTADOS`.
  - Vídeo só no CI (`COE_VIDEO` sobrescreve). Localmente não exige o ffmpeg do Playwright.
  - Pasta do E2E marcada como CommonJS (`package.json`), para projetos `"type": "module"`.
- **Workflows:**
  - `stack-web.yml`: E2E, acessibilidade e visual com `precisa_ambiente: false` passam a rodar no runner. Antes, não rodavam em lugar nenhum.
  - Os specs são escolhidos por `coe-test specs`, não pelos nomes de arquivo do template.
  - CI do framework: os jobs `web-template` e `portal` voltam a rodar (falhavam com `__dirname` em ES module).
- **Portal:**
  - Produtos com catálogo no repositório da squad aparecem no "Catálogo de cenários" a partir das métricas.
  - Cobertura abaixo do mínimo aparece indicada no painel.

## v1.0.0 — 2026-11-20
Primeira versão do CoE Test Framework.

- **CLI `coe-test`:**
  - comandos init, validate, plano, janela, catálogo e paridade, esqueleto, privacidade, gates, métricas, contrato, payloads, IU Click, bump, device farm e portal
  - testes automatizados do próprio CLI
- **Templates por stack:** Android (Compose), iOS (SwiftUI), BFF Kotlin, API .NET, Angular e React, além do E2E web compartilhado (Playwright) com demo local.
- **Produtos:** módulo de pesquisa (nativo, WebView e web), BFF Kotlin e API de eventos, com catálogos de cenários.
- **Contratos versionados** (schemas + pacts) em duas camadas, sem broker.
- **Suítes:**
  - bump do FullStory (Android e iOS)
  - transversais: LGPD, resiliência, rede instável, qualidade de dados, smoke, performance e segurança
- **Workflows reutilizáveis:**
  - janela 8h–20h com fila das 8h05
  - fechamento do pacote com suítes pesadas
  - SonarQube interno, Allure e JSON de métricas
  - device farm com adaptador genérico
- **Integração com o IU Click** via MCP, com status e movimentação parametrizáveis por squad.
- **Portal web** (WCAG 2.2 AA): cadastro de squad, perfis web, painel e catálogo.
- **Documentação:** estratégia, DoD, guia de adoção, janela, cenários e IU Click, playbooks e governança.
